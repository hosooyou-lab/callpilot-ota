// ============================================================
//  tutorial.js — 모바일 첫 실행 온보딩(스포트라이트 순차 안내)
//  - PC판(renderer/tutorial.js)과 같은 스포트라이트 방식이지만 모바일 최적화:
//    말풍선은 화면 아래(또는 위) 고정, 버튼은 크게, 대상이 화면 밖이면 스크롤 후 안내.
//  - 하이라이트된 요소는 딤 처리 없이 그대로 눌러볼 수 있게 클릭을 통과시킴(center 스텝만 전체 딤).
//  - 재진입: 헤더 #helpBtn(❔) → CPTutorial.start()
// ============================================================
(function () {
  const KEY = 'cp_tut_done';

  const STEPS = [
    { center: true, title: '👋 콜파일럿 모바일에 오신 걸 환영해요',
      body: '폰 하나로 「자동 전화걸기 + 통화 멘트 + 고객관리」를 다 할 수 있어요.\nPC가 없어도 괜찮아요, 폰만으로 충분합니다.\n\n버튼을 눌러 하나씩 살펴볼게요.',
      next: '시작하기' },

    { sel: '#listCard', title: '① 고객목록에 붙여넣기',
      body: '전화할 사람을 "이름,번호" 형식으로 한 줄에 한 명씩 붙여넣으세요.\n\n📋 클립보드 버튼을 누르면 복사해둔 목록을 바로 가져올 수 있어요.' },

    { sel: '#clearMenuBtn', title: '🧹 목록 비우기',
      body: '통화 전 목록과 통화 후(완료된) 목록을 나눠서 지울 수 있어요.\n\n실수로 다 지우지 않도록, 누르면 확인 메뉴가 먼저 떠요.' },

    { sel: '#scriptBox', title: '📋 콜 스크립트 미리 적어두기',
      body: '통화할 때 읽을 멘트를 여기에 적어두세요.\n\n자동발신을 시작하면 통화 중 화면에 이 스크립트가 크게 떠서 보면서 통화할 수 있어요.' },

    { sel: '#startBtn', title: '② 자동발신 시작',
      body: '▶ 시작 = 목록 위에서부터 자동으로 전화를 겁니다.\n▶▶ 다음 번호 = 한 명씩 넘기기, ■ 정지 = 자동 진행 멈춤.\n\n콜파일럿을 "기본 전화 앱"으로 설정해야 통화화면을 이 앱이 담당할 수 있어요. 안내가 뜨면 꼭 설정해주세요.' },

    { center: true, title: '③ 통화 중 화면',
      body: '통화가 시작되면 이 자리에 스크립트가 크게 뜨고, 통화가 끝나면 결과(가망·부재·거부·나중연락·방문예약·차단요청)를 고르고 메모를 남긴 뒤 [저장하고 다음]을 누르면 돼요.\n\n전화가 걸려오면 여기서 받기·거절도 할 수 있어요.' },

    { center: true, title: '📊 오늘 현황',
      body: '통화 기록이 쌓이면 오늘 콜 수·연결률·가망·예약이 한 줄로 요약돼서 보여요.\n\n오늘 얼마나 통화했는지 한눈에 확인할 수 있어요.' },

    { center: true, title: '📞 최근 통화',
      body: '방금 통화한 사람이 맨 위에 뜨고, 발신(↗)·수신(↙)·부재중이 색으로 구분돼요.\n\n이름·번호를 누르면 전화 상세 화면이 열려요. 거기서 바로 📞전화·✉️메시지를 보내고, 이름·메모·통화결과를 저장해 고객관리를 해요.\n\n고객 정보는 콜파일럿 안에만 저장되고 폰 연락처엔 안 들어갑니다.' },

    { center: true, title: '✉️ 메시지 양식',
      body: '고객 상세창의 메시지 화면에서, 미리 만들어둔 문자 양식(사진 포함)을 골라 바로 보낼 수 있어요.\n\n자주 쓰는 문구는 양식으로 저장해두면 편해요.' },

    { sel: '#redialBtn', title: '🔁 다시 걸기',
      body: '부재중이거나 나중에 연락하기로 한 고객을 골라 목록에 다시 등록할 수 있어요.\n\n놓친 고객을 잊지 않고 챙길 수 있어요.' },

    { sel: '#recMenuBtn', title: '⋯ 기록 메뉴',
      body: '통화기록 전체 삭제처럼 자주 쓰지 않는 기능은 이 ⋯ 메뉴 안에 모아뒀어요.' },

    { center: true, title: '🔄 PC와 함께 쓰기',
      body: '같은 wifi에서 노트북 콜파일럿을 켜고, ⑤ PC 동기화에 화면 우하단의 IP·페어링 코드를 입력해서 연결하세요.\n\n한 번 연결해두면 통화기록·고객이 자동으로 오가고, 다음부터는 자동으로 연결돼요.',
      next: '마치기' },
  ];

  let idx = 0, root = null, onResize = null, onScroll = null, onKey = null, busy = false;

  function injectStyle() {
    if (document.getElementById('tut-style')) return;
    const s = document.createElement('style');
    s.id = 'tut-style';
    s.textContent = `
      .tut-root { position: fixed; inset: 0; z-index: 100000; }
      .tut-dim { position: fixed; inset: 0; background: rgba(0,0,0,.72); }
      .tut-spot { position: fixed; border-radius: 12px; border: 2px solid var(--accent);
        box-shadow: 0 0 0 9999px rgba(0,0,0,.72), 0 0 0 4px rgba(201,100,66,.35);
        pointer-events: none; transition: all .18s ease; }
      .tut-tip { position: fixed; left: 14px; right: 14px; max-width: 480px; margin: 0 auto;
        background: var(--card); border: 1px solid var(--line); border-radius: 16px;
        box-shadow: 0 -10px 40px rgba(0,0,0,.55); padding: 20px 18px 14px;
        color: var(--text); font-family: inherit; z-index: 100001; }
      .tut-tip.tut-pos-bottom { bottom: max(14px, env(safe-area-inset-bottom)); top: auto; }
      .tut-tip.tut-pos-top { top: max(14px, env(safe-area-inset-top)); bottom: auto; }
      .tut-tip-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .tut-step { font-size: 12px; color: var(--faint); font-weight: 600; }
      .tut-tip-title { font-size: 16.5px; font-weight: 800; margin: 10px 0 8px; color: var(--accent); }
      .tut-tip-body { font-size: 14px; line-height: 1.62; white-space: pre-wrap; color: var(--text2); }
      .tut-tip-foot { display: flex; gap: 10px; margin-top: 16px; }
      .tut-btn { border-radius: 10px; font-weight: 700; cursor: pointer;
        border: 1px solid var(--line); background: transparent; color: var(--text); }
      .tut-btn:active { transform: scale(.97); }
      .tut-btn.ghost { border: none; color: var(--faint); background: transparent; padding: 8px 6px; font-size: 12.5px; }
      .tut-btn.tut-prev { flex: 1; padding: 14px; font-size: 14.5px; }
      .tut-btn.primary { flex: 1.6; padding: 15px; font-size: 15.5px;
        background: linear-gradient(180deg, var(--accent), var(--accent2)); color: #fff; border: none; font-weight: 800; }
    `;
    document.head.appendChild(s);
  }

  function wait(ms) { return new Promise((res) => setTimeout(res, ms)); }

  function cleanup() {
    if (root) { root.remove(); root = null; }
    if (onResize) { window.removeEventListener('resize', onResize); onResize = null; }
    if (onScroll) { window.removeEventListener('scroll', onScroll, true); onScroll = null; }
    if (onKey) { document.removeEventListener('keydown', onKey); onKey = null; }
  }

  function finish() {
    cleanup();
    try { localStorage.setItem(KEY, '1'); } catch (e) {}
  }

  function go(n) {
    idx = n;
    if (idx < 0) idx = 0;
    if (idx >= STEPS.length) { finish(); return; }
    showStep();
  }

  function nextStep() {
    const s = STEPS[idx];
    if (s && s.action) { try { s.action(); } catch (e) {} }
    go(idx + 1);
  }

  // 대상 스포트라이트 + 딤 표시(위치만 갱신, 스크롤은 하지 않음 — resize/scroll 시 재사용)
  function renderPositions() {
    if (!root) return;
    const step = STEPS[idx];
    const dim = root.querySelector('.tut-dim');
    const spot = root.querySelector('.tut-spot');
    const tip = root.querySelector('.tut-tip');

    let rect = null;
    if (step.sel) {
      const el = document.querySelector(step.sel);
      if (el) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) rect = r;
      }
    }

    if (rect) {
      // 스포트라이트만: 나머지는 딤 없이 그대로 눌러볼 수 있게 클릭 통과
      dim.style.display = 'none';
      const pad = 6;
      spot.style.display = 'block';
      spot.style.left = Math.max(2, rect.left - pad) + 'px';
      spot.style.top = Math.max(2, rect.top - pad) + 'px';
      spot.style.width = Math.min(window.innerWidth - 4, rect.width + pad * 2) + 'px';
      spot.style.height = Math.min(window.innerHeight - 4, rect.height + pad * 2) + 'px';
    } else {
      // 대상 없음(center 스텝, 또는 숨겨진 섹션) — 화면 전체 딤 + 아래 고정 안내 카드
      spot.style.display = 'none';
      dim.style.display = 'block';
    }

    tip.querySelector('.tut-tip-title').textContent = step.title;
    tip.querySelector('.tut-tip-body').textContent = step.body;
    tip.querySelector('.tut-step').textContent = `${idx + 1} / ${STEPS.length}`;
    const prevBtn = tip.querySelector('.tut-prev');
    const nextBtn = tip.querySelector('.tut-next');
    prevBtn.style.visibility = idx === 0 ? 'hidden' : 'visible';
    nextBtn.textContent = step.next || (idx === STEPS.length - 1 ? '마치기' : '다음 ▸');

    // 말풍선: 하단 고정이 기본. 대상이 화면 하단부에 있어 아래쪽 여유가 부족하면 위쪽 고정.
    const vh = window.innerHeight;
    let placeBottom = true;
    if (rect) {
      const tipH = tip.offsetHeight || 220;
      const spaceBelow = vh - rect.bottom;
      const spaceAbove = rect.top;
      if (spaceBelow < tipH + 24 && spaceAbove > spaceBelow) placeBottom = false;
    }
    tip.classList.toggle('tut-pos-bottom', placeBottom);
    tip.classList.toggle('tut-pos-top', !placeBottom);
  }

  // 스텝 전환 시: 대상이 화면 밖이면 가운데로 스크롤한 뒤 위치를 계산
  async function showStep() {
    if (!root || busy) return;
    busy = true;
    const step = STEPS[idx];
    const el = step.sel ? document.querySelector(step.sel) : null;
    if (el) {
      const r = el.getBoundingClientRect();
      if (r.top < 0 || r.bottom > window.innerHeight || r.width === 0) {
        try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
        await wait(280);
      }
    }
    renderPositions();
    busy = false;
  }

  function start() {
    cleanup();
    injectStyle();
    idx = 0;
    root = document.createElement('div');
    root.className = 'tut-root';
    root.innerHTML =
      '<div class="tut-dim"></div>' +
      '<div class="tut-spot"></div>' +
      '<div class="tut-tip tut-pos-bottom">' +
      '  <div class="tut-tip-head">' +
      '    <span class="tut-step"></span>' +
      '    <button class="tut-btn ghost tut-skip">건너뛰기 ✕</button>' +
      '  </div>' +
      '  <div class="tut-tip-title"></div>' +
      '  <div class="tut-tip-body"></div>' +
      '  <div class="tut-tip-foot">' +
      '    <button class="tut-btn tut-prev">◂ 이전</button>' +
      '    <button class="tut-btn primary tut-next">다음 ▸</button>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(root);
    root.querySelector('.tut-skip').onclick = finish;
    root.querySelector('.tut-prev').onclick = () => go(idx - 1);
    root.querySelector('.tut-next').onclick = () => nextStep();
    onResize = () => renderPositions();
    window.addEventListener('resize', onResize);
    onScroll = () => renderPositions();
    window.addEventListener('scroll', onScroll, true);
    onKey = (e) => {
      if (e.key === 'Escape') finish();
      else if (e.key === 'ArrowRight' || e.key === 'Enter') nextStep();
      else if (e.key === 'ArrowLeft') go(idx - 1);
    };
    document.addEventListener('keydown', onKey);
    showStep();
  }

  window.CPTutorial = {
    start,
    reset: () => { try { localStorage.removeItem(KEY); } catch (e) {} },
  };

  // 헤더 ❔ 버튼 → 언제든 다시 보기
  function wireHelpBtn() {
    const b = document.getElementById('helpBtn');
    if (b) b.onclick = () => start();
  }

  // 첫 실행 자동 시작 — 화면 요소가 준비된 뒤에 한 번만
  function maybeAutoStart(tries) {
    tries = tries || 0;
    let done = false;
    try { done = localStorage.getItem(KEY) === '1'; } catch (e) {}
    if (done) return;
    if (!document.getElementById('listCard') || !document.getElementById('startBtn')) {
      if (tries < 20) return setTimeout(() => maybeAutoStart(tries + 1), 250);
    }
    setTimeout(start, 500);
  }

  function init() {
    wireHelpBtn();
    maybeAutoStart(0);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
