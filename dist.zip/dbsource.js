// ============================================================
//  콜파일럿 모바일 — DB 출처 관리 · 수신거부 대장 · 통화결과 개편 (PC 2026-07-18 라운드 1~3 이식)
//
//  · 개인정보보호법 제20조(수집 출처 고지): 고객 스키마에 srcPath/srcDate/srcConsent/srcProof/
//    srcState/optOutAt/optOutReason/srcLog — PC(tmcrm)와 동일 필드명(LAN 동기화 왕복에서 스프레드로 보존).
//  · srcState: ""=미분류 · "확인"=출처 확인됨 · "격리"=출처불명 격리(발신금지)
//  · 수신거부 = 대장(cp_optout_v1, PC tmcrm_optout_v1과 동일 엔트리 {digits,phone,name,reason,ts,note})
//    기록 후 DB 즉시 파기. 모든 유입(붙여넣기·고객추가·수신저장·다시걸기·PC 동기화)·발신 경로에서
//    재등록/재발신 차단.
//  · 증빙 녹음: 법정 이벤트(수신동의/출처민원/수신거부) 통화의 녹음 파일 경로를 로컬 대장
//    (cp_evidence_v1)과 고객 srcLog에 자동 연결. 파일 자체는 앱 전용 폴더(recordings)에 이미 보관됨.
//    PC 자동 전송·서버(Supabase Storage) 업로드는 PLAN-recording-upload.md 설계 — 서버 결정 후 구현.
//  로드 순서: app.js 다음 · sync.js 이전. app.js 전역(queue/records/save/buildOverlay/...)을 그대로 사용.
// ============================================================
(function () {
  'use strict';

  // ---- 상수 (PC tmcrm.html과 동일) ----
  const SOURCES = ['전화문의', '인터넷광고', '블로그', '인스타그램', '지인소개', '분양홍보관', 'DB구매', '기타'];
  const SRC_PATHS = ['자발 문의', '홈페이지·광고 유입', '지인 소개', '명함·직접 수집', '기타'];
  const SRC_CONSENTS = ['전화 동의', '문자 동의', '서면 동의', '온라인 폼'];
  const SRC_LOG_ICON = { '확인': '🟢', '격리': '🚫', '격리 해제': '↩️', '출처 문의 민원': '🚨', '수신거부': '⛔', '발신금지 해제': '↩️', '수신동의': '✅', '증빙 녹음': '🎙' };

  function loadMyName() { try { const s = JSON.parse(localStorage.getItem('cp_crm_session') || 'null'); return (s && s.name) || ''; } catch (e) { return ''; } }
  function fmtStamp(iso) { const d = new Date(iso); return isNaN(d) ? String(iso || '') : d.toLocaleString('ko-KR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); }
  function syncNow() { try { if (window.cpSyncNow) window.cpSyncNow(); } catch (e) {} }
  function persistQueueAndRender() { save('cp_queue', queue); renderQueue(); try { renderCrm(); } catch (e) {} syncNow(); }

  // ---- 발신금지 판정 + 법정 로그 (PC isNoCall/pushSrcLog와 동일) ----
  window.cpIsNoCall = function (c) { return !!(c && (c.srcState === '격리' || c.optOutAt)); };
  window.cpPushSrcLog = function (c, type, note) { if (!Array.isArray(c.srcLog)) c.srcLog = []; c.srcLog.push({ ts: new Date().toISOString(), type: type, note: note || '' }); };

  // ---- ⛔ 수신거부 옵트아웃 대장 — 고객 DB는 파기하되 재발신 방지 최소 정보만 별도 보관(정통망법) ----
  const OPTOUT_KEY = 'cp_optout_v1';
  let optoutLedger = [];
  function loadOptout() { try { optoutLedger = JSON.parse(localStorage.getItem(OPTOUT_KEY) || '[]') || []; } catch (e) { optoutLedger = []; } if (!Array.isArray(optoutLedger)) optoutLedger = []; }
  function saveOptout() { try { localStorage.setItem(OPTOUT_KEY, JSON.stringify(optoutLedger)); } catch (e) {} }
  window.cpOptoutHas = function (d) { d = normNum(d); return !!d && optoutLedger.some(o => o && o.digits === d); };
  window.cpOptoutAdd = function (rec, reason, note) {
    const d = normNum(rec && (rec.phone || rec.number)); if (!d) return;
    const hit = optoutLedger.find(o => o && o.digits === d);
    if (hit) { hit.ts = new Date().toISOString(); hit.reason = reason || hit.reason; if (note) hit.note = (hit.note ? hit.note + ' · ' : '') + note; }
    else optoutLedger.push({ digits: d, phone: fmt(d), name: (rec && rec.name) || '', reason: reason || '수신거부', ts: new Date().toISOString(), note: note || '' });
    saveOptout();
  };
  window.cpOptoutAppendNote = function (d, note) { d = normNum(d); const hit = optoutLedger.find(o => o && o.digits === d); if (hit && note) { hit.note = (hit.note ? hit.note + ' · ' : '') + note; saveOptout(); } };

  // ---- 📱↔🖥 LAN 동기화용 대장 접근 — sync.js 가 /sync POST 본문에 싣고, PC 응답을 병합한다 ----
  window.cpOptoutList = function () { return optoutLedger.map(o => Object.assign({}, o)); };
  // PC(store 'tmcrm_optout' = TM tmcrm_optout_v1 미러) 대장 병합: digits 합집합 · ts 최신 우선.
  // {...로컬, ...원격} 스프레드로 PC 전용 감사 필드(said/agent/callSec/src)도 그대로 보존해 왕복 유실 없음.
  // 반환 = 이번에 '새로 알게 된' 번호 목록 → sync.js 가 해당 고객을 파기(tombstone 전파)한다.
  window.cpOptoutMergeRemote = function (remote) {
    const added = [];
    let changed = false;
    (remote || []).forEach(it => {
      if (!it) return;
      const d = normNum(it.digits || it.phone); if (!d) return;
      const hit = optoutLedger.find(o => o && o.digits === d);
      if (!hit) { optoutLedger.push(Object.assign({}, it, { digits: d, phone: it.phone || fmt(d) })); added.push(d); changed = true; }
      else if (String(it.ts || '') > String(hit.ts || '')) { Object.assign(hit, it, { digits: d }); changed = true; }
      else {
        // 로컬 승자(또는 동일 ts) — 로컬 값은 유지하되, 로컬에 없는 필드(PC 감사필드 said/agent/callSec/src 등)만 보충
        Object.keys(it).forEach(k => {
          if ((hit[k] == null || hit[k] === '') && it[k] != null && it[k] !== '') { hit[k] = it[k]; changed = true; }
        });
      }
    });
    if (changed) saveOptout();
    return added;
  };

  // ---- DB 파기 (활성 고객 + PC 전파 tombstone) — 통화기록(records)은 법정 대응 근거로 유지 ----
  window.cpPurgeByNumber = function (n) {
    n = normNum(n); let removed = null;
    for (let i = queue.length - 1; i >= 0; i--) {
      if (normNum(queue[i].number) === n) { removed = queue[i]; queue.splice(i, 1); if (i <= idx) idx--; }
    }
    if (removed) addTombstone(n);
    persistQueueAndRender();
    return removed;
  };

  // ---- 발신 하드블록 ----
  window.cpNoCallCheck = function (n) {
    n = normNum(n); if (!n) return false;
    if (cpOptoutHas(n)) { toast('⛔ 수신거부 이력 번호 — 재발신 방지 목록 등록(발신 금지)', 2600); return true; }
    const c = findCustomer(n);
    if (c && cpIsNoCall(c)) {
      toast('⛔ 발신금지 고객 (' + (c.optOutReason || '출처불명 격리') + ') — 출처 상세에서 확인하세요', 2800);
      return true;
    }
    if (isBlocked(n)) { toast('🚫 차단 목록 번호 — 발신 금지', 2200); return true; }
    return false;
  };
  window.cpQueueNoCall = function (c) { return !!(c && (cpIsNoCall(c) || cpOptoutHas(normNum(c.number)))); };

  // ---- 출처 배지/한 줄 표시 (PC srcBadge/srcLineFor와 동일 규칙) ----
  window.cpSrcBadge = function (c) {
    if (c.optOutAt) return { ic: '⛔', tx: c.optOutReason || '발신금지', cls: 'src-out' };
    if (c.srcState === '격리') return { ic: '🚫', tx: '격리(발신금지)', cls: 'src-quar' };
    if (c.srcState === '확인') return { ic: '🟢', tx: c.source || c.srcPath || '확인', cls: 'src-ok' };
    return { ic: '⚠️', tx: '출처 미분류', cls: 'src-none' };
  };
  function srcLineFor(c) {
    if (!c) return '';
    if (c.optOutAt) return '⛔ 발신금지 — ' + (c.optOutReason || '수신거부') + ' (' + String(c.optOutAt).slice(0, 10) + ' 처리)';
    if (c.srcState === '격리') return '🚫 출처불명 격리 — 발신금지';
    const bits = [];
    if (c.source || c.srcPath) bits.push(c.source || c.srcPath);
    if (c.srcDate) bits.push(String(c.srcDate).slice(2) + ' 수집');
    if (c.srcConsent) bits.push(c.srcConsent);
    if (!bits.length) return '⚠️ 출처 미분류 — 출처 상세에서 확인 필요';
    return '📌 출처: ' + bits.join(' · ');
  }
  window.cpUpdateSrcInfo = function (number) {
    const el = document.getElementById('callSrcInfo'); if (!el) return;
    const n = normNum(number);
    if (!n) { el.hidden = true; return; }
    let t, danger = false, warn = false;
    if (cpOptoutHas(n)) { t = '⛔ 수신거부 이력 — 재발신 방지 목록 등록(발신 금지)'; danger = true; }
    else {
      const c = findCustomer(n);
      if (!c) { el.hidden = true; return; }
      t = srcLineFor(c); danger = cpIsNoCall(c); warn = /미분류/.test(t);
    }
    el.textContent = t;
    el.className = 'src-info' + (danger ? ' danger' : (warn ? ' warn' : ''));
    el.hidden = false;
  };

  // ---- 등록 시 출처 적용 — 경로+동의가 모두 있으면 '확인'으로 승격(PC srcSaveOk 규칙), 아니면 미분류 유지 ----
  window.cpApplyRegSrc = function (c, o) {
    o = o || {};
    if (o.srcPath) c.srcPath = o.srcPath;
    if (o.srcConsent) c.srcConsent = o.srcConsent;
    if (o.srcDate) c.srcDate = o.srcDate;
    if (o.srcProof) c.srcProof = o.srcProof;
    if (!Array.isArray(c.srcLog)) c.srcLog = [];
    if (c.srcPath && c.srcConsent && !c.srcState) { c.srcState = '확인'; cpPushSrcLog(c, '확인', o.note || '신규 등록 시 기재'); }
    return c;
  };

  // ---- 현재 통화 상대 번호 (자동발신·수동·수신·결과입력 컨텍스트 공용) ----
  function currentCallNumber() {
    try {
      if (typeof extResult !== 'undefined' && extResult && extResult.number) return normNum(extResult.number);
      if (typeof running !== 'undefined' && running && idx >= 0 && queue[idx]) return normNum(queue[idx].number);
      if (typeof incomingNumber !== 'undefined' && incomingNumber) return normNum(incomingNumber);
    } catch (e) {}
    return '';
  }
  function stampMemo(text) { const el = document.getElementById('memoBox'); if (el) el.value = el.value ? el.value + '\n' + text : text; }
  function upsertCustomer(n) {
    let c = findCustomer(n);
    if (!c) { c = ensureCustomerFields({ name: lookupName(n) || '(이름없음)', number: n, memo: '', tag: '', done: false }); queue.push(c); }
    return c;
  }

  // ---- ✅ 수신동의 (원클릭·출처 상세 공용 코어) — 일시·방식(전화 동의)·상담사(CRM 로그인 이름) 기록 ----
  function logConsentCore(c) {
    const at = new Date().toISOString();
    c.srcConsent = '전화 동의'; if (!c.srcDate) c.srcDate = at.slice(0, 10);
    if (!c.srcState && c.srcPath) c.srcState = '확인';   // 경로까지 있으면 확인으로 승격(경로 없으면 미분류 유지)
    const me = loadMyName();
    cpPushSrcLog(c, '수신동의', '통화 중 구두 동의 · 전화 동의' + (me ? ' · 상담사 ' + me : ''));
    c.updatedAt = nowIso();
    persistQueueAndRender();
    return me;
  }
  window.cpConsentOneClick = function () {
    const n = currentCallNumber(); if (!n) { toast('먼저 통화(번호)를 시작하세요'); return; }
    if (cpOptoutHas(n)) { toast('⛔ 수신거부 이력 번호 — 재등록·기록할 수 없어요'); return; }
    const c = upsertCustomer(n);
    const now = new Date();
    const me = logConsentCore(c);
    stampMemo('[수신동의 · ' + now.toLocaleString('ko-KR') + ' 기록]');
    cpAttachEvidence(n, '수신동의');   // 🎙 동의 녹취 자동 연결(로컬 보관)
    cpUpdateSrcInfo(n);
    toast('✅ 수신동의 기록 (전화 동의 · ' + now.toLocaleString('ko-KR') + (me ? ' · ' + me : '') + ')', 2600);
  };

  // ---- ⚖ 원클릭 법정 기록 — 출처민원=발신금지+기록 보존 · 수신거부=대장 기록+DB 즉시 파기 ----
  window.cpLegalOneClick = function (kind) {
    const n = currentCallNumber(); if (!n) { toast('먼저 통화(번호)를 시작하세요'); return; }
    const now = new Date();
    if (kind === '수신거부') {
      const c = findCustomer(n);
      const who = fmt(n) + (c && c.name && c.name !== '(이름없음)' ? ' (' + c.name + ')' : '');
      if (!confirm('수신거부로 기록하고 이 고객을 DB에서 즉시 파기합니다.\n번호·일시·사유만 재발신 방지 목록에 남습니다.\n\n' + who)) return;
      cpOptoutAdd({ phone: n, name: (c && c.name) || lookupName(n) || '' }, '수신거부', '모바일 원클릭 · 즉시 파기');
      stampMemo('[수신거부 · ' + now.toLocaleString('ko-KR') + ' 기록]');
      curTag = '수신거부'; highlightTag();
      // 자동발신의 '현재 항목'이면 파기를 저장 시(saveAndNext)로 미룸 — 진행 인덱스가 안 꼬이게. 그 외엔 즉시 파기.
      const isCurrentAuto = (typeof running !== 'undefined' && running && idx >= 0 && queue[idx] && normNum(queue[idx].number) === n);
      if (!isCurrentAuto) cpPurgeByNumber(n);
      cpAttachEvidence(n, '수신거부');
      cpUpdateSrcInfo(n);
      toast('⛔ 수신거부 기록 — 재발신 방지 등록' + (isCurrentAuto ? ' (저장 시 DB 파기)' : ' · DB 파기 완료') + ' (' + now.toLocaleString('ko-KR') + ')', 3200);
    } else {
      if (cpOptoutHas(n)) { toast('⛔ 이미 수신거부 이력 번호예요'); return; }
      const c = upsertCustomer(n);
      c.optOutAt = now.toISOString(); c.optOutReason = kind;   // 민원은 분쟁 대응 근거가 필요하므로 파기하지 않고 발신금지+기록 보존
      cpPushSrcLog(c, kind, '원클릭 기록 (모바일)');
      c.updatedAt = nowIso();
      persistQueueAndRender();
      stampMemo('[' + kind + ' · ' + now.toLocaleString('ko-KR') + ' 기록]');
      curTag = '출처민원'; highlightTag();
      cpAttachEvidence(n, kind);
      cpUpdateSrcInfo(n);
      toast('⚖ ' + kind + ' 기록 — 발신금지 처리했어요 (' + now.toLocaleString('ko-KR') + ')', 3000);
    }
  };

  // ---- 🎙 증빙 녹음 연결 (로컬 보관 대장 cp_evidence_v1) ----
  //  녹음 파일은 통화 종료 후에야 생기므로 8초 간격 최대 22회(≈3분) 재시도. 같은 파일은 한 번만.
  //  파일 자체는 네이티브가 앱 전용 폴더(recordings)에 저장 → 여기서는 경로·일시·사유를 대장·법정 로그에 연결.
  const EVID_KEY = 'cp_evidence_v1';
  function loadEvid() { try { return JSON.parse(localStorage.getItem(EVID_KEY) || '[]') || []; } catch (e) { return []; } }
  function saveEvid(l) { try { localStorage.setItem(EVID_KEY, JSON.stringify(l)); } catch (e) {} }
  window.cpAttachEvidence = async function (number, kind) {
    if (!Dialer || !Dialer.listRecordings) return;
    const n = normNum(number);
    // 이 통화로 인정할 기준 시각: 발신 시작(없으면 최근 10분) − 2분 여유
    const sinceTs = ((typeof dialAt !== 'undefined' && dialAt) ? dialAt : (Date.now() - 10 * 60 * 1000)) - 2 * 60 * 1000;
    for (let i = 0; i < 22; i++) {
      let list = [];
      try { const r = await Dialer.listRecordings({ number: n }); list = (r && r.recordings) || []; } catch (e) { list = []; }
      const cand = list.find(f => f && (f.modified || 0) >= sinceTs);
      if (cand) {
        const reg = loadEvid();
        if (reg.some(x => x && x.path === cand.path)) return;   // 같은 통화에서 다른 버튼의 루프가 이미 연결함
        reg.push({ digits: n, path: cand.path, name: cand.name || '', ts: new Date().toISOString(), kind: kind, uploaded: false });
        saveEvid(reg);
        const c = findCustomer(n);
        if (c) {
          cpPushSrcLog(c, '증빙 녹음', (cand.name || cand.path) + ' · ' + kind);
          if (cand.name) c.srcProof = c.srcProof ? c.srcProof + ' · ' + cand.name : cand.name;
          c.updatedAt = nowIso(); persistQueueAndRender();
        } else cpOptoutAppendNote(n, '증빙 녹음 ' + (cand.name || ''));   // 수신거부(파기됨)는 대장에 증빙 표기
        toast('🎙 통화 녹음 증빙 연결 완료 — ' + (cand.name || ''));
        return;
      }
      await new Promise(rs => setTimeout(rs, 8000));
    }
    toast('🎙 이번 통화 녹음을 못 찾았어요 — 통화 자동녹음 설정 확인 (증빙 미연결)', 3200);
  };

  // ---- 💬 가망 유형 팝업 (PC openGamangPicker 이식) — 가망/콜백 날짜·시간/방문예약 ----
  window.openGamangPicker = function () {
    const n = currentCallNumber(); if (!n) { toast('먼저 통화(번호)를 시작하세요'); return; }
    const p2 = x => String(x).padStart(2, '0');
    const dstr = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
    const today = new Date(), tomorrow = new Date(Date.now() + 86400000);
    const chip = (label, d, t) => `<button class="btn ghost gp-chip" data-d="${d}" data-t="${t}" type="button">${label}</button>`;
    const { ov, close } = buildOverlay('gamangOv',
      `<div class="cp-ov-h">💬 가망 — 어떤 가망인가요?</div>
       <button class="btn primary cm-btn" id="gpPlain" type="button">💬 가망 — 대화 잘 됨</button>
       <button class="btn outline cm-btn" id="gpVisit" type="button">🏠 방문예약 잡힘</button>
       <div class="gp-cb">
         <div class="cp-ov-lbl">📞 콜백 — "조금 이따/나중에 전화 주세요"</div>
         <div class="gp-chips">${chip('오늘 17:00', dstr(today), '17:00')}${chip('오늘 19:00', dstr(today), '19:00')}${chip('내일 10:00', dstr(tomorrow), '10:00')}${chip('내일 14:00', dstr(tomorrow), '14:00')}</div>
         <div class="gp-inrow">
           <input type="date" id="gpDate" value="${dstr(today)}">
           <input type="time" id="gpTime">
           <button class="btn blue" id="gpGo" type="button">지정</button>
         </div>
         <div class="cp-ov-note" style="margin-top:6px;text-align:left">지정한 날짜·시간이 「오늘 연락할 고객」에 바로 올라가 놓치지 않아요.</div>
       </div>
       <div class="row"><button class="btn ghost" id="gpClear" type="button">결과 해제</button><button class="btn ghost" id="gpX" type="button">취소</button></div>`);
    const apply = (tag, cbDate, cbTime) => {
      close();
      curTag = tag; highlightTag();
      const gb = document.querySelector('#tagRow .tag[data-tag="가망"]');
      if (gb) { gb.classList.add('on'); gb.textContent = tag === '가망' ? '가망' : (tag === '방문예약' ? '가망·방문예약' : '가망·콜백' + (cbTime ? ' ' + cbTime : '')); }
      if (tag === '나중연락' && cbDate) {
        const c = upsertCustomer(n);
        c.nextCall = cbDate; c.nextCallTime = cbTime || ''; c.nextContact = cbDate;   // PC(TM) 동일 필드명 + 구필드 호환
        c.updatedAt = nowIso();
        persistQueueAndRender();
      }
      toast('결과 선택: ' + (tag === '나중연락' ? '콜백 ' + (cbDate || '') + (cbTime ? ' ' + cbTime : '') : tag) + ' — 저장 때 기록돼요', 2400);
    };
    ov.querySelector('#gpPlain').onclick = () => apply('가망');
    ov.querySelector('#gpVisit').onclick = () => apply('방문예약');
    ov.querySelectorAll('.gp-chip').forEach(b => b.onclick = () => apply('나중연락', b.dataset.d, b.dataset.t));
    ov.querySelector('#gpGo').onclick = () => {
      const d = ov.querySelector('#gpDate').value;
      if (!d) { toast('콜백 날짜를 선택하세요'); return; }
      apply('나중연락', d, ov.querySelector('#gpTime').value || '');
    };
    ov.querySelector('#gpClear').onclick = () => { close(); curTag = ''; highlightTag(); };
    ov.querySelector('#gpX').onclick = close;
  };

  // ---- 📋 출처 상세 모달 (PC openSrcModal 이식) ----
  window.openSrcModal = function (number) {
    const n = normNum(number);
    const c = findCustomer(n);
    if (!c) { toast('고객 목록에 없는 번호예요'); return; }
    let banner = '', bcls = 'warn';
    if (c.optOutAt) { bcls = 'danger'; banner = '⛔ 발신금지 — ' + esc(c.optOutReason || '') + ' (' + fmtStamp(c.optOutAt) + ' 처리)'; }
    else if (c.srcState === '격리') { bcls = 'danger'; banner = '🚫 출처불명 격리 — 발신금지 상태입니다. 출처를 확인해 저장하면 해제됩니다.'; }
    else if (c.srcState === '확인') { bcls = 'ok'; banner = '🟢 출처 확인됨' + (c.srcPath ? ' — ' + esc(c.srcPath) : '') + (c.srcConsent ? ' · ' + esc(c.srcConsent) : ''); }
    else banner = '⚠️ 출처 미분류 — 수집 경로·동의 방식을 확인해 기재하거나, 확인이 안 되면 격리(발신금지)하세요.';
    const opt = (list, cur) => '<option value="">선택하세요</option>' + list.map(s => `<option ${s === cur ? 'selected' : ''}>${s}</option>`).join('');
    const logs = Array.isArray(c.srcLog) ? c.srcLog.slice().reverse() : [];
    const { ov, close } = buildOverlay('srcModalOv',
      `<div class="cp-ov-h">📋 출처 상세 <span class="cp-ov-sub">${fmt(n)}${c.name && c.name !== '(이름없음)' ? ' · ' + esc(c.name) : ''}</span></div>
       <div class="src-banner ${bcls}">${banner}</div>
       <div class="cp-ov-lbl">수집 경로 *</div><select id="smPath">${opt(SRC_PATHS, c.srcPath)}</select>
       <div class="cp-ov-lbl">세부 채널</div><select id="smChan"><option value="">—</option>${SOURCES.map(s => `<option ${s === c.source ? 'selected' : ''}>${s}</option>`).join('')}</select>
       <div class="cp-ov-lbl">수집 일자</div><input type="date" id="smDate" value="${esc(c.srcDate || '')}">
       <div class="cp-ov-lbl">동의 방식 *</div><select id="smConsent">${opt(SRC_CONSENTS, c.srcConsent)}</select>
       <div class="cp-ov-lbl">증빙 메모</div><input type="text" id="smProof" value="${esc(c.srcProof || '')}" placeholder="예: 0712 홈페이지 상담신청 폼 · 통화 녹취 있음" autocomplete="off">
       <div class="row"><button class="btn primary" id="smSaveOk" type="button">💾 출처 확인됨으로 저장</button></div>
       <div class="row">
         ${c.srcState === '격리' ? '<button class="btn ghost" id="smUnquar" type="button">↩️ 격리 해제</button>' : '<button class="btn ghost danger" id="smQuar" type="button">🚫 출처불명 격리 (발신금지)</button>'}
         ${c.optOutAt ? '<button class="btn ghost" id="smClearOpt" type="button">↩️ 발신금지 해제</button>' : ''}
       </div>
       <div class="row">
         <button class="btn ghost consent" id="smConsentBtn" type="button">✅ 수신동의</button>
         <button class="btn ghost danger" id="smMinwon" type="button">🚨 출처민원</button>
         <button class="btn ghost danger" id="smRefuse" type="button">⛔ 수신거부</button>
       </div>
       <div class="src-log"><b>법정 대응 로그 (${logs.length}건 · 자동 기록, 삭제 불가)</b>
         ${logs.length ? logs.map(l => `<div class="li"><b>${SRC_LOG_ICON[l.type] || '·'} ${esc(l.type)}</b><span>${fmtStamp(l.ts)}</span><span>${esc(l.note || '')}</span></div>`).join('') : '<div class="li">기록 없음</div>'}
       </div>`);
    const reopen = () => { close(); openSrcModal(n); repaintAudit(); };
    ov.querySelector('#smSaveOk').onclick = () => {
      const p = ov.querySelector('#smPath').value, cs = ov.querySelector('#smConsent').value;
      if (!p || !cs) { toast("⚠️ 수집 경로와 동의 방식을 선택해야 '확인'으로 저장할 수 있습니다", 3000); return; }
      c.srcPath = p; c.source = ov.querySelector('#smChan').value || c.source || '';
      c.srcDate = ov.querySelector('#smDate').value || todayStr();
      c.srcConsent = cs; c.srcProof = (ov.querySelector('#smProof').value || '').trim();
      const was = c.srcState; c.srcState = '확인';
      cpPushSrcLog(c, '확인', was === '격리' ? '격리 해제 후 출처 확인' : '출처 상세에서 기재');
      c.updatedAt = nowIso(); persistQueueAndRender();
      toast('🟢 출처 확인됨으로 저장했습니다'); reopen();
    };
    const q = ov.querySelector('#smQuar'); if (q) q.onclick = () => {
      if (!confirm("이 고객을 '출처불명 격리(발신금지)'로 지정합니다.\n자동발신에서 제외되고 발신이 잠깁니다.")) return;
      c.srcState = '격리'; cpPushSrcLog(c, '격리', '출처 상세에서 지정');
      c.updatedAt = nowIso(); persistQueueAndRender();
      toast('🚫 출처불명 격리 — 발신금지 처리했습니다'); reopen();
    };
    const uq = ov.querySelector('#smUnquar'); if (uq) uq.onclick = () => {
      c.srcState = ''; cpPushSrcLog(c, '격리 해제', '출처 상세에서 해제(미분류로 복귀)');
      c.updatedAt = nowIso(); persistQueueAndRender();
      toast('격리를 해제했습니다 (미분류)'); reopen();
    };
    const co = ov.querySelector('#smClearOpt'); if (co) co.onclick = () => {
      if (!confirm('발신금지를 해제합니다.\n(기존 민원/수신거부 기록은 법정 로그에 그대로 남습니다)')) return;
      cpPushSrcLog(c, '발신금지 해제', '이전: ' + (c.optOutReason || '') + ' ' + fmtStamp(c.optOutAt));
      c.optOutAt = ''; c.optOutReason = '';
      c.updatedAt = nowIso(); persistQueueAndRender();
      toast('발신금지를 해제했습니다'); reopen();
    };
    ov.querySelector('#smConsentBtn').onclick = () => {
      const now = new Date(); const me = logConsentCore(c);
      toast('✅ 수신동의 기록 (전화 동의 · ' + now.toLocaleString('ko-KR') + (me ? ' · ' + me : '') + ')', 2600);
      reopen();
    };
    ov.querySelector('#smMinwon').onclick = () => {
      const now = new Date();
      c.optOutAt = now.toISOString(); c.optOutReason = '출처 문의 민원';
      cpPushSrcLog(c, '출처 문의 민원', '출처 상세에서 기록');
      c.updatedAt = nowIso(); persistQueueAndRender();
      toast('⛔ 출처 문의 민원 기록 — 발신금지 처리 (' + now.toLocaleString('ko-KR') + ')', 3000); reopen();
    };
    ov.querySelector('#smRefuse').onclick = () => {
      const who = fmt(n) + (c.name && c.name !== '(이름없음)' ? ' (' + c.name + ')' : '');
      if (!confirm('수신거부로 기록하고 이 고객을 DB에서 즉시 파기합니다.\n번호·일시·사유만 재발신 방지 목록에 남습니다.\n\n' + who)) return;
      cpOptoutAdd({ phone: n, name: c.name || '' }, '수신거부', '출처 상세 원클릭 · 즉시 파기');
      cpPurgeByNumber(n);
      close(); repaintAudit();
      // 뒤에 열려있던 고객 상세 화면도 닫기 — 파기된 고객 스냅샷이 남지 않게
      try { const cs2 = document.getElementById('contactScreen'); if (cs2) { const bk = cs2.querySelector('#csBack'); if (bk) bk.click(); else cs2.remove(); } } catch (e) {}
      toast('⛔ 수신거부 기록 · DB 파기 완료 (재발신 방지 목록 보관)', 3200);
    };
  };

  // ---- 📋 DB 출처 관리 (일괄 분류 도구 · PC renderSrcAudit 이식) ----
  let auditFilter = '미분류'; const auditSel = new Set();
  let auditRepaint = null;
  function repaintAudit() { if (auditRepaint) { try { auditRepaint(); } catch (e) {} } }
  function auditKind(c) { if (c.optOutAt) return '발신금지'; if (c.srcState === '격리') return '격리'; if (c.srcState === '확인') return '확인'; return '미분류'; }
  window.openSrcAudit = function () {
    auditSel.clear(); auditFilter = '미분류';
    buildOverlay('srcAuditOv', '<div id="srcAuditBody"></div>');
    function paint() {
      const body = document.getElementById('srcAuditBody'); if (!body) { auditRepaint = null; return; }
      const prevList = body.querySelector('.audit-list');
      const scrollTop = prevList ? prevList.scrollTop : 0;   // 재렌더 시 스크롤 위치 유지
      const cnt = { 미분류: 0, 확인: 0, 격리: 0, 발신금지: 0 };
      queue.forEach(c => { cnt[auditKind(c)]++; });
      const list = auditFilter === '전체' ? queue.slice() : queue.filter(c => auditKind(c) === auditFilter);
      const ids = new Set(list.map(c => c.id));
      [...auditSel].forEach(u => { if (!ids.has(u)) auditSel.delete(u); });
      const chipH = k => `<button class="audit-chip ${auditFilter === k ? 'on' : ''}" data-k="${k}" type="button">${k} ${k === '전체' ? queue.length : cnt[k]}</button>`;
      const allOn = list.length && list.every(c => auditSel.has(c.id));
      body.innerHTML =
        `<div class="cp-ov-h">📋 DB 출처 관리</div>
         <div class="cp-ov-note" style="text-align:left">출처 미기재(미분류) 고객을 <b>출처 확인</b> 또는 <b>출처불명 격리(발신금지)</b>로 정리하세요. 격리·발신금지 고객은 자동발신에서 빠지고 발신이 잠깁니다.</div>
         <div class="audit-chips">${['미분류', '격리', '발신금지', '확인', '전체'].map(chipH).join('')}</div>
         <label class="audit-all"><input type="checkbox" id="adAll" ${allOn ? 'checked' : ''}> 보이는 고객 전체선택 <span>(${auditSel.size}명 선택)</span></label>
         <div class="row">
           <button class="btn outline" id="adOk" type="button" ${auditSel.size ? '' : 'disabled'}>✅ 출처 확인 (${auditSel.size})</button>
           <button class="btn ghost danger" id="adQuar" type="button" ${auditSel.size ? '' : 'disabled'}>🚫 격리</button>
           <button class="btn ghost" id="adUnquar" type="button" ${auditSel.size ? '' : 'disabled'}>↩️ 해제</button>
         </div>
         <div id="adForm" style="display:none" class="ad-form">
           <div class="cp-ov-lbl">수집 경로 *</div><select id="adPath"><option value="">선택하세요</option>${SRC_PATHS.map(s => `<option>${s}</option>`).join('')}</select>
           <div class="cp-ov-lbl">동의 방식 *</div><select id="adConsent"><option value="">선택하세요</option>${SRC_CONSENTS.map(s => `<option>${s}</option>`).join('')}</select>
           <div class="cp-ov-lbl">수집 일자</div><input type="date" id="adDate">
           <div class="cp-ov-lbl">증빙 메모</div><input type="text" id="adProof" placeholder="예: 2026-05 네이버 광고 리드폼 일괄 수집분 · 폼 기록 보관" autocomplete="off">
           <div class="row"><button class="btn primary" id="adGo" type="button">선택 ${auditSel.size}명에게 적용</button><button class="btn ghost" id="adCancel" type="button">취소</button></div>
         </div>
         <div class="audit-list">
           ${list.length ? list.map(c => {
             const bb = cpSrcBadge(c);
             const nm = (c.name && c.name !== '(이름없음)') ? esc(c.name) : '';
             return `<label class="audit-row"><input type="checkbox" class="adChk" data-id="${c.id}" ${auditSel.has(c.id) ? 'checked' : ''}>
               <div class="audit-main">${nm ? '<b>' + nm + '</b>' : ''} <span class="audit-no">${fmt(normNum(c.number))}</span>
                 <span class="src-cell ${bb.cls}">${bb.ic} ${esc(bb.tx)}</span></div>
               <button class="audit-detail" data-n="${normNum(c.number)}" type="button">상세</button></label>`;
           }).join('') : '<div class="grp-empty">해당 고객이 없어요</div>'}
         </div>`;
      const newList = body.querySelector('.audit-list'); if (newList) newList.scrollTop = scrollTop;
      body.querySelectorAll('.audit-chip').forEach(cb => cb.onclick = () => { auditFilter = cb.dataset.k; auditSel.clear(); paint(); });
      body.querySelectorAll('.adChk').forEach(cb => cb.onchange = () => { if (cb.checked) auditSel.add(cb.dataset.id); else auditSel.delete(cb.dataset.id); paint(); });
      body.querySelectorAll('.audit-detail').forEach(db => db.onclick = (e) => { e.preventDefault(); e.stopPropagation(); openSrcModal(db.dataset.n); });
      const allBox = body.querySelector('#adAll');
      if (allBox) allBox.onchange = () => { if (allBox.checked) list.forEach(c => auditSel.add(c.id)); else auditSel.clear(); paint(); };
      const selRecs = () => queue.filter(c => auditSel.has(c.id));
      const okB = body.querySelector('#adOk');
      if (okB) okB.onclick = () => { const f = body.querySelector('#adForm'); f.style.display = f.style.display === 'none' ? '' : 'none'; const d = body.querySelector('#adDate'); if (d && !d.value) d.value = todayStr(); };
      const cxB = body.querySelector('#adCancel'); if (cxB) cxB.onclick = () => { body.querySelector('#adForm').style.display = 'none'; };
      const goB = body.querySelector('#adGo');
      if (goB) goB.onclick = () => {
        const p = body.querySelector('#adPath').value, cs = body.querySelector('#adConsent').value;
        const d = body.querySelector('#adDate').value || todayStr(), pf = (body.querySelector('#adProof').value || '').trim();
        if (!p || !cs) { toast('⚠️ 수집 경로와 동의 방식을 선택하세요'); return; }
        let nn = 0;
        selRecs().forEach(c => { c.srcPath = p; c.srcDate = d; c.srcConsent = cs; if (pf) c.srcProof = pf; c.srcState = '확인'; cpPushSrcLog(c, '확인', '일괄 분류 도구'); c.updatedAt = nowIso(); nn++; });
        if (nn) persistQueueAndRender();
        auditSel.clear(); paint();
        toast(`🟢 ${nn}명 출처 확인됨`);
      };
      const qB = body.querySelector('#adQuar');
      if (qB) qB.onclick = () => {
        const rs = selRecs().filter(c => c.srcState !== '격리'); if (!rs.length) { toast('선택된 고객이 없습니다'); return; }
        if (!confirm(`${rs.length}명을 '출처불명 격리(발신금지)'로 지정합니다.\n자동발신에서 제외되고 발신이 잠깁니다.\n(출처가 확인되면 언제든 해제할 수 있습니다)`)) return;
        rs.forEach(c => { c.srcState = '격리'; cpPushSrcLog(c, '격리', '일괄 분류 도구'); c.updatedAt = nowIso(); });
        persistQueueAndRender(); auditSel.clear(); paint();
        toast(`🚫 ${rs.length}명 격리(발신금지) 처리했습니다`);
      };
      const uB = body.querySelector('#adUnquar');
      if (uB) uB.onclick = () => {
        const rs = selRecs().filter(c => c.srcState === '격리'); if (!rs.length) { toast('선택 중 격리 상태 고객이 없습니다'); return; }
        rs.forEach(c => { c.srcState = ''; cpPushSrcLog(c, '격리 해제', '일괄 분류 도구'); c.updatedAt = nowIso(); });
        persistQueueAndRender(); auditSel.clear(); paint();
        toast(`↩️ ${rs.length}명 격리 해제 (미분류)`);
      };
    }
    auditRepaint = paint;
    paint();
  };

  // ---- 레거시 정리 — 거부·차단요청 태그 고객 파기(1회, PC purgeLegacyOnce와 동일 규칙)
  //      + 수신거부 태그 잔존 안전망(저장 전 앱 종료 대비 · 매 부팅) ----
  function purgeLegacyOnce() {
    let changed = false;
    queue.slice().forEach(c => {
      if (c.tag === '수신거부') {
        cpOptoutAdd({ phone: c.number, name: c.name || '' }, '수신거부', '부팅 시 잔존 정리');
        const nn = normNum(c.number);
        for (let i = queue.length - 1; i >= 0; i--) if (normNum(queue[i].number) === nn) queue.splice(i, 1);
        addTombstone(nn); changed = true;
      }
    });
    let flag = ''; try { flag = localStorage.getItem('cp_purge_refuse_v1') || ''; } catch (e) {}
    if (flag !== '1') {
      const targets = queue.filter(c => c.tag === '차단요청' || c.tag === '거부');
      targets.forEach(c => {
        if (c.tag === '차단요청') cpOptoutAdd({ phone: c.number, name: c.name || '' }, '차단요청', '레거시 일괄 정리');
        const nn = normNum(c.number);
        for (let i = queue.length - 1; i >= 0; i--) if (normNum(queue[i].number) === nn) queue.splice(i, 1);
        addTombstone(nn); changed = true;
      });
      if (targets.length) toast(`구버전 거부·차단요청 ${targets.length}명 정리(파기) — 재발신 방지 목록은 유지`, 3400);
      try { localStorage.setItem('cp_purge_refuse_v1', '1'); } catch (e) {}
    }
    if (changed) { save('cp_queue', queue); renderQueue(); try { renderCrm(); } catch (e) {} }
  }

  // ---- 부팅 ----
  loadOptout();
  purgeLegacyOnce();
  const srcBtn = document.getElementById('crmSrcBtn');
  if (srcBtn) srcBtn.onclick = () => openSrcAudit();
})();
