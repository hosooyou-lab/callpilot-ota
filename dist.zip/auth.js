// ============================================================
//  콜파일럿 모바일 — 설치 인증 (기기코드 = ANDROID_ID)
//
//  PC판과 동일한 ECDSA P-256 서명 검증. 앱엔 공개키만 → 위조 불가.
//  키발급기(개인키 보관)에 폰 기기코드를 넣어 인증키를 만들고, 앱에 붙여넣으면 활성화.
//  서명 형식은 PC판과 동일한 ieee-p1363(raw r||s) → WebCrypto ECDSA 가 그대로 검증.
//
//  ⚙ 지금은 ACTIVATION_REQUIRED=false → 어떤 기기도 잠기지 않음(내 폰 개발용).
//    남에게 배포할 때 true 로 바꾸고, 내 폰 기기코드는 OWNER_IDS 에 넣으면 자동 활성.
// ============================================================
(function () {
  const ACTIVATION_REQUIRED = false;        // 배포 시 true
  const OWNER_IDS = [];                      // 자동 활성화할 기기코드(내 폰). 예: ['a1b2c3...']

  // PC판 LICENSE_PUBKEY 와 동일한 공개키(SPKI DER, base64)
  const PUBKEY_SPKI_B64 =
    'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE37dMiJMFZzIPmKeqva3Sj3XF/7pY' +
    'dWb0nw9Kmn0No/InMOCwRpG5uX/Oho4lWb2gKGPfha2l9Xd4qWasZLhfqA==';

  function b64ToBytes(b64) {
    const bin = atob(String(b64 || '').replace(/\s+/g, ''));
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }

  async function verifyKey(deviceCode, authKey) {
    try {
      const spki = b64ToBytes(PUBKEY_SPKI_B64);
      const key = await crypto.subtle.importKey('spki', spki,
        { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      const sig = b64ToBytes(authKey);
      if (!sig.length) return false;
      const data = new TextEncoder().encode(String(deviceCode));
      return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sig, data);
    } catch (e) { return false; }
  }

  async function getDeviceCode() {
    try {
      const Cap = window.Capacitor;
      if (Cap && Cap.nativePromise) {
        const r = await Cap.nativePromise('CallPilotDialer', 'deviceId', {});
        return (r && r.id) ? r.id : 'na';
      }
    } catch (e) {}
    return 'preview-device';
  }

  function storedKey() { try { return localStorage.getItem('cp_license') || ''; } catch (e) { return ''; } }
  function storeKey(k) { try { localStorage.setItem('cp_license', k); } catch (e) {} }

  async function isActivated(deviceCode) {
    if (!ACTIVATION_REQUIRED) return true;
    if (OWNER_IDS.includes(deviceCode)) return true;
    const k = storedKey();
    return k ? await verifyKey(deviceCode, k) : false;
  }

  function showLock(deviceCode) {
    const wrap = document.createElement('div');
    wrap.id = 'cp-lock';
    wrap.style.cssText = 'position:fixed;inset:0;z-index:9999;background:#161310;color:#f0ece6;' +
      'display:flex;flex-direction:column;justify-content:center;padding:28px;gap:14px;font-size:16px';
    wrap.innerHTML =
      '<div style="font-size:22px;font-weight:800">🔒 콜파일럿 인증</div>' +
      '<div style="color:#a29a8f;line-height:1.5">이 기기코드를 관리자에게 보내면 인증키를 받습니다.</div>' +
      '<div style="background:#0f0d0a;border-radius:10px;padding:14px;font-family:monospace;font-size:15px;' +
      'word-break:break-all;user-select:all" id="cp-devcode">' + esc(deviceCode) + '</div>' +
      '<button id="cp-copycode" style="padding:10px;border-radius:8px;border:1px solid #3a352f;background:#1e1a16;color:#e8a84a">기기코드 복사</button>' +
      '<input id="cp-keyin" placeholder="인증키 붙여넣기" style="padding:12px;border-radius:8px;border:1px solid #3a352f;background:#0f0d0a;color:#fff;font-size:15px">' +
      '<button id="cp-activate" style="padding:14px;border-radius:8px;border:0;background:#c96442;color:#fff;font-weight:700;font-size:16px">활성화</button>' +
      '<div id="cp-lockmsg" style="color:#e06146;min-height:18px"></div>';
    document.body.appendChild(wrap);
    document.getElementById('cp-copycode').onclick = () => {
      try { navigator.clipboard.writeText(deviceCode); document.getElementById('cp-lockmsg').style.color = '#34b56e'; document.getElementById('cp-lockmsg').textContent = '복사됨'; } catch (e) {}
    };
    document.getElementById('cp-activate').onclick = async () => {
      const k = document.getElementById('cp-keyin').value.trim();
      const msg = document.getElementById('cp-lockmsg');
      if (await verifyKey(deviceCode, k)) { storeKey(k); location.reload(); }
      else { msg.style.color = '#e06146'; msg.textContent = '인증키가 올바르지 않습니다'; }
    };
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])); }

  // 앱보다 먼저 실행: 미인증이면 잠금. window.CPAuth.ready 로 app.js 가 상태 확인.
  window.CPAuth = { ready: false, locked: false, deviceCode: '' };
  (async () => {
    const dc = await getDeviceCode();
    window.CPAuth.deviceCode = dc;
    const ok = await isActivated(dc);
    window.CPAuth.locked = !ok;
    window.CPAuth.ready = true;
    if (!ok) showLock(dc);
    // 하단 기기코드 표시(개발/지원용) — 잠기지 않았을 때만
    else document.addEventListener('DOMContentLoaded', () => showDeviceFooter(dc));
    if (document.readyState !== 'loading' && ok) showDeviceFooter(dc);
  })();

  function showDeviceFooter(dc) {
    if (document.getElementById('cp-devfoot')) return;
    const f = document.createElement('div');
    f.id = 'cp-devfoot';
    f.style.cssText = 'text-align:center;color:#6f675d;font-size:11px;padding:8px 0 20px';
    f.textContent = '기기코드 ' + dc;
    const main = document.querySelector('main');
    if (main && main.parentNode) main.parentNode.insertBefore(f, main.nextSibling);
  }
})();
