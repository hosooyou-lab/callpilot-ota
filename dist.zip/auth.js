// ============================================================
//  콜파일럿 모바일 — 설치 인증 (기기코드 = ANDROID_ID)
//
//  PC판과 동일한 ECDSA P-256 서명 검증. 앱엔 공개키만 → 위조 불가.
//  키발급기(개인키 보관)에 폰 기기코드를 넣어 인증키를 만들고, 앱에 붙여넣으면 활성화.
//  서명 형식은 PC판과 동일한 ieee-p1363(raw r||s) → WebCrypto ECDSA 가 그대로 검증.
//
//  ⚙ 지금은 ACTIVATION_REQUIRED=false → 어떤 기기도 잠기지 않음(내 폰 개발용).
//    남에게 배포할 때 true 로 바꾸고, 내 폰 기기코드는 OWNER_IDS 에 넣으면 자동 활성.
// ============================================================
(function () {
  const ACTIVATION_REQUIRED = false;        // 배포 시 true
  const OWNER_IDS = [];                      // 자동 활성화할 기기코드(내 폰). 예: ['a1b2c3...']

  // PC판 LICENSE_PUBKEY 와 동일한 공개키(SPKI DER, base64)
  const PUBKEY_SPKI_B64 =
    'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE37dMiJMFZzIPmKeqva3Sj3XF/7pY' +
    'dWb0nw9Kmn0No/InMOCwRpG5uX/Oho4lWb2gKGPfha2l9Xd4qWasZLhfqA==';

  function b64ToBytes(b64) {
    const bin = atob(String(b64 || '').replace(/\s+/g, ''));
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }

  async function verifyKey(deviceCode, authKey) {
    try {
      const spki = b64ToBytes(PUBKEY_SPKI_B64);
      const key = await crypto.subtle.importKey('spki', spki,
        { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      const sig = b64ToBytes(authKey);
      if (!sig.length) return false;
      const data = new TextEncoder().encode(String(deviceCode));
      return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sig, data);
    } catch (e) { return false; }
  }

  async function getDeviceCode() {
    try {
      const Cap = window.Capacitor;
      if (Cap && Cap.nativePromise) {
        const r = await Cap.nativePromise('CallPilotDialer', 'deviceId', {});
        return (r && r.id) ? r.id : 'na';
      }
    } catch (e) {}
    return 'preview-device';
  }

  function storedKey() { try { return localStorage.getItem('cp_license') || ''; } catch (e) { return ''; } }
  function storeKey(k) { try { localStorage.setItem('cp_license', k); } catch (e) {} }
  // 🔗 LAN 공유 인증: 다른 기기(PC 등)에서 받은 (기기코드,키) 쌍. 공개키로 검증 가능.
  function storedShared() { try { return JSON.parse(localStorage.getItem('cp_license_shared') || 'null'); } catch (e) { return null; } }
  function storeShared(pair) { try { localStorage.setItem('cp_license_shared', JSON.stringify({ deviceCode: pair.deviceCode, key: pair.key })); } catch (e) {} }
  async function sharedValid() { const s = storedShared(); return (s && s.deviceCode && s.key) ? await verifyKey(s.deviceCode, s.key) : false; }

  async function isActivated(deviceCode) {
    if (!ACTIVATION_REQUIRED) return true;
    if (OWNER_IDS.includes(deviceCode)) return true;
    const k = storedKey();
    if (k && await verifyKey(deviceCode, k)) return true;
    return await sharedValid();   // 🔗 LAN으로 받은 공유 인증도 인정 (additive)
  }

  // 이 기기가 남에게 넘겨줄 인증(자기 키 우선 → 공유받은 것). sync.js 가 사용.
  async function getActivation() {
    const dc = window.CPAuth.deviceCode;
    const k = storedKey();
    if (k && await verifyKey(dc, k)) return { deviceCode: dc, key: k };
    const s = storedShared();
    if (s && s.deviceCode && s.key && await verifyKey(s.deviceCode, s.key)) return { deviceCode: s.deviceCode, key: s.key };
    return null;
  }
  // 다른 기기(PC 등)에서 받은 인증쌍 수락 — 내가 미인증이고 쌍이 유효하면 저장·잠금해제.
  async function acceptShared(pair) {
    if (!ACTIVATION_REQUIRED) return false;
    if (!pair || !pair.deviceCode || !pair.key) return false;
    if (await isActivated(window.CPAuth.deviceCode)) return false;
    if (!(await verifyKey(pair.deviceCode, pair.key))) return false;
    storeShared(pair);
    window.CPAuth.locked = false;
    if (document.getElementById('cp-lock')) location.reload();
    return true;
  }
  // 잠금화면에서 PC로 직접 한 번 요청해 인증 받기 (혼합콘텐츠 우회: 네이티브 HTTP)
  async function lockPostSync(url, body) {
    const Cap = window.Capacitor;
    if (Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise) {
      const r = await Cap.nativePromise('CapacitorHttp', 'request', { url, method: 'POST', headers: { 'Content-Type': 'application/json' }, data: body, responseType: 'json', connectTimeout: 5000, readTimeout: 5000 });
      let d = r && r.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} } return d || {};
    }
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return await res.json();
  }

  function showLock(deviceCode) {
    const wrap = document.createElement('div');
    wrap.id = 'cp-lock';
    wrap.style.cssText = 'position:fixed;inset:0;z-index:9999;background:#161310;color:#f0ece6;' +
      'display:flex;flex-direction:column;justify-content:center;padding:28px;gap:14px;font-size:16px';
    wrap.innerHTML =
      '<div style="font-size:18px;font-weight:800;display:flex;align-items:center;gap:6px">🔒 ' +
      '<span class="cp-brand-logo cp-brand-logo--lock" role="img" aria-label="CallPilot"></span>' +
      '<span class="cp-brand-fallback" hidden>CallPilot</span> 인증</div>' +
      '<div style="color:#a29a8f;line-height:1.5">이 기기코드를 관리자에게 보내면 인증키를 받습니다.</div>' +
      '<div style="background:#0f0d0a;border-radius:10px;padding:14px;font-family:monospace;font-size:15px;' +
      'word-break:break-all;user-select:all" id="cp-devcode">' + esc(deviceCode) + '</div>' +
      '<button id="cp-copycode" style="padding:10px;border-radius:8px;border:1px solid #3a352f;background:#1e1a16;color:#e8a84a">기기코드 복사</button>' +
      '<input id="cp-keyin" placeholder="인증키 붙여넣기" style="padding:12px;border-radius:8px;border:1px solid #3a352f;background:#0f0d0a;color:#fff;font-size:15px">' +
      '<button id="cp-activate" style="padding:14px;border-radius:8px;border:0;background:#c96442;color:#fff;font-weight:700;font-size:16px">활성화</button>' +
      '<div id="cp-lockmsg" style="color:#e06146;min-height:18px"></div>' +
      '<div style="border-top:1px solid #3a352f;margin-top:8px;padding-top:12px">' +
      '<div style="color:#a29a8f;font-size:13px;line-height:1.5;margin-bottom:8px">또는 온라인으로 관리자에게 인증 요청 (승인되면 자동으로 켜집니다):</div>' +
      '<button id="cp-reqonline" style="padding:12px;border-radius:8px;border:1px solid #c96442;background:#c96442;color:#fff;font-weight:700;font-size:15px;width:100%">📨 인증 요청 보내기</button>' +
      '<div id="cp-reqstatus" style="color:#a29a8f;font-size:13px;margin-top:8px;min-height:16px"></div>' +
      '</div>' +
      '<div style="border-top:1px solid #3a352f;margin-top:8px;padding-top:12px">' +
      '<div style="color:#a29a8f;font-size:13px;line-height:1.5;margin-bottom:6px">또는 이미 인증된 PC와 같은 wifi면 자동으로 받기 (한 번만 인증하면 됩니다):</div>' +
      '<input id="cp-pcip" inputmode="decimal" placeholder="PC 동기화 IP (예: 192.168.0.5)" style="padding:12px;border-radius:8px;border:1px solid #3a352f;background:#0f0d0a;color:#fff;font-size:15px;width:100%;box-sizing:border-box;margin-bottom:8px">' +
      '<button id="cp-getpc" style="padding:12px;border-radius:8px;border:1px solid #5a4520;background:#1e1a16;color:#e8a84a;font-weight:700;font-size:15px;width:100%">📡 PC에서 인증 받기</button>' +
      '</div>';
    document.body.appendChild(wrap);
    // 🖼 mask 미지원(구형 웹뷰) 폴백 — 로고 대신 "CallPilot" 텍스트 표시(로직엔 영향 없음)
    (function () {
      const ok = !!(window.CSS && CSS.supports && (CSS.supports('-webkit-mask-image', 'url(a)') || CSS.supports('mask-image', 'url(a)')));
      if (ok) return;
      const logo = wrap.querySelector('.cp-brand-logo'); const fb = wrap.querySelector('.cp-brand-fallback');
      if (logo) logo.hidden = true; if (fb) fb.hidden = false;
    })();
    document.getElementById('cp-getpc').onclick = async () => {
      const ip = (document.getElementById('cp-pcip').value || '').trim();
      const msg = document.getElementById('cp-lockmsg');
      if (!ip) { msg.style.color = '#e06146'; msg.textContent = 'PC IP를 입력하세요'; return; }
      msg.style.color = '#a29a8f'; msg.textContent = 'PC에 인증 요청 중…';
      try {
        const resp = await lockPostSync('http://' + ip + ':8787/sync', { customers: [], records: [], tombstones: [] });
        const a = resp && resp.activation;
        if (a && a.deviceCode && a.key && await verifyKey(a.deviceCode, a.key)) {
          storeShared(a); msg.style.color = '#34b56e'; msg.textContent = '인증됐어요!'; setTimeout(() => location.reload(), 600);
        } else { msg.style.color = '#e06146'; msg.textContent = 'PC 인증정보를 못 받았어요 (PC가 인증돼 있고 같은 wifi인지 확인)'; }
      } catch (e) { msg.style.color = '#e06146'; msg.textContent = 'PC 연결 실패 — IP·wifi를 확인하세요'; }
    };
    document.getElementById('cp-copycode').onclick = () => {
      try { navigator.clipboard.writeText(deviceCode); document.getElementById('cp-lockmsg').style.color = '#34b56e'; document.getElementById('cp-lockmsg').textContent = '복사됨'; } catch (e) {}
    };
    document.getElementById('cp-activate').onclick = async () => {
      const k = document.getElementById('cp-keyin').value.trim();
      const msg = document.getElementById('cp-lockmsg');
      if (await verifyKey(deviceCode, k)) { storeKey(k); location.reload(); }
      else { msg.style.color = '#e06146'; msg.textContent = '인증키가 올바르지 않습니다'; }
    };

    // 📨 온라인 인증 요청 → 승인 폴링(승인되면 자동 활성화). 서명은 관리자 기기에서만.
    let pollTimer = null;
    function startPolling() {
      const st = document.getElementById('cp-reqstatus');
      if (st) { st.style.color = '#a29a8f'; st.textContent = '승인 대기 중… 관리자가 승인하면 자동으로 켜집니다.'; }
      if (pollTimer) return;
      const tick = async () => {
        try {
          if (!window.CPSupa || !window.CPSupa.configured) return;
          const key = await window.CPSupa.pollActivation(deviceCode);
          if (key && await verifyKey(deviceCode, key)) {
            if (pollTimer) clearInterval(pollTimer);
            storeKey(key);
            try { localStorage.removeItem('cp_actv_requested'); } catch (e) {}
            location.reload();
          }
        } catch (e) {}
      };
      pollTimer = setInterval(tick, 5000);
      tick();
    }
    const reqBtn = document.getElementById('cp-reqonline');
    if (reqBtn) reqBtn.onclick = async () => {
      const st = document.getElementById('cp-reqstatus');
      if (!window.CPSupa || !window.CPSupa.configured) { if (st) { st.style.color = '#e06146'; st.textContent = '온라인 인증이 아직 설정되지 않았어요'; } return; }
      reqBtn.disabled = true; if (st) { st.style.color = '#a29a8f'; st.textContent = '요청 보내는 중…'; }
      try {
        const r = await window.CPSupa.requestActivation(deviceCode, '');
        if (r && r.ok) { try { localStorage.setItem('cp_actv_requested', '1'); } catch (e) {} startPolling(); }
        else { reqBtn.disabled = false; if (st) { st.style.color = '#e06146'; st.textContent = '요청 실패 — 인터넷 확인 후 다시'; } }
      } catch (e) { reqBtn.disabled = false; if (st) { st.style.color = '#e06146'; st.textContent = '요청 실패 — 인터넷을 확인하세요'; } }
    };
    // 이전에 요청했으면 잠금화면 다시 떠도 자동으로 폴링 재개
    try { if (localStorage.getItem('cp_actv_requested') && reqBtn) { reqBtn.disabled = true; startPolling(); } } catch (e) {}
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])); }

  // 앱보다 먼저 실행: 미인증이면 잠금. window.CPAuth.ready 로 app.js 가 상태 확인.
  window.CPAuth = { ready: false, locked: false, deviceCode: '', getActivation: getActivation, acceptShared: acceptShared, verifyKey: verifyKey };
  (async () => {
    const dc = await getDeviceCode();
    window.CPAuth.deviceCode = dc;
    const ok = await isActivated(dc);
    window.CPAuth.locked = !ok;
    window.CPAuth.ready = true;
    if (!ok) showLock(dc);
    // 하단 기기코드 표시(개발/지원용) — 잠기지 않았을 때만
    else document.addEventListener('DOMContentLoaded', () => showDeviceFooter(dc));
    if (document.readyState !== 'loading' && ok) showDeviceFooter(dc);
  })();

  function showDeviceFooter(dc) {
    if (document.getElementById('cp-devfoot')) return;
    const f = document.createElement('div');
    f.id = 'cp-devfoot';
    f.style.cssText = 'text-align:center;color:#6f675d;font-size:11px;padding:8px 0 20px';
    f.textContent = '기기코드 ' + dc;
    const main = document.querySelector('main');
    if (main && main.parentNode) main.parentNode.insertBefore(f, main.nextSibling);
  }
})();
