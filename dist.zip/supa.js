// ============================================================
//  콜파일럿 모바일 — Supabase 백엔드 클라이언트
//    · 인증 요청/승인 폴링 · 피드백 · 버전 조회
//  SDK 없이 REST(fetch / CapacitorHttp)로 호출. 공개 anon 키만 사용(앱 임베드 안전).
//  네이티브에선 CapacitorHttp(믹스드콘텐츠·CORS 회피), 브라우저에선 fetch 폴백.
//  개인 서명키는 관리자 콘솔에만 — 여기엔 절대 없음. 승인키는 그 기기에서만 유효(위조 불가).
// ============================================================
(function () {
  'use strict';
  const SUPA_URL = 'https://sihczrtbjxnrgeneyyhq.supabase.co';
  // anon public 키(공개키 — 앱에 넣어도 안전, 접근통제는 서버 RLS가 함)
  const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNpaGN6cnRianhucmdlbmV5eWhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0NDg2MDEsImV4cCI6MjA5NjAyNDYwMX0.udtMDESv6fFFyIJnpFN88vnZP9FXKpzakwsHLVv2kBU';
  const REST = SUPA_URL + '/rest/v1/';

  const Cap = window.Capacitor;
  const native = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise);

  async function req(method, path, body, extraHeaders) {
    const url = REST + path;
    const headers = Object.assign({
      'apikey': SUPA_KEY, 'Authorization': 'Bearer ' + SUPA_KEY,
      'Content-Type': 'application/json'
    }, extraHeaders || {});
    if (native) {
      const r = await Cap.nativePromise('CapacitorHttp', 'request', {
        url, method, headers, data: (body != null ? body : undefined),
        responseType: 'json', connectTimeout: 8000, readTimeout: 8000
      });
      let d = r && r.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} }
      return { ok: !!(r && r.status >= 200 && r.status < 300), status: r && r.status, data: d };
    }
    const res = await fetch(url, {
      method, headers, body: (body != null ? JSON.stringify(body) : undefined)
    });
    let d = null; try { d = await res.json(); } catch (e) {}
    return { ok: res.ok, status: res.status, data: d };
  }

  // 인증 요청 넣기 (기기코드 + 선택 라벨)
  async function requestActivation(deviceCode, label) {
    return req('POST', 'license_requests',
      { device_code: deviceCode, platform: 'mobile', label: label || '' },
      { 'Prefer': 'return=minimal' });
  }
  // 승인 폴링 → 승인키 있으면 문자열, 없으면 null
  async function pollActivation(deviceCode) {
    const p = 'license_requests?device_code=eq.' + encodeURIComponent(deviceCode) +
      '&status=eq.approved&select=approved_key,approved_at&order=approved_at.desc&limit=1';
    const r = await req('GET', p, null);
    if (r.ok && Array.isArray(r.data) && r.data[0] && r.data[0].approved_key) return r.data[0].approved_key;
    return null;
  }
  // 피드백 전송
  async function feedback(deviceCode, message) {
    return req('POST', 'feedback',
      { device_code: deviceCode || '', platform: 'mobile', message: message },
      { 'Prefer': 'return=minimal' });
  }
  // 버전 포인터 조회
  async function version(platform) {
    const r = await req('GET', 'app_versions?platform=eq.' + encodeURIComponent(platform) + '&select=*', null);
    if (r.ok && Array.isArray(r.data)) return r.data[0] || null;
    return null;
  }

  window.CPSupa = {
    configured: !!(SUPA_URL && SUPA_KEY),
    requestActivation, pollActivation, feedback, version
  };

  // ---------- ✍ 의견(피드백) 오버레이 ----------
  function openFeedback() {
    if (document.getElementById('cp-fb')) return;
    const dc = (window.CPAuth && window.CPAuth.deviceCode) || '';
    const w = document.createElement('div');
    w.id = 'cp-fb';
    w.style.cssText = 'position:fixed;inset:0;z-index:100060;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:24px';
    w.innerHTML =
      '<div style="background:#1e1a16;border:1px solid #3a352f;border-radius:14px;padding:18px;width:100%;max-width:420px">' +
      '<div style="font-size:17px;font-weight:800;color:#f0ece6;margin-bottom:10px">✍ 의견 보내기</div>' +
      '<textarea id="cp-fb-txt" rows="4" placeholder="불편한 점·건의 무엇이든 적어주세요" style="width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #3a352f;background:#0f0d0a;color:#fff;font-size:15px"></textarea>' +
      '<div id="cp-fb-msg" style="color:#a29a8f;font-size:13px;min-height:16px;margin-top:6px"></div>' +
      '<div style="display:flex;gap:8px;margin-top:8px">' +
      '<button id="cp-fb-send" style="flex:1;padding:12px;border-radius:8px;border:0;background:#c96442;color:#fff;font-weight:700">보내기</button>' +
      '<button id="cp-fb-x" style="padding:12px 16px;border-radius:8px;border:1px solid #3a352f;background:#1e1a16;color:#a29a8f">닫기</button>' +
      '</div></div>';
    document.body.appendChild(w);
    document.getElementById('cp-fb-x').onclick = () => w.remove();
    document.getElementById('cp-fb-send').onclick = async () => {
      const btn = document.getElementById('cp-fb-send');
      if (btn.disabled) return;                    // 중복 전송 방지(빠른 다중 탭)
      const txt = (document.getElementById('cp-fb-txt').value || '').trim();
      const msg = document.getElementById('cp-fb-msg');
      if (!txt) { msg.style.color = '#e06146'; msg.textContent = '내용을 입력하세요'; return; }
      if (!window.CPSupa.configured) { msg.style.color = '#e06146'; msg.textContent = '온라인 기능이 아직 설정되지 않았어요'; return; }
      btn.disabled = true;
      msg.style.color = '#a29a8f'; msg.textContent = '보내는 중…';
      try {
        const r = await feedback(dc, txt);
        if (r && r.ok) { msg.style.color = '#34b56e'; msg.textContent = '보냈어요. 감사합니다!'; setTimeout(() => w.remove(), 900); }
        else { btn.disabled = false; msg.style.color = '#e06146'; msg.textContent = '전송 실패 — 인터넷 확인 후 다시'; }
      } catch (e) { btn.disabled = false; msg.style.color = '#e06146'; msg.textContent = '전송 실패 — 인터넷을 확인하세요'; }
    };
  }
  window.CPSupa.openFeedback = openFeedback;

  function wireFeedbackBtn() { const b = document.getElementById('feedbackBtn'); if (b) b.onclick = openFeedback; }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wireFeedbackBtn);
  else wireFeedbackBtn();
})();
