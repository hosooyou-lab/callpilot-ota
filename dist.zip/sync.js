// ============================================================
//  콜파일럿 모바일 — 같은 wifi LAN 동기화 (PC ↔ 폰)
//
//  클라우드 없이, 노트북 콜파일럿이 켜져 있고 같은 wifi면 서로 동기화.
//   - 폰이 노트북(http://IP:8787/sync)에 POST → 서로 병합해서 응답 → 폰도 병합.
//   - 5~10초마다 반복. 고객은 id+수정시각 LWW + 번호 dedup + 삭제(tombstone) 전파.
//   - 통화기록은 id 기준 합집합(누적).
//  app.js 다음에 로드 → 전역 queue/records/save/render... 를 그대로 사용.
// ============================================================
(function () {
  const DEF_PORT = 8787;
  const POLL_MS = 7000;
  let timer = null, busy = false;

  // 앱(WebView)은 https 화면이라 http 로컬주소로 fetch하면 "혼합 콘텐츠"로 막힌다.
  // → 네이티브 HTTP(CapacitorHttp, 코어 내장)로 보내 우회한다. 미리보기(브라우저)는 fetch 폴백.
  const Cap = window.Capacitor;
  const nativeHttp = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise);
  async function postSync(url, bodyObj) {
    if (nativeHttp) {
      const r = await Cap.nativePromise('CapacitorHttp', 'request', {
        url, method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        data: bodyObj, responseType: 'json',
        connectTimeout: 5000, readTimeout: 5000,
      });
      if (r && r.status === 403) { const e = new Error('pair'); e.pair = true; throw e; }
      if (!r || (r.status && (r.status < 200 || r.status >= 300))) throw new Error('http ' + (r && r.status));
      let d = r.data;
      if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} }
      return d || {};
    }
    const ctrl = new AbortController();
    const to = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal, body: JSON.stringify(bodyObj) });
    clearTimeout(to);
    if (res.status === 403) { const e = new Error('pair'); e.pair = true; throw e; }
    if (!res.ok) throw new Error('http ' + res.status);
    return await res.json();
  }

  function cfg() { try { return JSON.parse(localStorage.getItem('cp_sync_pc') || 'null'); } catch (e) { return null; } }
  function setCfg(v) { if (v) localStorage.setItem('cp_sync_pc', JSON.stringify(v)); else localStorage.removeItem('cp_sync_pc'); }
  function status(t) { const e = document.getElementById('syncStatus'); if (e) e.textContent = t; }

  function localCustomers() {
    return queue.map(q => ({ id: q.id, name: q.name, number: normNum(q.number), updatedAt: q.updatedAt || nowIso(), done: !!q.done }));
  }
  function localRecords() {
    return records.map(r => ({ id: r.id, number: normNum(r.number), name: r.name, tag: r.tag, memo: r.memo, dialAt: r.dialAt, durationSec: r.durationSec || 0, updatedAt: r.time || r.dialAt }));
  }
  function localTombs() { return (typeof tombstones !== 'undefined') ? tombstones : []; }

  // 고객 병합: id LWW → 번호 dedup(최신) → tombstone 적용, 로컬 done 보존
  function mergeCustomers(remote, remoteTombs) {
    const byId = new Map();
    const put = c => { const ex = byId.get(c.id); if (!ex || (c.updatedAt || '') > (ex.updatedAt || '')) byId.set(c.id, c); };
    queue.forEach(q => put({ id: q.id, name: q.name, number: normNum(q.number), updatedAt: q.updatedAt || nowIso(), done: !!q.done }));
    (remote || []).forEach(c => c && c.id && put({ id: c.id, name: c.name, number: normNum(c.number), updatedAt: c.updatedAt || '', done: !!c.done }));
    const byNum = new Map();
    [...byId.values()].sort((a, b) => (a.updatedAt || '').localeCompare(b.updatedAt || '')).forEach(c => byNum.set(c.number, c));
    let list = [...byNum.values()];
    const tombByNum = new Map();
    [...localTombs(), ...(remoteTombs || [])].forEach(t => { if (!t) return; const n = normNum(t.number); const ex = tombByNum.get(n); if (!ex || t.at > ex.at) tombByNum.set(n, { number: n, at: t.at }); });
    list = list.filter(c => { const t = tombByNum.get(c.number); return !(t && t.at >= (c.updatedAt || '')); });
    const localByNum = new Map(queue.map(q => [normNum(q.number), q]));
    return {
      // done 은 LWW 승자(c.done) 사용 → 한쪽에서 통화한 번호가 다른 쪽에서도 '통화함'으로. tag 는 로컬 표시용 보존.
      list: list.map(c => { const loc = localByNum.get(c.number) || {}; return { id: c.id, name: c.name, number: c.number, updatedAt: c.updatedAt, done: !!c.done, tag: loc.tag || '' }; }),
      tombs: [...tombByNum.values()],
    };
  }
  // 통화기록 병합: id 합집합
  function mergeRecords(remote) {
    const byId = new Map();
    records.forEach(r => byId.set(r.id, r));
    (remote || []).forEach(r => { if (r && r.id && !byId.has(r.id)) byId.set(r.id, { id: r.id, number: normNum(r.number), name: r.name, tag: r.tag, memo: r.memo, dialAt: r.dialAt, durationSec: r.durationSec || 0, time: r.updatedAt || r.dialAt }); });
    return [...byId.values()];
  }

  async function doSync() {
    const c = cfg(); if (!c || !c.host || busy) return;
    busy = true;
    try {
      const url = `http://${c.host}:${c.port || DEF_PORT}/sync`;
      let activation = null;
      try { if (window.CPAuth && window.CPAuth.getActivation) activation = await window.CPAuth.getActivation(); } catch (e) {}
      const m = await postSync(url, { pairCode: c.code || '', customers: localCustomers(), records: localRecords(), tombstones: localTombs(), activation: activation });
      // 🔗 상대(PC 등) 인증을 받아, 내가 잠겨 있으면 자동 인증 (1회 입력으로 공유)
      try { if (m && m.activation && window.CPAuth && window.CPAuth.locked && window.CPAuth.acceptShared) await window.CPAuth.acceptShared(m.activation); } catch (e) {}
      const mc = mergeCustomers(m.customers, m.tombstones);
      queue.length = 0; mc.list.forEach(x => queue.push(x));
      tombstones = mc.tombs;
      const mr = mergeRecords(m.records);
      records.length = 0; mr.forEach(x => records.push(x));
      save('cp_queue', queue); save('cp_records', records); save('cp_tombstones', tombstones);
      renderQueue(); renderRecords();
      status('연결됨 · ' + new Date().toLocaleTimeString('ko-KR'));
    } catch (e) {
      if (e && e.pair) { status('❌ 페어링 코드 불일치 — 노트북 코드 확인'); stop(); }  // 다른 PC거나 코드 오타 → 헛되이 재시도 안 함
      else status('연결 안됨 — 노트북 콜파일럿·같은 wifi 확인');
    }
    finally { busy = false; }
  }

  function start() { stop(); if (cfg()) { doSync(); timer = setInterval(doSync, POLL_MS); } }
  function stop() { if (timer) clearInterval(timer); timer = null; }

  function bind() {
    const host = document.getElementById('syncHost'), port = document.getElementById('syncPort'), code = document.getElementById('syncCode');
    const c = cfg(); if (c) { if (host) host.value = c.host; if (port) port.value = c.port || DEF_PORT; if (code) code.value = c.code || ''; }
    const conn = document.getElementById('syncConnect');
    if (conn) conn.onclick = () => {
      const h = (host.value || '').trim();
      const cd = (code && code.value || '').trim().toUpperCase();
      if (!h) { status('노트북 IP를 입력하세요 (예: 192.168.0.5)'); return; }
      if (!cd) { status('페어링 코드를 입력하세요 (노트북 우하단)'); return; }
      setCfg({ host: h, port: parseInt(port.value) || DEF_PORT, code: cd });
      status('연결 시도 중…'); start();
    };
    const disc = document.getElementById('syncDisconnect');
    if (disc) disc.onclick = () => { setCfg(null); stop(); status('동기화 꺼짐'); };
    // 자동 재연결: wifi 복구·앱 복귀 시 즉시 동기화(주소는 저장돼 있으므로 계속 유지)
    window.addEventListener('online', () => { if (cfg()) start(); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && cfg()) doSync(); });
    if (cfg()) start(); else status('꺼짐');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
