// ============================================================
//  콜파일럿 모바일 — 배분 CRM 로그인 게이트 (상담사 아이디·비번)
//    PC판(main.js crmlogin:submit)과 동일한 서버 흐름을 그대로 씁니다.
//    · 로그인 아이디(한글 가능) → 합성 이메일 매핑 RPC(cp_email_for_login)
//      → Supabase Auth 비밀번호 로그인 → cp_profiles 로 role/status 확인
//    · 세션은 localStorage(cp_crm_session)에 저장 — 토큰 + 마지막 정상확인시각(lastOkAt)
//    · 부팅 시 세션이 있으면 오버레이 없이 시작하고 "조용히" 재검증만 한다.
//      401이면 refresh_token 으로 한 번 갱신 재시도, 그래도 안 되면 재로그인 요구.
//      완전 오프라인(네트워크 자체 실패)이면 lastOkAt 기준 3일까지는 봐준다.
//    · 라이선스 잠금(auth.js #cp-lock, z-index 9999)이 항상 최우선 — 이 오버레이는
//      그보다 낮은 z-index(style.css .cp-crm-gate 참고)로, 동시에 뜨면 라이선스 잠금이 위에 온다.
//    · 아이디만 localStorage(cp_crm_login_id)에 저장 — 비밀번호는 절대 저장하지 않는다.
// ============================================================
(function () {
  'use strict';
  const SUPA_URL = 'https://sihczrtbjxnrgeneyyhq.supabase.co';
  // anon(publishable) 공개키 — supa.js와 동일한 키(공개해도 안전, 접근통제는 서버 RLS가 함)
  const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNpaGN6cnRianhucmdlbmV5eWhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0NDg2MDEsImV4cCI6MjA5NjAyNDYwMX0.udtMDESv6fFFyIJnpFN88vnZP9FXKpzakwsHLVv2kBU';
  const REST = SUPA_URL + '/rest/v1/';
  const AUTH = SUPA_URL + '/auth/v1/';

  const SESSION_KEY = 'cp_crm_session';
  const LOGINID_KEY = 'cp_crm_login_id';
  const GRACE_MS = 3 * 24 * 60 * 60 * 1000;   // 오프라인 유예 3일

  const Cap = window.Capacitor;
  const native = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise);

  // ── 서버 요청 — supa.js와 동일 패턴(네이티브: CapacitorHttp, 브라우저: fetch) ──
  // status: 0 이면 네트워크 자체 실패(오프라인 판정용). 그 외엔 실제 HTTP status.
  async function req(base, method, path, body, extraHeaders) {
    const url = base + path;
    const headers = Object.assign({ 'apikey': SUPA_KEY, 'Content-Type': 'application/json' }, extraHeaders || {});
    try {
      if (native) {
        const r = await Cap.nativePromise('CapacitorHttp', 'request', {
          url, method, headers, data: (body != null ? body : undefined),
          responseType: 'json', connectTimeout: 8000, readTimeout: 8000
        });
        let d = r && r.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) {} }
        const status = (r && r.status) || 0;
        return { ok: status >= 200 && status < 300, status, data: d };
      }
      const res = await fetch(url, { method, headers, body: (body != null ? JSON.stringify(body) : undefined) });
      let d = null; try { d = await res.json(); } catch (e) {}
      return { ok: res.ok, status: res.status, data: d };
    } catch (e) {
      return { ok: false, status: 0, data: null };   // 연결 자체 실패(오프라인·타임아웃 등)
    }
  }
  function restReq(method, path, body, headers) { return req(REST, method, path, body, headers); }
  // /auth/v1 은 /rest/v1과 별개 베이스라 supa.js 헬퍼를 못 쓰므로 같은 패턴으로 여기서 직접 처리
  function authReq(method, path, body, headers) { return req(AUTH, method, path, body, headers); }

  // JWT payload에서 sub(=user id)만 꺼냄(서명검증 없음 — 곧바로 서버에 다시 물어 확인하므로 위조돼도 무해)
  function decodeJwtSub(token) {
    try {
      const parts = String(token || '').split('.');
      if (parts.length < 2) return null;
      let b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      while (b64.length % 4) b64 += '=';
      const payload = JSON.parse(atob(b64));
      return (payload && payload.sub) || null;
    } catch (e) { return null; }
  }

  // ── 세션/아이디 저장 (localStorage) ──
  function readSession() { try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch (e) { return null; } }
  function saveSession(s) { try { localStorage.setItem(SESSION_KEY, JSON.stringify(s)); } catch (e) {} }
  function clearSession() { try { localStorage.removeItem(SESSION_KEY); } catch (e) {} }
  function readLoginId() { try { return localStorage.getItem(LOGINID_KEY) || ''; } catch (e) { return ''; } }
  function saveLoginId(id) { try { localStorage.setItem(LOGINID_KEY, id || ''); } catch (e) {} }
  function clearLoginId() { try { localStorage.removeItem(LOGINID_KEY); } catch (e) {} }
  // '아이디 저장' 체크 상태 기억 — 기본 켬. 꺼두면 다음 로그인 화면에서도 꺼진 채로 유지.
  const REMEMBER_KEY = 'cp_crm_remember';
  function rememberPref() { try { return localStorage.getItem(REMEMBER_KEY) !== '0'; } catch (e) { return true; } }
  function saveRememberPref(on) { try { localStorage.setItem(REMEMBER_KEY, on ? '1' : '0'); } catch (e) {} }

  // cp_profiles 에서 내 role/status/name 확인 → { ok, status(HTTP코드), data }
  function fetchProfile(userId, accessToken) {
    return restReq('GET', 'cp_profiles?id=eq.' + encodeURIComponent(userId) + '&select=name,role,status', null,
      { 'Authorization': 'Bearer ' + accessToken });
  }

  // 아이디→합성이메일 매핑 → 비밀번호 로그인 → 프로필 확인까지 한 번에 처리
  async function doLogin(loginIdRaw, passwordRaw) {
    const loginId = String(loginIdRaw || '').trim();
    const password = String(passwordRaw || '');
    if (!loginId) return { ok: false, message: '아이디를 입력하세요.' };
    if (!password) return { ok: false, message: '비밀번호를 입력하세요.' };

    let email;
    if (loginId.includes('@')) {
      email = loginId;   // 이메일 계정(예: 마스터)은 바로 로그인
    } else {
      const emailR = await restReq('POST', 'rpc/cp_email_for_login', { p_login_id: loginId });
      if (emailR.status === 0) return { ok: false, message: '인터넷 연결을 확인해 주세요.' };
      if (!emailR.ok || typeof emailR.data !== 'string' || !emailR.data) return { ok: false, message: '아이디를 찾을 수 없습니다.' };
      email = emailR.data;
    }

    const authR = await authReq('POST', 'token?grant_type=password', { email, password });
    if (authR.status === 0) return { ok: false, message: '인터넷 연결을 확인해 주세요.' };
    if (!authR.ok || !authR.data || !authR.data.access_token) return { ok: false, message: '아이디 또는 비밀번호가 올바르지 않습니다.' };

    const userId = (authR.data.user && authR.data.user.id) || decodeJwtSub(authR.data.access_token);
    const profR = await fetchProfile(userId, authR.data.access_token);
    if (profR.status === 0) return { ok: false, message: '인터넷 연결을 확인해 주세요.' };
    if (!profR.ok || !Array.isArray(profR.data) || !profR.data[0]) return { ok: false, message: '계정 정보를 찾을 수 없습니다. 관리자에게 문의하세요.' };
    const row = profR.data[0];
    if (row.status === 'blocked') return { ok: false, message: '관리자가 계정을 차단했습니다.' };
    if (row.status !== 'active') return { ok: false, message: '사용할 수 없는 계정 상태입니다. 관리자에게 문의하세요.' };

    saveSession({
      access_token: authR.data.access_token,
      refresh_token: authR.data.refresh_token,
      user_id: userId,
      login_id: loginId,
      name: row.name,
      role: row.role,
      lastOkAt: Date.now()
    });
    // 아이디 저장 여부는 로그인 화면의 '아이디 저장' 체크박스가 결정(submit 쪽에서 처리)
    return { ok: true };
  }

  // refresh_token 으로 access_token 갱신 — 성공 시 갱신된 세션(저장까지 완료), 실패 시 null
  async function tryRefresh(session) {
    const r = await authReq('POST', 'token?grant_type=refresh_token', { refresh_token: session.refresh_token });
    if (r.status === 0 || !r.ok || !r.data || !r.data.access_token) return null;
    const updated = Object.assign({}, session, {
      access_token: r.data.access_token,
      refresh_token: r.data.refresh_token || session.refresh_token
    });
    saveSession(updated);
    return updated;
  }

  // 부팅 시 저장된 세션을 "조용히" 재검증. 통과하면 아무 표시 없이 lastOkAt만 갱신,
  // 실패하면 사유별 안내와 함께 로그인 오버레이를 띄운다. (refreshed: 401 재시도 1회 제한용)
  async function revalidate(session, refreshed) {
    const r = await fetchProfile(session.user_id, session.access_token);
    if (r.status === 0) {
      const last = session.lastOkAt || 0;
      if (Date.now() - last < GRACE_MS) return;   // 오프라인 유예 기간 내 — 조용히 통과
      showGate('인터넷에 연결한 뒤 다시 로그인해 주세요.');
      return;
    }
    if (r.status === 401 || r.status === 403) {
      if (refreshed) { clearSession(); showGate('세션이 만료됐어요. 다시 로그인해 주세요.'); return; }
      const next = await tryRefresh(session);
      if (next) { await revalidate(next, true); return; }
      clearSession(); showGate('세션이 만료됐어요. 다시 로그인해 주세요.');
      return;
    }
    if (!r.ok || !Array.isArray(r.data) || !r.data[0]) {
      clearSession(); showGate('계정 정보를 확인할 수 없습니다. 관리자에게 문의하세요.');
      return;
    }
    const row = r.data[0];
    if (row.status === 'blocked') { clearSession(); showGate('관리자가 계정을 차단했습니다.'); return; }
    if (row.status !== 'active') { clearSession(); showGate('사용할 수 없는 계정 상태입니다. 관리자에게 문의하세요.'); return; }
    session.lastOkAt = Date.now();
    session.name = row.name; session.role = row.role;
    saveSession(session);
    hideGate();   // 이미 떠 있었다면(드문 경우) 정상 확인됐으니 닫아둔다
  }

  // mask 미지원(구형 웹뷰) 폴백 — 로고를 숨기고 "CallPilot" 텍스트를 대신 보여줌
  function applyBrandFallback(logoEl, fallbackEl) {
    const ok = !!(window.CSS && CSS.supports && (CSS.supports('-webkit-mask-image', 'url(a)') || CSS.supports('mask-image', 'url(a)')));
    if (ok) return;
    if (logoEl) logoEl.hidden = true;
    if (fallbackEl) fallbackEl.hidden = false;
  }

  // ── 오버레이 UI (전체화면, 라이선스 잠금보다 낮은 z-index — style.css .cp-crm-gate) ──
  let gate = null;   // { el, idEl, pwEl, errEl, noticeEl, goBtn }

  function buildGate() {
    const el = document.createElement('div');
    el.className = 'cp-crm-gate';
    el.id = 'cp-crm-gate';

    const box = document.createElement('div');
    box.className = 'cp-crm-box';

    const brandLogo = document.createElement('span');
    brandLogo.className = 'cp-brand-logo cp-brand-logo--login';
    brandLogo.setAttribute('role', 'img'); brandLogo.setAttribute('aria-label', 'CallPilot');
    const brandFallback = document.createElement('span');
    brandFallback.className = 'cp-brand-fallback'; brandFallback.hidden = true; brandFallback.textContent = 'CallPilot';
    applyBrandFallback(brandLogo, brandFallback);
    const titleEl = document.createElement('div');
    titleEl.className = 'cp-crm-title'; titleEl.textContent = '상담사 로그인';
    box.appendChild(brandLogo); box.appendChild(brandFallback); box.appendChild(titleEl);

    const noticeEl = document.createElement('div');
    noticeEl.className = 'cp-crm-notice'; noticeEl.id = 'cp-crm-notice'; noticeEl.hidden = true;

    const idField = document.createElement('div');
    idField.className = 'cp-crm-field';
    idField.innerHTML = '<label for="cp-crm-id">아이디 (또는 이메일)</label>';
    const idEl = document.createElement('input');
    idEl.type = 'text'; idEl.id = 'cp-crm-id'; idEl.placeholder = '아이디 또는 이메일 입력';
    idEl.autocomplete = 'username';
    idField.appendChild(idEl);

    const pwField = document.createElement('div');
    pwField.className = 'cp-crm-field';
    pwField.innerHTML = '<label for="cp-crm-pw">비밀번호</label>';
    const pwEl = document.createElement('input');
    pwEl.type = 'password'; pwEl.id = 'cp-crm-pw'; pwEl.placeholder = '비밀번호 입력';
    pwEl.autocomplete = 'off';
    pwField.appendChild(pwEl);

    // ☑ 아이디 저장 (비밀번호는 어떤 경우에도 저장 안 함)
    const rememberWrap = document.createElement('label');
    rememberWrap.className = 'cp-crm-remember';
    rememberWrap.htmlFor = 'cp-crm-remember';
    const rememberEl = document.createElement('input');
    rememberEl.type = 'checkbox'; rememberEl.id = 'cp-crm-remember';
    rememberEl.checked = rememberPref();
    rememberWrap.appendChild(rememberEl);
    rememberWrap.appendChild(document.createTextNode(' 아이디 저장'));

    const errEl = document.createElement('div');
    errEl.className = 'cp-crm-err'; errEl.id = 'cp-crm-err';

    const goBtn = document.createElement('button');
    goBtn.type = 'button';
    goBtn.className = 'btn primary cp-crm-go'; goBtn.id = 'cp-crm-go';
    goBtn.textContent = '로그인';

    box.appendChild(noticeEl);
    box.appendChild(idField);
    box.appendChild(pwField);
    box.appendChild(rememberWrap);
    box.appendChild(errEl);
    box.appendChild(goBtn);
    el.appendChild(box);
    document.body.appendChild(el);

    async function submit() {
      if (goBtn.disabled) return;
      const loginId = (idEl.value || '').trim();
      const password = pwEl.value || '';
      if (!loginId) { errEl.textContent = '아이디를 입력하세요.'; idEl.focus(); return; }
      if (!password) { errEl.textContent = '비밀번호를 입력하세요.'; pwEl.focus(); return; }
      goBtn.disabled = true; idEl.disabled = true; pwEl.disabled = true;
      const prevLabel = goBtn.textContent;
      goBtn.textContent = '확인 중…';
      errEl.textContent = '';
      let result;
      try { result = await doLogin(loginId, password); }
      catch (e) { result = { ok: false, message: '로그인 처리 중 오류가 발생했습니다.' }; }
      if (result && result.ok) {
        saveRememberPref(rememberEl.checked);
        if (rememberEl.checked) saveLoginId(loginId); else clearLoginId();
        hideGate(); return;
      }
      goBtn.disabled = false; idEl.disabled = false; pwEl.disabled = false;
      goBtn.textContent = prevLabel;
      errEl.textContent = (result && result.message) || '로그인할 수 없습니다.';
      pwEl.focus();
    }
    goBtn.onclick = submit;
    idEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') pwEl.focus(); });
    pwEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });

    return { el: el, idEl: idEl, pwEl: pwEl, errEl: errEl, noticeEl: noticeEl, goBtn: goBtn, rememberEl: rememberEl };
  }

  function showGate(notice) {
    if (!gate) gate = buildGate();
    if (notice) { gate.noticeEl.textContent = notice; gate.noticeEl.hidden = false; }
    else { gate.noticeEl.hidden = true; gate.noticeEl.textContent = ''; }
    gate.errEl.textContent = '';
    gate.pwEl.value = '';
    gate.idEl.value = readLoginId();
    gate.rememberEl.checked = rememberPref();
    // 이전 로그인 성공 때 disabled 로 남은 상태 복구 — 안 하면 로그아웃 후 재로그인 버튼이 죽는다(실측)
    gate.goBtn.disabled = false; gate.idEl.disabled = false; gate.pwEl.disabled = false;
    gate.goBtn.textContent = '로그인';
    gate.el.style.display = 'flex';
    setTimeout(function () {
      if (gate.idEl.value) gate.pwEl.focus(); else gate.idEl.focus();
    }, 30);
  }
  function hideGate() { if (gate) gate.el.style.display = 'none'; }

  // ── 공개 API ──
  window.CPCRM = {
    session: function () { return readSession(); },
    // 설정/더보기 화면이 생기면 '로그아웃(아이디: xxx)' 항목에서 호출하면 됨
    logout: function () { clearSession(); showGate(); }
  };

  // ── 부팅 게이트 ──
  // 정책(사용자 요청 2026-07-22): 앱을 껐다 켤 때마다 항상 다시 로그인.
  //   이 스크립트가 새로 실행되는 시점 = 콜드 스타트(앱 종료 후 재실행)뿐이고,
  //   홈으로 잠깐 나갔다 복귀(백그라운드→포그라운드)할 땐 재실행되지 않아 로그인이 유지된다.
  //   → 저장된 세션이 있어도 자동 로그인하지 않고, 지운 뒤 로그인 화면을 띄운다.
  //   아이디는 'cp_crm_login_id'에 따로 저장돼 있어 그대로 자동으로 채워진다(비밀번호만 재입력).
  //   (참고: 이 정책상 revalidate()/tryRefresh()/GRACE_MS 조용한 재검증 경로는 더 이상 타지 않는다.)
  (function boot() {
    clearSession();   // 남아 있던 세션 폐기 → 자동 로그인 차단
    showGate();
  })();
})();
