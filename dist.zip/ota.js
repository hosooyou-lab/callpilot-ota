// ============================================================
//  콜파일럿 모바일 — 웹 자동 업데이트 (OTA, 무료 self-hosted)
//
//  @capgo/capacitor-updater(오픈소스) 를 클라우드 없이 사용.
//  공개 repo(callpilot-ota)의 update.json 을 확인해, 새 웹 번들이 있으면
//  내려받아 적용 → 재설치 없이 화면·로직 변경이 폰에 자동 반영.
//  (네이티브 변경은 여전히 APK 재설치 필요 → minNativeCode 로 안전장치)
//
//  안전장치:
//   - notifyAppReady(): 새 번들이 정상 실행됐음을 알림(10초 내 미호출 시 자동 롤백).
//   - 매니페스트/네트워크 실패 시 조용히 내장 번들로 계속 실행(앱 안 깨짐).
//   - minNativeCode > 현재 APK 버전이면 적용 안 함(웹이 없는 네이티브 호출→크래시 방지).
// ============================================================
(function () {
  const OTA_WEB_VERSION = '1.0.7';   // 이 내장 번들의 웹 버전. 새 번들 배포 시 올림.
  const MANIFEST_URL = 'https://raw.githubusercontent.com/hosooyou-lab/callpilot-ota/main/update.json';

  const Cap = window.Capacitor;
  const native = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise);
  function up(method, opts) { return Cap.nativePromise('CapacitorUpdater', method, opts || {}); }

  window.CPOta = { webVersion: OTA_WEB_VERSION, status: 'idle' };

  async function nativeCode() {
    try { const r = await Cap.nativePromise('CallPilotDialer', 'nativeInfo', {}); return (r && r.versionCode) || 0; }
    catch (e) { return 0; }
  }

  async function run() {
    if (!native) return;
    // 1) 현재 번들 정상 실행 확인(롤백 방지) — 가능한 한 이르게
    try { await up('notifyAppReady'); } catch (e) {}

    try {
      const res = await fetch(MANIFEST_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) return;
      const m = await res.json();               // {webVersion, url, checksum?, minNativeCode}
      if (!m || !m.webVersion || !m.url) return;
      if (m.webVersion === OTA_WEB_VERSION) return;             // 이미 최신
      const nc = await nativeCode();
      if (m.minNativeCode && nc && m.minNativeCode > nc) {      // 네이티브가 오래됨 → APK 재설치 필요
        window.CPOta.status = 'need-apk';
        return;
      }
      window.CPOta.status = 'downloading';
      const dl = { version: m.webVersion, url: m.url };
      if (m.checksum) dl.checksum = m.checksum;
      const b = await up('download', dl);
      if (b && b.id) {
        window.CPOta.status = 'applying';
        await up('set', { id: b.id });          // 새 번들로 전환(자동 reload)
      }
    } catch (e) { /* 실패 시 내장 번들로 계속 */ }
  }

  // 앱 로드 직후 실행(비차단)
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
