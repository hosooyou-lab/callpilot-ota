// ============================================================
//  콜파일럿 모바일 — 웹 자동 업데이트 (OTA, 무료 self-hosted)
//
//  @capgo/capacitor-updater(오픈소스) 를 클라우드 없이 사용.
//  공개 repo(callpilot-ota)의 update.json 을 확인해, 새 웹 번들이 있으면
//  내려받아 적용 → 재설치 없이 화면·로직 변경이 폰에 자동 반영.
//  (네이티브 변경은 여전히 APK 재설치 필요 → minNativeCode 로 안전장치)
//
//  안전장치:
//   - notifyAppReady(): 새 번들이 정상 실행됐음을 알림(10초 내 미호출 시 자동 롤백).
//   - 매니페스트/네트워크 실패 시 조용히 내장 번들로 계속 실행(앱 안 깨짐).
//   - minNativeCode > 현재 APK 버전이면 적용 안 함(웹이 없는 네이티브 호출→크래시 방지).
// ============================================================
(function () {
  const OTA_WEB_VERSION = '1.0.65';   // 이 내장 번들의 웹 버전. 새 번들 배포 시 올림. (1.0.65 = 발신 앞번호(투넘버) 설정)
  const MANIFEST_URL = 'https://raw.githubusercontent.com/hosooyou-lab/callpilot-ota/main/update.json';
  const INSTALLER_MIN = 999999;       // 슬림빌드부터 REQUEST_INSTALL_PACKAGES 제거 → 인앱 자동설치 불가, 항상 수동설치(URL 열기)로 안내

  // 버전 비교: a>b → 양수, a<b → 음수, 같으면 0. ("1.0.43" vs "1.0.42")
  function cmpVer(a, b) {
    const pa = String(a || '').split('.').map(x => parseInt(x, 10) || 0);
    const pb = String(b || '').split('.').map(x => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d; }
    return 0;
  }

  const Cap = window.Capacitor;
  const native = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.nativePromise);
  function up(method, opts) { return Cap.nativePromise('CapacitorUpdater', method, opts || {}); }

  window.CPOta = { webVersion: OTA_WEB_VERSION, status: 'idle' };

  async function nativeCode() {
    try { const r = await Cap.nativePromise('CallPilotDialer', 'nativeInfo', {}); return (r && r.versionCode) || 0; }
    catch (e) { return 0; }
  }

  async function run() {
    if (!native) return;
    // 1) 현재 번들 정상 실행 확인(롤백 방지) — 가능한 한 이르게
    try { await up('notifyAppReady'); } catch (e) {}

    let m = null;
    try {
      const res = await fetch(MANIFEST_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) return;
      m = await res.json();                     // {webVersion, url, minNativeCode, apk:{versionCode,url,note}}
    } catch (e) { return; }
    if (!m) return;

    // 2) 📥 네이티브(APK) 업데이트 확인 — 웹 OTA와 별개로 배너 안내
    try { await checkApkUpdate(m); } catch (e) {}

    // 3) 웹 번들 자동 업데이트
    try {
      if (!m.webVersion || !m.url) return;
      // 원격이 내장(APK)보다 '높을 때만' 적용 — 낮거나 같으면 무시(다운그레이드 금지).
      // (이전엔 !== 로만 비교해, 원격이 내장보다 낮아도 옛 번들을 덮어씌우는 다운그레이드 버그가 있었음)
      if (cmpVer(m.webVersion, OTA_WEB_VERSION) <= 0) return;
      const nc = await nativeCode();
      if (m.minNativeCode && nc && m.minNativeCode > nc) { window.CPOta.status = 'need-apk'; return; }
      window.CPOta.status = 'downloading';
      const dl = { version: m.webVersion, url: m.url };
      if (m.checksum) dl.checksum = m.checksum;
      const b = await up('download', dl);
      if (b && b.id) { window.CPOta.status = 'applying'; await up('set', { id: b.id }); }
    } catch (e) { /* 실패 시 내장 번들로 계속 */ }
  }

  // 새 APK(네이티브 버전)가 있으면 상단 배너로 안내 → '업데이트' 누르면 내려받아 설치화면
  async function checkApkUpdate(m) {
    if (!m.apk || !m.apk.versionCode || !m.apk.url) return;
    const nc = await nativeCode();
    if (!nc || m.apk.versionCode <= nc) return;       // 이미 최신
    showUpdateBanner(m.apk, nc >= INSTALLER_MIN);     // 현재 앱이 인앱설치 지원(vc≥18)이면 자동, 아니면 수동안내
  }
  function showUpdateBanner(apk, canAuto) {
    if (document.getElementById('cp-update-banner')) return;
    const bar = document.createElement('div');
    bar.id = 'cp-update-banner';
    bar.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:100050;display:flex;align-items:center;gap:10px;padding:12px 14px;background:#2f6db0;color:#fff;font:14px/1.4 sans-serif;box-shadow:0 -4px 16px rgba(0,0,0,.4)';
    const label = canAuto ? '업데이트' : '받기';
    bar.innerHTML = '<span style="flex:1">📥 새 버전이 있어요' + (apk.note ? ' · ' + String(apk.note).replace(/[<>]/g, '') : '') +
      (canAuto ? '' : ' (수동 설치)') + '</span>' +
      '<button id="cp-update-btn" style="background:#fff;color:#1c4a7a;border:none;border-radius:8px;padding:9px 16px;font-weight:800;font-size:14px">' + label + '</button>' +
      '<button id="cp-update-x" style="background:transparent;border:none;color:#dbe8f5;font-size:18px;padding:0 4px">✕</button>';
    document.body.appendChild(bar);
    document.getElementById('cp-update-x').onclick = () => bar.remove();
    document.getElementById('cp-update-btn').onclick = async () => {
      const btn = document.getElementById('cp-update-btn');
      if (!canAuto) { try { window.open(apk.url, '_blank'); } catch (e) {} try { location.href = apk.url; } catch (e) {} return; }
      btn.textContent = '내려받는 중…'; btn.disabled = true;
      try { await Cap.nativePromise('CallPilotDialer', 'installApk', { url: apk.url }); btn.textContent = '설치 화면 여는 중…'; }
      catch (e) { btn.textContent = '다시 시도'; btn.disabled = false; alert('업데이트: ' + (e && e.message || e)); }
    };
  }
  window.CPOta.checkNow = run;   // 수동 확인용

  // 앱 로드 직후 실행(비차단)
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
