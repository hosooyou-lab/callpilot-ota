// ============================================================
//  콜파일럿 모바일 — 자동발신 + 수신 (기본 전화 앱 방식)
//
//  콜파일럿이 "기본 전화 앱" → 통화화면을 직접 담당.
//   발신: DIALING(신호) → ACTIVE(상대가 받음) → DISCONNECTED(종료). 정확한 통화시간.
//   수신: RINGING(걸려옴, 받기/거절) → ACTIVE(통화) → DISCONNECTED.
//     · 기존 고객(목록에 있거나 통화한 적 있는 번호)이면 자동으로 통화기록 저장.
//     · 처음 보는 번호는 "고객 저장" 버튼을 눌러야 목록·기록에 남김.
// ============================================================

const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
const PLUGIN = 'CallPilotDialer';
const Dialer = (isNative && Cap.nativePromise) ? {
  dial:          (o) => Cap.nativePromise(PLUGIN, 'dial', o || {}),
  sendSms:       (o) => Cap.nativePromise(PLUGIN, 'sendSms', o || {}),
  sendMms:       (o) => Cap.nativePromise(PLUGIN, 'sendMms', o || {}),
  callLog:       (o) => Cap.nativePromise(PLUGIN, 'callLog', o || {}),
  listRecordings:(o) => Cap.nativePromise(PLUGIN, 'listRecordings', o || {}),
  prepRecording: (o) => Cap.nativePromise(PLUGIN, 'prepRecording', o || {}),
  hasStoragePermission: () => Cap.nativePromise(PLUGIN, 'hasStoragePermission', {}),
  requestStoragePermission: () => Cap.nativePromise(PLUGIN, 'requestStoragePermission', {}),
  endCall:       ()  => Cap.nativePromise(PLUGIN, 'endCall', {}),
  answerCall:    ()  => Cap.nativePromise(PLUGIN, 'answerCall', {}),
  startWatching: ()  => Cap.nativePromise(PLUGIN, 'startWatching', {}),
  stopWatching:  ()  => Cap.nativePromise(PLUGIN, 'stopWatching', {}),
  deviceId:      ()  => Cap.nativePromise(PLUGIN, 'deviceId', {}),
  requestAllPermissions: () => Cap.nativePromise(PLUGIN, 'requestAllPermissions', {}),
  isDefaultDialer:     () => Cap.nativePromise(PLUGIN, 'isDefaultDialer', {}),
  requestDefaultDialer:() => Cap.nativePromise(PLUGIN, 'requestDefaultDialer', {}),
  setKeepAwake:  (on) => Cap.nativePromise(PLUGIN, 'setKeepAwake', { on: !!on }),
  setMute:       (on) => Cap.nativePromise(PLUGIN, 'setMute', { on: !!on }),
  setSpeaker:    (on) => Cap.nativePromise(PLUGIN, 'setSpeaker', { on: !!on }),
  getCurrentCall:()  => Cap.nativePromise(PLUGIN, 'getCurrentCall', {}),
  addListener:   (ev, cb) => Cap.addListener(PLUGIN, ev, cb),
} : null;

const $ = (id) => document.getElementById(id);
const toastEl = $('toast');
let toastTimer = null;
function toast(msg, ms = 1800) {
  if (!toastEl) return;
  toastEl.textContent = msg; toastEl.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.hidden = true, ms);
}

// ---- 상태 ----
let queue = load('cp_queue', []);
let records = load('cp_records', []);
let sysCalls = [];   // 폰 시스템 통화기록(READ_CALL_LOG) — 최근 통화 표시용
let blocklist = load('cp_blocklist', []);
let running = false;
let idx = -1;
let phase = 'idle';          // idle | call | waiting
let panelMode = 'dial';      // dial | ring | inActive
let curTag = '';
let curDuration = 0;
let dialAt = 0;
let activeAt = 0;
let callWasActive = false;
let callEnded = false;
let waitTimer = null, safetyTimer = null;
let isDefaultDialer = false;
let muteOn = false, speakerOn = false;
// 수신 통화용
let incomingNumber = '';
let incomingKnown = false;
let incomingSaved = false;
let pausedForIncoming = false;

const TAGS = ['가망', '부재', '거부', '나중연락', '방문예약', '차단요청'];
function getScript() { const b = $('scriptBox'); return b ? b.value : ''; }

function load(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
function save(k, v) {
  try { localStorage.setItem(k, JSON.stringify(v)); }
  catch (e) { toast('⚠ 저장 실패 — 저장공간을 확인하세요', 3000); }
}

// ---- 유틸 ----
function normNum(n) { return String(n == null ? '' : n).replace(/[^\d]/g, ''); }
function isBlocked(n) { return blocklist.includes(normNum(n)); }
function addToBlocklist(n) {
  n = normNum(n);
  if (n && !blocklist.includes(n)) { blocklist.push(n); save('cp_blocklist', blocklist); }
}
function isKnownNumber(num) {
  const n = normNum(num);
  return queue.some(q => normNum(q.number) === n) || records.some(r => normNum(r.number) === n);
}
function lookupName(num) {
  const n = normNum(num);
  const q = queue.find(x => normNum(x.number) === n);
  if (q && q.name && q.name !== '(이름없음)') return q.name;
  const r = [...records].reverse().find(x => normNum(x.number) === n && x.name && x.name !== '(이름없음)');
  return r ? r.name : '';
}
function newId(seed) {
  try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return String(seed || Date.now()) + '-' + Math.random().toString(16).slice(2);
}
function makeRecord(t, tag, memo, durationSec, dialTs) {
  return {
    id: newId(dialTs),
    name: t.name, number: normNum(t.number),
    tag: tag || '', memo: memo || '',
    dialAt: new Date(dialTs || Date.now()).toISOString(),
    durationSec: durationSec || 0,
    time: new Date().toISOString(),
  };
}
function suggestTag() { return callWasActive ? '' : '부재'; }

// ---- 동기화용 (고객에 id·수정시각, 삭제 tombstone) ----
function nowIso() { return new Date().toISOString(); }
let tombstones = load('cp_tombstones', []);   // [{number, at}] — 삭제 전파용
function addTombstone(number) {
  const n = normNum(number);
  tombstones = tombstones.filter(t => t.number !== n);
  tombstones.push({ number: n, at: nowIso() });
  save('cp_tombstones', tombstones);
}
function ensureCustomerFields(c) {
  if (!c.id) c.id = newId();
  if (!c.updatedAt) c.updatedAt = nowIso();
  return c;
}
function migrateQueue() {
  let changed = false;
  queue.forEach(c => { if (!c.id || !c.updatedAt) { ensureCustomerFields(c); changed = true; } });
  if (changed) save('cp_queue', queue);
}

// ---- 목록 파싱 ----
function parseLines(text) {
  return text.split(/\n/).map(l => l.trim()).filter(Boolean).map(l => {
    let name = '', num = '';
    const parts = l.includes('\t') ? l.split('\t') : (l.includes(',') ? l.split(',') : null);
    if (parts) {
      const a = (parts[0] || '').trim(), b = (parts[1] || '').trim();
      const aNum = normNum(a), bNum = normNum(b);
      if (bNum.length >= 8) { name = a; num = bNum; }
      else if (aNum.length >= 8) { name = b || '(이름없음)'; num = aNum; }
      else { name = a; num = bNum; }
    } else {
      const m = l.match(/[\d][\d\s-]{6,}/);
      num = m ? normNum(m[0]) : '';
      name = m ? l.replace(m[0], '').trim() : l;
    }
    return { name: name || '(이름없음)', number: num, done: false };
  }).filter(x => x.number.length >= 8);
}

// ---- 렌더 ----
function renderQueue() {
  $('queueCount').textContent = queue.length + '명';
  const ul = $('queueList'); ul.innerHTML = '';
  // 2그룹: 아직 안 건(!done) / 통화 끝난(done). 원래 인덱스(i) 보존해 삭제·현재표시 유지.
  const indexed = queue.map((q, i) => ({ q, i }));
  const groups = [
    { label: '📞 통화 전', done: false, items: indexed.filter(x => !x.q.done) },
    { label: '✅ 통화 후', done: true, items: indexed.filter(x => x.q.done) },
  ];
  // 좌우 2열: 왼쪽=통화 전 / 오른쪽=통화 후
  const cols = document.createElement('div');
  cols.className = 'q-cols';
  groups.forEach(g => {
    const col = document.createElement('div');
    col.className = 'q-col';
    const head = document.createElement('div');
    head.className = 'grp';
    head.textContent = `${g.label} (${g.items.length})`;
    col.appendChild(head);
    if (!g.items.length) {
      const e = document.createElement('div'); e.className = 'grp-empty'; e.textContent = '없음';
      col.appendChild(e);
    } else {
      // 항목은 3개까지만 보이고 나머지는 이 안에서 스크롤 (목록이 길어도 화면 안 밀림)
      const items = document.createElement('div');
      items.className = 'q-items';
      g.items.forEach(({ q, i }) => {
        const li = document.createElement('li');
        if (q.done) li.className = 'done';
        if (i === idx && running) li.className = 'active';
        // 통화 후 결과 태그는 '결과가 있을 때만' 오른쪽에 표시(빈 '결과 입력' 칩 없음 → 한 줄 컴팩트)
        const tagHtml = (g.done && q.tag) ? `<span class="rtag">${esc(q.tag)}</span>` : '';
        const nameHtml = q.name ? `<span class="nm">${esc(q.name)}</span>` : '';
        li.innerHTML = `<div class="qbody">` + nameHtml +
          `<span class="no">${fmt(q.number)}</span>` + tagHtml + `</div>`;
        // 번호를 누르면 통합 상세창(정보·메모·전화·메시지·추가/삭제) — 통화 전/후 모두
        li.querySelector('.qbody').onclick = () => openContact(q.number, { name: q.name });
        items.appendChild(li);
      });
      col.appendChild(items);
    }
    cols.appendChild(col);
  });
  ul.appendChild(cols);
}
function deleteQueueItem(i) {
  if (running && i === idx) { toast('통화 중인 항목은 지울 수 없어요'); return; }
  const removed = queue[i];
  queue.splice(i, 1);
  if (removed) addTombstone(removed.number);   // 삭제를 PC에도 전파
  if (i < idx) idx--;
  save('cp_queue', queue); renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화(삭제 바로 PC 반영)
}
function recDateMD(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  return (d && !isNaN(d)) ? `${d.getMonth() + 1}/${d.getDate()}` : '';
}
function renderRecords() {
  $('recCount').textContent = records.length + '건';
  const ul = $('recordList'); ul.innerHTML = '';
  // 전체 표시(최신순). 누르면 결과·메모 수정.
  records.slice().reverse().forEach(r => {
    const li = document.createElement('li');
    li.className = 'rec-item';
    const md = recDateMD(r);
    const meta = [];
    if (r.name && r.name !== '(이름없음)' && r.name !== '(수신)' && r.name !== '(발신)') meta.push(esc(r.name));
    if (r.durationSec) meta.push(r.durationSec + '초');
    if (md) meta.push(md);
    li.innerHTML = `<span class="rtag">${esc(r.tag || '-')}</span>`
      + `<span class="rmeta">${meta.join(' · ')}</span>`
      + `<span class="no">${fmt(r.number)}</span>`;
    li.onclick = () => openContact(r.number, { name: r.name });
    ul.appendChild(li);
  });
  renderRecent();
}
// 📞 최근 통화 — 번호별 최신 1건(중복 제거)만, 최신순 상위 8개. 전화앱처럼 눌러서 상세창.
function recTimeShort(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  if (!d || isNaN(d)) return '';
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12;
    return `${ap} ${h}:${m}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}
// 폰 시스템 통화기록 읽기(READ_CALL_LOG) → PC 연결 없이도 최근 통화 표시
async function loadSystemCalls() {
  if (!Dialer || !Dialer.callLog) return;
  try {
    const r = await Dialer.callLog({ limit: 60 });
    const calls = (r && r.calls) || [];
    sysCalls = calls.map(c => ({ number: normNum(c.number), name: c.name || '', date: +c.date || 0, type: +c.type || 0, duration: +c.duration || 0 }))
      .filter(c => c.number);
    renderRecent();
  } catch (e) { /* 권한 없거나 실패 → 로컬 기록으로 */ }
}
// 통화 방향/부재 → 화살표·색. (안드로이드 CallLog TYPE: 1 수신·2 발신·3 부재·5 거절·6 차단)
function callMark(type) {
  if (type === 2) return { arrow: '↗', color: 'var(--ok)' };                 // 발신(초록)
  if (type === 3 || type === 5 || type === 6) return { arrow: '↙', color: 'var(--bad)', missed: true }; // 부재중(빨강)
  if (type === 1) return { arrow: '↙', color: '#5b9bd5' };                    // 수신(파랑)
  return { arrow: '↗', color: 'var(--ok)' };
}
function renderRecent() {
  const card = $('recentCard'), ul = $('recentList');
  if (!card || !ul) return;
  const seen = new Set(); const rows = [];
  if (sysCalls && sysCalls.length) {
    // 시스템 통화기록 우선(폰 실제 최근통화). 번호별 최신 1건.
    sysCalls.forEach(c => {
      if (seen.has(c.number)) return; seen.add(c.number);
      const rec = records.slice().reverse().find(r => normNum(r.number) === c.number);
      const nm = (c.name || (rec && rec.name)) || fmt(c.number);
      rows.push({ number: c.number, name: nm, tag: rec ? rec.tag : '', time: c.date ? new Date(c.date) : null, type: c.type });
    });
  } else {
    records.slice().reverse().forEach(r => {
      const n = normNum(r.number); if (!n || seen.has(n)) return; seen.add(n);
      const nm = (r.name && r.name !== '(이름없음)' && r.name !== '(수신)' && r.name !== '(발신)') ? r.name : fmt(r.number);
      const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
      // 로컬 기록엔 통화방향이 없음 → 태그로 추정(수신/부재)
      const type = r.tag === '수신' ? 1 : (r.tag === '부재' ? 3 : 2);
      rows.push({ number: n, name: nm, tag: r.tag, time: d, type });
    });
  }
  const top = rows.slice(0, 8);
  ul.innerHTML = '';
  if (!top.length) { card.hidden = true; return; }
  card.hidden = false;
  top.forEach(row => {
    const li = document.createElement('li');
    li.className = 'rec-item';
    const m = callMark(row.type);
    li.innerHTML = `<span class="rc-arrow" style="color:${m.color}">${m.arrow}</span>`
      + `<span class="rc-main">${esc(row.name)}</span>`
      + (m.missed ? `<span class="rc-missed">부재중</span>` : '')
      + (row.tag ? `<span class="rtag">${esc(row.tag)}</span>` : '')
      + `<span class="rc-time">${row.time ? whenFull(row.time) : ''}</span>`;
    li.onclick = () => openContact(row.number, { name: row.name });
    ul.appendChild(li);
  });
}
function timeShort(d) {
  if (!d || isNaN(d)) return '';
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12; return `${ap} ${h}:${m}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}
// 최근통화용 — 날짜 + 시간 함께(오늘은 시간만, 지난 날은 날짜+시간)
function whenFull(d) {
  if (!d || isNaN(d)) return '';
  let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
  const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12; const t = `${ap} ${h}:${m}`;
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return t;
  return `${d.getMonth() + 1}/${d.getDate()} ${t}`;
}
function esc(s) { return String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])); }
function fmt(n) { n = String(n || ''); return n.length === 11 ? n.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3') : n; }

function setStatus(text, cls) {
  $('statusText').textContent = text;
  $('dot').className = 'dot' + (cls ? ' ' + cls : '');
}

// ---- 결과 태그 ----
function buildTagButtons() {
  const row = $('tagRow'); if (!row) return;
  row.innerHTML = '';
  TAGS.forEach(t => {
    const b = document.createElement('button');
    b.className = 'tag'; b.dataset.tag = t; b.textContent = t;
    b.onclick = () => { curTag = t; [...row.querySelectorAll('.tag')].forEach(x => x.classList.toggle('on', x === b)); };
    row.appendChild(b);
  });
}
function highlightTag() {
  [...document.querySelectorAll('#tagRow .tag')].forEach(b => b.classList.toggle('on', b.dataset.tag === curTag));
}

// ---- 통화 패널 ----
function setPanelMode(mode) {
  panelMode = mode;
  const dial = mode === 'dial', ring = mode === 'ring', inA = mode === 'inActive';
  const disp = (id, on) => { const e = $(id); if (e) e.style.display = on ? '' : 'none'; };
  $('callPanel').classList.toggle('ringing', ring);
  disp('ringRow', ring);
  disp('callScript', dial || inA);   // 발신 중·통화 중 모두 스크립트 크게 표시(수신 통화도)
  $('callCtl').style.display = (dial || inA) ? 'flex' : 'none';
  disp('tagRow', dial);
  disp('memoBox', dial || inA);
  disp('saveRow', dial);
  disp('saveCustomerBtn', inA && !incomingKnown);
  disp('endCallBtn', !ring);
  $('endCallBtn').textContent = dial ? '■ 통화 종료 · 자동발신 정지' : '■ 통화 종료';
  $('callHead').firstChild.textContent = dial ? '통화 ' : (ring ? '수신 전화 ' : '수신 통화 ');
}
function closeAllOverlays() {
  document.querySelectorAll('.cp-ov').forEach(o => o.remove());
}
// 📞 통화 상태를 PC(같은 wifi·페어링)로 전송 → PC 화면에 "폰 통화 중 · 번호" 배너
function pushLiveCall(state, number, name, incoming) {
  try { if (window.cpLiveCall) window.cpLiveCall({ state, number: normNum(number), name: name || '', incoming: !!incoming }); } catch (e) {}
}
function openCallPanel(mode, name, number) {
  closeAllOverlays();   // 전화 걸기/받기 시작하면 열려있던 고객창·미리보기 등 모두 닫기
  $('memoTarget').textContent = (name ? name + ' · ' : '') + fmt(number || '');
  // 콜 스크립트는 발신·통화 중 모두 크게 보이게 채워둔다(수신 통화 포함)
  $('callScript').textContent = getScript() || '';
  if (mode === 'dial') {
    $('memoBox').value = ''; curTag = ''; highlightTag();
    $('callState').textContent = '발신 중…';
  } else if (mode === 'ring') {
    $('callState').textContent = '📞 수신 전화 — 받으시겠어요?';
  } else {
    $('memoBox').value = '';
    $('callState').textContent = incomingKnown ? '통화 중 · 기존 고객(자동 저장됨)' : '통화 중 · 새 번호';
  }
  muteOn = false; speakerOn = false; syncCtl();
  setPanelMode(mode);
  $('callPanel').hidden = false;
  // 통화 시작(발신·통화 중)엔 콜 스크립트가 잘 보이는 위치로 스크롤 — 스크립트 보며 메모.
  // 수신 벨(ring)일 땐 큰 받기 버튼이 보이도록 패널 상단으로.
  setTimeout(() => {
    try {
      const target = (mode === 'ring') ? $('callPanel') : ($('callScript') || $('callPanel'));
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {}
  }, 140);
}
function closeCallPanel() { $('callPanel').hidden = true; }
function syncCtl() {
  $('muteBtn').classList.toggle('on', muteOn);
  $('speakerBtn').classList.toggle('on', speakerOn);
}

// ---- 자동발신 ----
async function refreshDefaultDialer() {
  if (!Dialer || !Dialer.isDefaultDialer) { isDefaultDialer = false; return; }
  try { const r = await Dialer.isDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); }
  catch (e) { isDefaultDialer = false; }
  const btn = $('defaultDialerBtn'); if (btn) btn.hidden = isDefaultDialer || !isNative;
}

async function startAuto() {
  if (!queue.some(q => !q.done)) { toast('걸 대상이 없습니다'); return; }
  if (!isNative) toast('브라우저 미리보기: 발신은 흉내만 냅니다', 2600);

  if (Dialer && Dialer.requestAllPermissions) {
    try {
      const r = await Dialer.requestAllPermissions();
      if (r && r.granted === false) { toast('전화·통화상태·통화제어 권한을 모두 허용해야 시작할 수 있어요', 3200); return; }
    } catch (e) { toast('권한 확인 실패'); return; }
  }

  await refreshDefaultDialer();
  if (isNative && Dialer && !isDefaultDialer) {
    const go = confirm(
      '콜파일럿을 "기본 전화 앱"으로 설정해야 통화화면에 스크립트·메모가 뜹니다.\n\n' +
      '설정하면 통화화면을 콜파일럿이 담당합니다.\n\n지금 설정할까요?'
    );
    if (go) {
      try { const r = await Dialer.requestDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); } catch (e) {}
      await refreshDefaultDialer();
      if (!isDefaultDialer) { toast('기본 전화 앱으로 설정한 뒤 다시 시작을 눌러주세요', 3200); return; }
    } else {
      toast('기본 전화 앱 미설정 — 통화화면에 스크립트가 안 보일 수 있어요', 3000);
    }
  }

  running = true;
  $('startBtn').disabled = true; $('stopBtn').disabled = false; $('nextBtn').disabled = false;
  try { if (Dialer) await Dialer.startWatching(); } catch (e) { toast('통화상태 권한 필요'); }
  idx = queue.findIndex(q => !q.done) - 1;
  nextCall();
}

async function nextCall() {
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  if (!running || pausedForIncoming) return;

  do { idx++; } while (idx < queue.length && queue[idx].done);
  if (idx >= queue.length) { toast('목록 끝 — 완료'); stopAuto(); return; }
  const t = queue[idx];

  if (isBlocked(t.number)) {
    queue[idx].done = true;
    queue[idx].tag = '차단-건너뜀';
    queue[idx].updatedAt = nowIso();
    records.push(makeRecord(t, '차단-건너뜀', '', 0, Date.now()));
    save('cp_queue', queue); save('cp_records', records);
    renderQueue(); renderRecords();
    toast(`${t.name} · 차단번호 — 건너뜀`);
    safetyTimer = setTimeout(() => { if (running) nextCall(); }, 300);
    return;
  }

  phase = 'call'; dialAt = Date.now(); activeAt = 0; callWasActive = false; callEnded = false;
  curDuration = 0; curTag = '';
  setStatus('발신 중', 'call'); renderQueue();
  openCallPanel('dial', t.name, t.number);

  try {
    if (Dialer) await Dialer.dial({ number: t.number });
    else if (!isNative) mockCall();
    else { $('callState').textContent = '발신 모듈 없음 — 재설치 필요'; toast('플러그인 로드 실패'); stopAuto(); return; }
  } catch (e) {
    $('callState').textContent = '발신 실패 — 권한을 확인하세요';
    toast('전화 걸기 권한을 허용해주세요');
    callEnded = true; curTag = '부재';
    return;
  }

  safetyTimer = setTimeout(() => {
    if (running && phase === 'call' && !callEnded) { callEnded = true; $('callState').textContent = '통화 종료(추정) · 결과 저장'; }
  }, 120000);
}

// 통화 상태 이벤트 (발신 + 수신 통합)
function onCallEvent(ev) {
  const st = ev && ev.state;
  const incoming = !!(ev && ev.incoming);
  const number = (ev && ev.number) || '';
  if (incoming) return handleIncoming(st, number);

  if (!running) return handleExternalCall(st, number);   // 📞 PC/수동 발신도 통화패널 띄움(메모 가능)
  const curNum = number || (queue[idx] && queue[idx].number) || '';
  const curNm = (queue[idx] && queue[idx].name) || '';
  if (st === 'DIALING') { $('callState').textContent = '발신 중… (신호 감)'; pushLiveCall('dialing', curNum, curNm); return; }
  if (st === 'ACTIVE' || st === 'OFFHOOK') {
    callWasActive = true;
    if (!activeAt) activeAt = Date.now();
    if (phase === 'call' && !callEnded) $('callState').textContent = '통화 중… (상대 연결됨)';
    setStatus('통화 중', 'call');
    pushLiveCall('active', curNum, curNm);
    return;
  }
  if (st === 'DISCONNECTED' || st === 'IDLE') {
    if (phase !== 'call' || callEnded) return;
    pushLiveCall('end', curNum, curNm);
    callEnded = true;
    curDuration = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
    curTag = suggestTag(); highlightTag();
    const durTxt = callWasActive ? `통화 ${curDuration}초 · 결과 저장` : '안 받음(부재) · 저장';
    $('callState').textContent = '통화 종료됨 — ' + durTxt;
    $('memoTarget').textContent = (queue[idx] ? queue[idx].name + ' · ' + fmt(queue[idx].number) : '')
      + (curDuration ? ` · ${curDuration}초` : '');
    setStatus('결과 입력', 'watch');
  }
}

// 📞 외부(PC 발신·수동 발신) 통화 처리 — 자동발신 아닐 때도 통화패널을 띄워 메모 가능하게
function handleExternalCall(st, number) {
  if (st === 'DIALING' || st === 'OFFHOOK' || st === 'ACTIVE') {
    if (phase !== 'call') {
      incomingNumber = number; incomingKnown = isKnownNumber(number); incomingSaved = false;
      activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
      phase = 'call';
      openCallPanel('inActive', lookupName(number), number);
      $('callState').textContent = (st === 'DIALING') ? '발신 중…' : '통화 중';
      setStatus('통화 중', 'call');
      pushLiveCall((st === 'DIALING') ? 'dialing' : 'active', number, lookupName(number));
    }
    if (st === 'ACTIVE' || st === 'OFFHOOK') { callWasActive = true; if (!activeAt) activeAt = Date.now(); $('callState').textContent = '통화 중'; pushLiveCall('active', number, lookupName(number)); }
    return;
  }
  if (st === 'DISCONNECTED' || st === 'IDLE') {
    if (phase !== 'call' || callEnded) return;
    pushLiveCall('end', number, lookupName(number));
    callEnded = true;
    const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
    if (incomingKnown || incomingSaved) {
      const nm = lookupName(number) || '(발신)';
      records.push(makeRecord({ name: nm, number }, callWasActive ? '' : '부재', $('memoBox').value.trim(), dur, dialAt));
      save('cp_records', records); renderRecords();
    }
    closeCallPanel(); phase = 'idle'; setStatus('대기');
  }
}

// 수신 통화 처리
function handleIncoming(st, number) {
  if (st === 'RINGING') {
    incomingNumber = number; incomingKnown = isKnownNumber(number); incomingSaved = false;
    activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
    if (running) { pausedForIncoming = true; clearTimeout(waitTimer); clearTimeout(safetyTimer); }
    phase = 'call';
    openCallPanel('ring', lookupName(number), number);
    setStatus('수신 전화', 'watch');
    pushLiveCall('ringing', number, lookupName(number), true);
    return;
  }
  if (st === 'ACTIVE') {
    callWasActive = true; if (!activeAt) activeAt = Date.now();
    openCallPanel('inActive', lookupName(number), number);
    setStatus('통화 중(수신)', 'call');
    pushLiveCall('active', number, lookupName(number), true);
    return;
  }
  if (st === 'DISCONNECTED') {
    pushLiveCall('end', number, lookupName(number), true);
    if (!callEnded) {
      callEnded = true;
      const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
      // 기존 고객이거나 사용자가 "고객 저장"을 누른 경우만 기록
      if (incomingKnown || incomingSaved) {
        const nm = lookupName(number) || '(수신)';
        records.push(makeRecord({ name: nm, number }, '수신', $('memoBox').value.trim(), dur, dialAt));
        save('cp_records', records); renderRecords();
      }
    }
    closeCallPanel();
    phase = 'idle';
    if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); }
    else setStatus('대기');
  }
}

async function saveAndNext() {
  if (!running || panelMode !== 'dial') return;
  if (!callEnded) { try { if (Dialer) await Dialer.endCall(); } catch (e) {} }
  if (queue[idx]) {
    queue[idx].done = true;
    queue[idx].tag = curTag || '';   // 통화 끝난 그룹에 결과 표시용
    queue[idx].updatedAt = nowIso();  // 📱 통화함 상태를 PC에도 전파(LWW)
    const dur = callEnded ? curDuration : (activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0);
    records.push(makeRecord(queue[idx], curTag, $('memoBox').value.trim(), dur, dialAt));
    if (curTag === '차단요청') addToBlocklist(queue[idx].number);
    save('cp_queue', queue); save('cp_records', records);
  }
  closeCallPanel();
  renderQueue(); renderRecords();
  if (!running) { phase = 'idle'; setStatus('대기'); return; }
  scheduleNext();
}

function scheduleNext() {
  phase = 'waiting';
  clearTimeout(waitTimer);
  const w = Math.max(0, parseInt($('waitSec').value) || 0);
  setStatus(`${w}초 후 다음`, 'watch');
  waitTimer = setTimeout(() => { if (running && !pausedForIncoming) nextCall(); }, w * 1000);
}

async function stopAuto() {
  const wasActive = (phase === 'call');
  running = false; phase = 'idle'; pausedForIncoming = false;
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  $('startBtn').disabled = false; $('stopBtn').disabled = true; $('nextBtn').disabled = true;
  try { if (Dialer && wasActive && !callEnded && panelMode === 'dial') await Dialer.endCall(); } catch (e) {}
  try { if (Dialer) Dialer.stopWatching(); } catch (e) {}
  closeCallPanel();
  setStatus('대기'); renderQueue();
}

// ---- 미리보기용 흉내 ----
function mockCall() {
  setTimeout(() => onCallEvent({ state: 'DIALING' }), 400);
  setTimeout(() => onCallEvent({ state: 'ACTIVE' }), 1600);
  setTimeout(() => onCallEvent({ state: 'DISCONNECTED' }), 4200);
}

// ---- 이벤트 바인딩 ----
$('addBtn').onclick = () => {
  const add = parseLines($('pasteBox').value);
  if (!add.length) { toast('인식된 번호가 없습니다'); return; }
  const existing = new Set(queue.map(q => normNum(q.number)));
  const fresh = [];
  let dup = 0;
  add.forEach(a => { const n = normNum(a.number); if (existing.has(n)) dup++; else { existing.add(n); ensureCustomerFields(a); fresh.push(a); } });
  queue = queue.concat(fresh); save('cp_queue', queue);
  $('pasteBox').value = ''; renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화
  toast(`${fresh.length}명 추가` + (dup ? ` · 중복 ${dup}명 제외` : ''));
};
// 그룹별 비우기 (삭제를 PC에도 전파 = tombstone)
function removeQueueBy(pred, msg) {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const targets = queue.filter(pred);
  if (!targets.length) { toast('비울 항목이 없어요'); return; }
  if (!confirm(msg.replace('{n}', targets.length))) return;
  targets.forEach(t => { addTombstone(t.number); });
  const del = new Set(targets.map(t => t.id));
  queue = queue.filter(q => !del.has(q.id));
  idx = -1;
  save('cp_queue', queue); renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화
}
// 🧹 목록 비우기 → 통화 전 / 통화 후 / 선택 삭제 중 고르기 (평소엔 버튼 하나만 노출)
function openClearMenu() {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const pre = queue.filter(q => !q.done).length;
  const done = queue.filter(q => q.done).length;
  const { ov, close } = buildOverlay('clearMenuOv',
    `<div class="cp-ov-h">목록 비우기</div>
     <div class="cp-ov-note">어떤 걸 지울지 고르세요.</div>
     <button class="btn ghost danger cm-btn" id="cmPre">📞 통화 전 전부 비우기 (${pre})</button>
     <button class="btn ghost danger cm-btn" id="cmDone">✅ 통화 후 전부 비우기 (${done})</button>
     <button class="btn ghost cm-btn" id="cmCancel">취소</button>`);
  ov.querySelector('#cmPre').onclick = () => { close(); removeQueueBy(q => !q.done, '통화 전 {n}명을 비울까요?'); };
  ov.querySelector('#cmDone').onclick = () => { close(); removeQueueBy(q => q.done, '통화 후 {n}명을 비울까요?'); };
  ov.querySelector('#cmCancel').onclick = close;
}
$('clearMenuBtn').onclick = openClearMenu;
// 📋 클립보드 붙여넣기 — 클립보드 내용을 붙여넣기칸에 넣음(모바일 길게눌러 붙여넣기 번거로움 해소)
{ const cb = $('clipPasteBtn'); if (cb) cb.onclick = async () => {
    const txt = await readClip();
    if (!txt) { toast('클립보드가 비었거나 권한이 필요해요 — 길게 눌러 붙여넣기 하세요'); return; }
    const box = $('pasteBox'); box.value = (box.value ? box.value.replace(/\s*$/, '') + '\n' : '') + txt;
    box.dispatchEvent(new Event('input', { bubbles: true }));
    toast('클립보드에서 붙여넣었어요 — 확인하고 [목록에 추가]');
  }; }
// PC 동기화 카드 접기/펼치기 (기본 접힘)
{ const st = $('syncToggle'); if (st) st.onclick = () => { const c = document.getElementById('syncCard'); if (c) c.classList.toggle('collapsed'); }; }
$('startBtn').onclick = startAuto;
$('stopBtn').onclick = () => { stopAuto(); toast('정지됨'); };
// ▶▶ 다음 번호 (PC와 동일) — 통화 중이면 결과 저장 후 다음, 대기 중이면 바로 다음 발신
$('nextBtn').onclick = () => {
  if (!running) { toast('자동발신 시작 후 사용하세요'); return; }
  if (panelMode === 'dial' && !$('callPanel').hidden) saveAndNext();
  else nextCall();
};
$('saveBtn').onclick = saveAndNext;
$('skipBtn').onclick = () => { curTag = curTag || '건너뜀'; saveAndNext(); };
$('endCallBtn').onclick = async () => {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  if (panelMode !== 'dial') { closeCallPanel(); phase = 'idle'; if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기'); return; }
  stopAuto();
  toast('통화 종료 · 자동발신 멈춤');
};
$('answerBtn').onclick = async () => { try { if (Dialer) await Dialer.answerCall(); } catch (e) {} };
$('rejectBtn').onclick = async () => {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  closeCallPanel(); phase = 'idle';
  if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기');
};
$('saveCustomerBtn').onclick = () => {
  const n = normNum(incomingNumber);
  if (n && !queue.some(q => normNum(q.number) === n)) {
    queue.push(ensureCustomerFields({ name: '(이름없음)', number: n, done: false }));
    save('cp_queue', queue); renderQueue();
  }
  incomingSaved = true;
  $('saveCustomerBtn').textContent = '고객목록에 저장됨 ✓';
  $('saveCustomerBtn').disabled = true;
};
$('muteBtn').onclick = async () => { muteOn = !muteOn; syncCtl(); try { if (Dialer) await Dialer.setMute(muteOn); } catch (e) {} };
$('speakerBtn').onclick = async () => { speakerOn = !speakerOn; syncCtl(); try { if (Dialer) await Dialer.setSpeaker(speakerOn); } catch (e) {} };

// ============================================================
//  🔁 다시 걸기 + 통화기록 결과 수정 (모달)
// ============================================================
// 공용 오버레이 (배경클릭·✕·Esc 로 닫힘)
function buildOverlay(id, innerHtml) {
  const old = document.getElementById(id); if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = id; ov.className = 'cp-ov';
  ov.innerHTML = `<div class="cp-ov-box">${innerHtml}</div>`;
  document.body.appendChild(ov);
  const close = () => { ov.remove(); document.removeEventListener('keydown', onEsc); };
  function onEsc(e) { if (e.key === 'Escape') close(); }
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', onEsc);
  return { ov, close };
}

// 통화기록 한 건: 결과 태그·메모 수정
function openRecordEdit(id) {
  const r = records.find(x => x.id === id); if (!r) return;
  const tagBtns = TAGS.map(t => `<button class="tag${t === r.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('recEditOv',
    `<div class="cp-ov-h">기록 수정 · ${esc(r.name || '')} <span class="cp-ov-sub">${fmt(r.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="reTags">${tagBtns}</div>
     <div class="cp-ov-lbl">메모</div>
     <textarea id="reMemo" rows="3" placeholder="메모…">${esc(r.memo || '')}</textarea>
     <div class="row">
       <button class="btn primary" id="reSave">저장</button>
       <button class="btn ghost" id="reCancel">취소</button>
     </div>`);
  let sel = r.tag || '';
  ov.querySelectorAll('#reTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#reTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#reCancel').onclick = close;
  ov.querySelector('#reSave').onclick = () => {
    r.tag = sel; r.memo = ov.querySelector('#reMemo').value.trim();
    r.time = nowIso();                       // 수정시각(동기화 LWW용)
    if (sel === '차단요청') addToBlocklist(r.number);
    // 발신목록의 같은 번호(통화 끝난)에도 결과 반영
    const q = queue.find(x => normNum(x.number) === normNum(r.number) && x.done);
    if (q) q.tag = sel;
    save('cp_records', records); save('cp_queue', queue);
    renderRecords(); renderQueue();
    close(); toast('기록을 고쳤어요');
  };
}

// 통화 후 발신목록 항목: 통화 결과(태그) 수정. 같은 번호 통화기록이 있으면 그 기록 편집기로(양방향 반영), 없으면 태그만.
function openQueueEdit(id) {
  const q = queue.find(x => x.id === id); if (!q) return;
  const rec = records.slice().reverse().find(r => normNum(r.number) === normNum(q.number));
  if (rec) { openRecordEdit(rec.id); return; }
  const tagBtns = TAGS.map(t => `<button class="tag${t === q.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('qEditOv',
    `<div class="cp-ov-h">통화 결과 · ${esc(q.name || '')} <span class="cp-ov-sub">${fmt(q.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="qeTags">${tagBtns}</div>
     <div class="row">
       <button class="btn primary" id="qeSave">저장</button>
       <button class="btn ghost" id="qeCancel">취소</button>
     </div>`);
  let sel = q.tag || '';
  ov.querySelectorAll('#qeTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#qeTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#qeCancel').onclick = close;
  ov.querySelector('#qeSave').onclick = () => {
    q.tag = sel; q.updatedAt = nowIso();
    if (sel === '차단요청') addToBlocklist(q.number);
    save('cp_queue', queue); renderQueue();
    close(); toast('통화 결과를 고쳤어요');
  };
}

// ============================================================
//  📇 통합 고객 상세창 — 어디서든 번호를 누르면 열림
//     정보·메모·통화결과 + 전화/메시지/고객추가·삭제 (PC와 동일 컨셉)
// ============================================================
function findCustomer(number) { const n = normNum(number); return queue.find(x => normNum(x.number) === n); }
function lastRecordFor(number) { const n = normNum(number); return records.slice().reverse().find(r => normNum(r.number) === n); }
function callCountFor(number) { const n = normNum(number); return records.filter(r => normNum(r.number) === n).length; }

function callNumber(number) {
  const n = normNum(number);
  if (Dialer) { Dialer.dial({ number: n }).catch(() => toast('발신 실패')); }
  else toast('통화는 폰 앱에서만 됩니다');
}
// 📋 클립보드 (복사/읽기) — 안 되는 환경 폴백 포함
async function copyToClip(text) {
  try { await navigator.clipboard.writeText(text || ''); return true; } catch (e) {}
  try {
    const ta = document.createElement('textarea'); ta.value = text || '';
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0'; document.body.appendChild(ta);
    ta.focus(); ta.select(); document.execCommand('copy'); ta.remove(); return true;
  } catch (e) { return false; }
}
async function readClip() { try { return (await navigator.clipboard.readText()) || ''; } catch (e) { return ''; } }

async function messageNumber(number, body, images) {
  const n = normNum(number);
  const imgs = Array.isArray(images) ? images.filter(Boolean) : [];
  // 메시지앱이 내용을 미리 못 채우는 기기 대비 — 보낼 내용을 클립보드에도 복사(붙여넣기로 사용)
  if (body) copyToClip(body);
  // 사진이 있으면 MMS(사진+문자 한 번에) — 네이티브 필요(새 APK)
  if (imgs.length) {
    if (Dialer && Dialer.sendMms) {
      try { await Dialer.sendMms({ number: n, body: body || '', images: imgs }); return; }
      catch (e) { toast('사진 전송은 새 APK 설치 후 됩니다 — 문자만 엽니다', 3000); }
    } else { toast('사진 전송은 새 APK 설치 후 됩니다 — 문자만 엽니다', 3000); }
  }
  if (Dialer && Dialer.sendSms) {
    try { await Dialer.sendSms({ number: n, body: body || '' }); return; }   // 폰 기본 메시지앱 열림
    catch (e) { /* 구버전 APK(메서드 없음) → 폴백 */ }
  }
  try { window.location.href = 'sms:' + n + (body ? ('?body=' + encodeURIComponent(body)) : ''); }
  catch (e) { toast('메시지는 앱 업데이트(새 APK) 후 사용하세요'); }
}

// 사진을 localStorage에 담을 수 있게 축소(긴 변 1080px·JPEG) → data URI
function resizeImageFile(file, maxPx, quality) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let w = img.width, h = img.height; const m = maxPx || 1080;
        if (w > m || h > m) { if (w >= h) { h = Math.round(h * m / w); w = m; } else { w = Math.round(w * m / h); h = m; } }
        try {
          const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
          cv.getContext('2d').drawImage(img, 0, 0, w, h);
          resolve(cv.toDataURL('image/jpeg', quality || 0.8));
        } catch (e) { resolve(reader.result); }
      };
      img.onerror = reject; img.src = reader.result;
    };
    reader.onerror = reject; reader.readAsDataURL(file);
  });
}

// 🎙 이 번호의 통화 녹음 로드 + 재생 (버튼 눌러 그 자리에서 재생)
async function loadRecordingsInto(box, number) {
  const n = normNum(number);
  box.innerHTML = '<div class="cp-ov-note">불러오는 중…</div>';
  if (!Dialer || !Dialer.listRecordings) { box.innerHTML = '<div class="cp-ov-note">녹음은 새 APK(업데이트) 후 됩니다</div>'; return; }
  try {
    const p = await Dialer.hasStoragePermission();
    if (!p || !p.granted) {
      box.innerHTML = '<div class="cp-ov-note">녹음 파일 접근 권한이 필요해요.</div>';
      const pb = document.createElement('button'); pb.className = 'btn ghost'; pb.textContent = '🔓 권한 허용하기';
      pb.onclick = async () => { try { await Dialer.requestStoragePermission(); toast('허용 후 다시 [녹음 불러오기]', 3000); } catch (e) {} };
      box.appendChild(pb); return;
    }
  } catch (e) {}
  let list = [];
  try { const r = await Dialer.listRecordings({ number: n }); list = (r && r.recordings) || []; }
  catch (e) { box.innerHTML = '<div class="cp-ov-note">녹음 목록 실패: ' + esc(String(e && e.message || e)) + '</div>'; return; }
  list.sort((a, b) => (b.modified || 0) - (a.modified || 0));
  if (!list.length) { box.innerHTML = '<div class="cp-ov-note">이 번호의 녹음이 없어요</div>'; return; }
  box.innerHTML = '';
  const audio = document.createElement('audio'); audio.controls = true; audio.style.cssText = 'width:100%;margin-top:8px;display:none';
  list.slice(0, 12).forEach(rec => {
    const b = document.createElement('button'); b.className = 'btn ghost cm-btn';
    const dt = rec.modified ? new Date(rec.modified) : null;
    b.textContent = '▶ ' + (dt ? timeShort(dt) + ' 녹음' : rec.name);
    b.onclick = async () => {
      try {
        const pr = await Dialer.prepRecording({ path: rec.path });
        const src = (window.Capacitor && window.Capacitor.convertFileSrc) ? window.Capacitor.convertFileSrc(pr.path) : pr.path;
        audio.src = src; audio.style.display = 'block'; audio.play();
      } catch (e) { toast('재생 실패: ' + (e && e.message || e)); }
    };
    box.appendChild(b);
  });
  box.appendChild(audio);
}

// 📞 발신 전 미리보기 — 이 사람과의 통화 이력·주고받은 문자·녹음을 보고 걸지 말지 결정
function openPreCall(number, name) {
  const n = normNum(number);
  const nm = name || lookupName(n) || fmt(n);
  const recs = records.filter(r => normNum(r.number) === n).slice().reverse();
  const cnt = recs.length; const last = recs[0];
  const bits = [];
  if (last && last.tag) bits.push('최근 결과 <b>' + esc(last.tag) + '</b>');
  if (last) { const md = recDateMD(last); if (md) bits.push('마지막 ' + md); }
  if (cnt) bits.push('통화 ' + cnt + '회');
  const info = bits.length ? bits.join(' · ') : '통화 기록 없음';
  const recRows = recs.slice(0, 6).map(r => {
    const md = recDateMD(r); const memo = r.memo ? ' · ' + esc(r.memo) : '';
    return `<div class="pc-rec"><span class="rtag">${esc(r.tag || '-')}</span>`
      + `<span class="pc-rec-m">${md}${r.durationSec ? ' · ' + r.durationSec + '초' : ''}${memo}</span></div>`;
  }).join('');

  const { ov, close } = buildOverlay('preCallOv',
    `<div class="cp-ov-h">📞 전화 걸기 전 · ${esc(nm)} <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="cp-ov-note">${info}</div>
     ${recRows ? `<div class="cp-ov-lbl">통화 이력</div><div class="pc-recs">${recRows}</div>` : ''}
     <div class="cp-ov-lbl">🎙 통화 녹음</div>
     <div class="ct-rec" id="pcRec"><button class="btn ghost" id="pcRecLoad">🎙 녹음 불러오기</button></div>
     <div class="row" style="margin-top:14px">
       <button class="btn primary" id="pcCall">📞 전화 걸기</button>
       <button class="btn ghost" id="pcCancel">취소</button>
     </div>`);
  ov.querySelector('#pcRecLoad').onclick = () => loadRecordingsInto(ov.querySelector('#pcRec'), n);
  ov.querySelector('#pcCancel').onclick = close;
  ov.querySelector('#pcCall').onclick = () => { close(); callNumber(n); };
}

function openContact(number, opts) {
  opts = opts || {};
  const n = normNum(number);
  const cust0 = findCustomer(n);
  const lastRec = lastRecordFor(n);
  const inList = !!cust0;
  const name0 = (cust0 && cust0.name) || (lastRec && lastRec.name) || opts.name || '';
  const memo0 = (cust0 && cust0.memo) || (lastRec && lastRec.memo) || '';
  const curTag0 = (cust0 && cust0.tag) || (lastRec && lastRec.tag) || '';
  const cnt = callCountFor(n);
  const lastMd = lastRec ? recDateMD(lastRec) : '';
  const bits = [];
  if (curTag0) bits.push('최근 결과 <b>' + esc(curTag0) + '</b>');
  if (lastMd) bits.push('마지막 통화 ' + lastMd);
  if (cnt) bits.push('통화 ' + cnt + '회');
  const info = bits.length ? bits.join(' · ') : '통화 기록 없음';
  const tagBtns = TAGS.map(t => `<button class="tag${t === curTag0 ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');

  const { ov, close } = buildOverlay('contactOv',
    `<div class="cp-ov-h">고객 <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="cp-ov-note">${info}</div>
     <div class="cp-ov-lbl">이름</div>
     <input type="text" id="ctName" value="${esc(name0)}" placeholder="이름" autocomplete="off">
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="ctTags">${tagBtns}</div>
     <div class="cp-ov-lbl">메모</div>
     <textarea id="ctMemo" rows="3" placeholder="이 고객 메모…">${esc(memo0)}</textarea>
     <div class="row">
       <button class="btn primary" id="ctCall">📞 전화</button>
       <button class="btn blue" id="ctMsg">✉️ 메시지</button>
     </div>
     <div class="row">
       <button class="btn ghost ${inList ? 'danger' : ''}" id="ctAddDel">${inList ? '🗑 고객 삭제' : '＋ 고객목록에 추가'}</button>
       <button class="btn primary" id="ctSave">저장</button>
     </div>
     <div class="cp-ov-lbl">🎙 통화 녹음</div>
     <div class="ct-rec" id="ctRec"><button class="btn ghost" id="ctRecLoad">🎙 녹음 불러오기</button></div>`);

  // 통화 녹음 로드/재생
  const recBox = ov.querySelector('#ctRec');
  ov.querySelector('#ctRecLoad').onclick = () => loadRecordingsInto(recBox, n);

  let selTag = curTag0;
  ov.querySelectorAll('#ctTags .tag').forEach(b => b.onclick = () => {
    selTag = (selTag === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#ctTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === selTag));
  });

  // 이름·메모·결과 저장 → 고객(있으면) + 최근 통화기록에 반영. 없으면 고객 신규 추가.
  function persist() {
    const nm = (ov.querySelector('#ctName').value || '').trim();
    const mm = (ov.querySelector('#ctMemo').value || '').trim();
    let c = findCustomer(n);
    if (!c) { c = ensureCustomerFields({ name: nm || '(이름없음)', number: n, memo: mm, tag: selTag, done: false }); queue.push(c); }
    else { if (nm) c.name = nm; c.memo = mm; c.tag = selTag; c.updatedAt = nowIso(); }
    const r = lastRecordFor(n);
    if (r) { r.tag = selTag; r.memo = mm; if (nm) r.name = nm; r.time = nowIso(); }
    if (selTag === '차단요청') addToBlocklist(n);
    save('cp_queue', queue); save('cp_records', records);
    renderQueue(); renderRecords();
    if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화(추가·수정 바로 PC 반영)
    return c;
  }

  ov.querySelector('#ctCall').onclick = () => {
    persist(); close();
    // 통화한 적 있는 사람이면 발신 전 미리보기(메시지·녹음 보고 걸지 결정), 처음이면 바로 발신
    const hasHist = callCountFor(n) > 0 || (sysCalls && sysCalls.some(c => c.number === n));
    if (hasHist) openPreCall(n, name0); else callNumber(n);
  };
  ov.querySelector('#ctMsg').onclick = () => { persist(); openMsgPicker(n); };
  ov.querySelector('#ctSave').onclick = () => { persist(); close(); toast('저장했어요'); };
  ov.querySelector('#ctAddDel').onclick = () => {
    if (inList) {
      const i2 = queue.findIndex(x => normNum(x.number) === n);
      if (i2 >= 0) { const rem = queue[i2]; queue.splice(i2, 1); addTombstone(rem.number); if (i2 < idx) idx--; save('cp_queue', queue); renderQueue(); if (window.cpSyncNow) window.cpSyncNow(); }
      close(); toast('고객을 삭제했어요');
    } else {
      persist();   // 신규 고객 추가(이름·메모·결과 반영)
      close(); toast('고객목록에 추가했어요');
    }
  };
}

// ============================================================
//  ✉️ 메시지 양식(템플릿) — 저장해두고 골라서 보내기
// ============================================================
function msgTemplates() { try { return JSON.parse(localStorage.getItem('cp_msg_tpl') || '[]'); } catch (e) { return []; } }
function saveMsgTemplates(list) { try { localStorage.setItem('cp_msg_tpl', JSON.stringify(list)); return true; } catch (e) { return false; } }
function tplPreview(t) { const b = (t.body || '').trim(); const im = (t.images && t.images.length) ? ' 📷' + t.images.length : ''; return (b ? esc(b.slice(0, 46)) : '(사진만)') + im; }

// 메시지 버튼 → 저장된 양식 중 선택해서 보내기 (없으면 빈 메시지/양식 추가 안내)
function openMsgPicker(number) {
  const n = normNum(number);
  const tpls = msgTemplates();
  const items = tpls.map(t =>
    `<button class="btn ghost cm-btn" data-tid="${t.id}" style="text-align:left;white-space:normal">${tplPreview(t)}</button>`).join('');
  const { ov, close } = buildOverlay('msgPickOv',
    `<div class="cp-ov-h">메시지 보내기 <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="cp-ov-note">${tpls.length ? '보낼 양식을 고르세요. 메시지앱이 내용·사진 채워져서 열립니다.' : '저장된 양식이 없어요. 아래에서 메시지·사진을 저장해두세요.'}</div>
     ${items}
     <button class="btn ghost cm-btn" id="mpBlank">✏️ 빈 메시지로 열기</button>
     <button class="btn ghost cm-btn" id="mpEdit">⚙️ 양식 편집·추가</button>
     <button class="btn ghost cm-btn" id="mpCancel">취소</button>`);
  ov.querySelectorAll('[data-tid]').forEach(b => b.onclick = () => {
    const t = msgTemplates().find(x => x.id === b.dataset.tid);
    close();
    if (t && t.images && t.images.length) openMsgPreview(n, t);   // 사진 있으면 미리보기 후 전송
    else { messageNumber(n, (t && t.body) || ''); toast('메시지앱을 엽니다…'); }
  });
  ov.querySelector('#mpBlank').onclick = () => { close(); messageNumber(n, ''); toast('메시지앱을 엽니다…'); };
  ov.querySelector('#mpEdit').onclick = () => { close(); openMsgTemplates(n); };
  ov.querySelector('#mpCancel').onclick = close;
}

// 보내기 전 미리보기 — 메시지앱(갤럭시 메시지)에 실제로 갈 내용·사진을 말풍선으로 확인
function openMsgPreview(number, t) {
  const n = normNum(number);
  const imgs = (t.images || []).map(src => `<img class="mp-img" src="${src}">`).join('');
  const { ov, close } = buildOverlay('msgPrevOv',
    `<div class="cp-ov-h">메시지 미리보기 <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="mp-thread">
       ${t.body ? `<div class="mp-bubble">${esc(t.body)}</div>` : ''}
       ${imgs ? `<div class="mp-imgs">${imgs}</div>` : ''}
     </div>
     <div class="cp-ov-note">보내기를 누르면 폰 메시지앱이 <b>사진 ${(t.images || []).length}장 + 내용</b>이 채워진 채로 열려요. 거기서 <b>보내기</b>를 눌러야 실제로 전송됩니다. 내용이 안 채워지면 메시지앱에서 붙여넣기 하세요(자동 복사됨).</div>
     <div class="row">
       <button class="btn primary" id="mpvSend">📨 메시지앱으로 보내기</button>
       <button class="btn ghost" id="mpvCopy">📋 내용 복사</button>
     </div>
     <button class="btn ghost" id="mpvCancel" style="margin-top:8px">취소</button>`);
  ov.querySelector('#mpvSend').onclick = () => { close(); messageNumber(n, t.body || '', t.images || []); toast('메시지앱을 엽니다 · 내용은 클립보드에도 복사됨'); };
  ov.querySelector('#mpvCopy').onclick = async () => { const ok = await copyToClip(t.body || ''); toast(ok ? '내용을 복사했어요' : '복사 실패'); };
  ov.querySelector('#mpvCancel').onclick = close;
}

// 양식 관리(추가·삭제) — 이름 없이 '보낼 내용' 한 곳 + 사진 최대 2장
function openMsgTemplates(backNumber) {
  const list = msgTemplates();
  const rows = list.map(t =>
    `<div class="mt-row" data-tid="${t.id}">
       <div class="mt-txt"><div class="mt-body">${esc(t.body || '')}</div>${(t.images && t.images.length) ? '<span class="mt-imgc">📷 사진 ' + t.images.length + '장</span>' : ''}</div>
       <button class="mt-del" data-del="${t.id}" title="삭제">🗑</button>
     </div>`).join('');
  const { ov, close } = buildOverlay('msgTplOv',
    `<div class="cp-ov-h">메시지 양식</div>
     <div class="cp-ov-note">보낼 메시지와 사진(최대 2장)을 저장해두고 골라서 보냅니다.</div>
     <div id="mtList">${rows || '<div class="grp-empty">저장된 양식이 없어요</div>'}</div>
     <div class="cp-ov-lbl">새 양식 — 보낼 내용</div>
     <textarea id="mtBody" rows="3" placeholder="보낼 메시지 내용…"></textarea>
     <div class="mt-photos" id="mtThumbs"></div>
     <input type="file" id="mtFile" accept="image/*" multiple style="display:none">
     <button class="btn ghost" id="mtAddPhoto" style="margin-top:8px">📷 사진 추가 (여러 장 가능)</button>
     <div class="row">
       <button class="btn primary" id="mtAdd">＋ 양식 저장</button>
       <button class="btn ghost" id="mtClose">닫기</button>
     </div>`);
  const MAXP = 10;   // 사진 최대 장수(여러 장)
  let newImgs = [];
  function renderThumbs() {
    const el = ov.querySelector('#mtThumbs'); el.innerHTML = '';
    newImgs.forEach((src, i) => {
      const w = document.createElement('div'); w.className = 'mt-thumb';
      w.innerHTML = `<img src="${src}"><button class="mt-thumb-x">✕</button>`;
      w.querySelector('.mt-thumb-x').onclick = () => { newImgs.splice(i, 1); renderThumbs(); };
      el.appendChild(w);
    });
    ov.querySelector('#mtAddPhoto').style.display = newImgs.length >= MAXP ? 'none' : '';
  }
  ov.querySelector('#mtAddPhoto').onclick = () => ov.querySelector('#mtFile').click();
  ov.querySelector('#mtFile').onchange = async (e) => {
    const files = [...(e.target.files || [])];
    for (const f of files) { if (newImgs.length >= MAXP) break; try { newImgs.push(await resizeImageFile(f, 1080, 0.8)); } catch (err) {} }
    e.target.value = ''; renderThumbs();
  };
  ov.querySelectorAll('[data-del]').forEach(b => b.onclick = () => {
    saveMsgTemplates(msgTemplates().filter(x => x.id !== b.dataset.del));
    close(); openMsgTemplates(backNumber);   // 새로고침
  });
  ov.querySelector('#mtAdd').onclick = () => {
    const body = (ov.querySelector('#mtBody').value || '').trim();
    if (!body && !newImgs.length) { toast('메시지 내용이나 사진을 넣으세요'); return; }
    const list2 = msgTemplates();
    list2.push({ id: newId(), body: body, images: newImgs.slice() });
    if (!saveMsgTemplates(list2)) { toast('저장 공간 부족 — 사진 수/크기를 줄여주세요', 3000); return; }
    close(); openMsgTemplates(backNumber);
  };
  ov.querySelector('#mtClose').onclick = () => { close(); if (backNumber) openMsgPicker(backNumber); };
}

// 다시 걸기: 최근 결과가 부재/나중연락인 번호 → 부재 횟수·통화 날짜 보고 골라서 발신목록에 재추가
function openRedial() {
  const byNum = {};
  records.forEach(r => {
    const n = normNum(r.number); if (!n) return;
    if (!byNum[n]) byNum[n] = { number: n, name: '', buje: 0, later: 0, bujeDates: [], last: 0, lastTag: '' };
    const g = byNum[n];
    if (r.name && r.name !== '(이름없음)') g.name = r.name;
    const t = r.dialAt ? new Date(r.dialAt).getTime() : (r.time ? new Date(r.time).getTime() : 0);
    if (r.tag === '부재') { g.buje++; if (t) g.bujeDates.push(t); }
    else if (r.tag === '나중연락') g.later++;
    if (t >= g.last) { g.last = t; g.lastTag = r.tag || ''; }
  });
  let cands = Object.values(byNum).filter(g => g.lastTag === '부재' || g.lastTag === '나중연락');
  cands.sort((a, b) => a.last - b.last);   // 오래된(먼저 연락해야 할) 순
  const DAY = 86400000;
  const inQ = new Set(queue.filter(q => !q.done).map(q => normNum(q.number)));   // 이미 발신대기 중인 번호
  const { ov, close } = buildOverlay('redialOv',
    `<div class="cp-ov-h">🔁 다시 걸기 <span class="cp-ov-sub">부재·나중연락 ${cands.length}명</span></div>
     <div class="cp-ov-note">부재 횟수와 마지막 통화일을 보고, 오늘 다시 걸 사람을 골라 발신목록(통화 전)에 올리세요.</div>
     <div class="rd-filter" id="rdFilter">
       <button class="rd-f on" data-d="0">전체</button>
       <button class="rd-f" data-d="1">1일↑ 지남</button>
       <button class="rd-f" data-d="2">2일↑ 지남</button>
       <button class="rd-f" data-d="3">3일↑ 지남</button>
     </div>
     <div class="rd-list" id="rdList"></div>
     <div class="row">
       <button class="btn primary" id="rdAdd">선택 발신목록에 추가</button>
       <button class="btn ghost" id="rdClose">닫기</button>
     </div>`);
  let minDays = 0;
  const picked = new Set();
  function daysAgo(t) { return t ? Math.floor((Date.now() - t) / DAY) : 999; }
  function mdOf(t) { const d = new Date(t); return isNaN(d) ? '' : `${d.getMonth() + 1}/${d.getDate()}`; }
  function draw() {
    const list = ov.querySelector('#rdList');
    const shown = cands.filter(g => daysAgo(g.last) >= minDays);
    if (!shown.length) { list.innerHTML = '<div class="rd-empty">해당하는 대상이 없어요.</div>'; return; }
    list.innerHTML = shown.map(g => {
      const da = daysAgo(g.last);
      const dates = g.bujeDates.sort((a, b) => a - b).map(mdOf).filter(Boolean).join(', ');
      const cntTxt = [g.buje ? `부재 ${g.buje}회` : '', g.later ? `나중연락 ${g.later}회` : ''].filter(Boolean).join(' · ');
      const already = inQ.has(g.number) ? ' <span class="rd-inq">발신대기중</span>' : '';
      return `<label class="rd-row${picked.has(g.number) ? ' pk' : ''}" data-n="${g.number}">
        <input type="checkbox" ${picked.has(g.number) ? 'checked' : ''}>
        <div class="rd-main">
          <div class="rd-top"><b>${esc(g.name || '(이름없음)')}</b> <span class="rd-no">${fmt(g.number)}</span>${already}</div>
          <div class="rd-meta">${cntTxt || '재콜 대상'} · 마지막 ${mdOf(g.last)} (${da}일 전)${dates ? ' · 부재일: ' + dates : ''}</div>
        </div></label>`;
    }).join('');
    list.querySelectorAll('.rd-row').forEach(row => {
      const n = row.dataset.n, cb = row.querySelector('input');
      cb.onchange = () => { if (cb.checked) picked.add(n); else picked.delete(n); row.classList.toggle('pk', cb.checked); };
    });
  }
  ov.querySelectorAll('#rdFilter .rd-f').forEach(b => b.onclick = () => {
    minDays = +b.dataset.d;
    ov.querySelectorAll('#rdFilter .rd-f').forEach(x => x.classList.toggle('on', x === b));
    draw();
  });
  ov.querySelector('#rdClose').onclick = close;
  ov.querySelector('#rdAdd').onclick = () => {
    if (!picked.size) { toast('추가할 사람을 선택하세요'); return; }
    let added = 0;
    picked.forEach(n => {
      const g = byNum[n]; if (!g) return;
      const ex = queue.find(q => normNum(q.number) === n);
      if (ex) { ex.done = false; ex.tag = ''; ex.updatedAt = nowIso(); }   // 이미 목록에 있으면 다시 '안 건'으로 되돌림(PC에도 전파)
      else { queue.push(ensureCustomerFields({ name: g.name || '(이름없음)', number: n, done: false })); }
      added++;
    });
    save('cp_queue', queue); renderQueue();
    close(); toast(`${added}명을 발신목록(통화 전)에 올렸어요`);
  };
  draw();
}
$('redialBtn').onclick = openRedial;
$('wipeBtn').onclick = () => {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  if (confirm('통화기록을 삭제할까요?')) { records = []; save('cp_records', records); renderRecords(); }
};

const scriptBox = $('scriptBox');
if (scriptBox) {
  scriptBox.value = load('cp_script', '');
  scriptBox.addEventListener('input', () => save('cp_script', scriptBox.value));
}
const defaultDialerBtn = $('defaultDialerBtn');
if (defaultDialerBtn) defaultDialerBtn.onclick = async () => {
  try { if (Dialer) await Dialer.requestDefaultDialer(); } catch (e) {}
  await refreshDefaultDialer();
  toast(isDefaultDialer ? '기본 전화 앱으로 설정됨' : '설정 화면에서 콜파일럿을 선택해주세요', 2600);
};

if (Dialer) {
  Dialer.addListener('callStateChanged', (ev) => onCallEvent(ev || {}));
  // 콜드 스타트 복구: 앱이 (수신 전화로) 막 켜졌으면 놓친 신호를 현재 상태로 보완
  Dialer.getCurrentCall().then(c => {
    if (c && c.state && c.state !== 'NONE' && c.state !== 'DISCONNECTED') onCallEvent(c);
  }).catch(() => {});
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) { refreshDefaultDialer(); loadSystemCalls(); } });
refreshDefaultDialer();

(function () {
  const v = document.querySelector('.brand .ver');
  const wv = (window.CPOta && window.CPOta.webVersion) ? ' · 웹 v' + window.CPOta.webVersion : '';
  if (v) v.textContent = (isNative ? (Dialer ? '모바일 · 실기기' : '모바일 · ⚠️모듈없음') : '모바일 · 미리보기') + wv;
})();

// 🔆 화면 계속 켜두기 / 홀드 — 기본은 '켜둠'(앱 켜져 있으면 화면 안 꺼짐). 홀드 누르면 꺼짐 허용.
let keepAwake = load('cp_keepawake', true);
function syncKeepAwake() {
  const b = $('keepAwakeBtn'); if (!b) return;
  b.textContent = keepAwake ? '🔆 화면 켜둠' : '💤 홀드';
  b.classList.toggle('on', keepAwake);
  b.classList.toggle('hold', !keepAwake);
  try { if (Dialer && Dialer.setKeepAwake) Dialer.setKeepAwake(keepAwake).catch(() => {}); } catch (e) {}
}
{ const kb = $('keepAwakeBtn'); if (kb) kb.onclick = () => {
    keepAwake = !keepAwake; save('cp_keepawake', keepAwake); syncKeepAwake();
    toast(keepAwake ? '화면을 계속 켜둡니다' : '홀드 — 화면이 꺼질 수 있어요', 2200);
  }; }
syncKeepAwake();

migrateQueue();
buildTagButtons();
renderQueue(); renderRecords(); setStatus('대기');
loadSystemCalls();   // 폰 시스템 통화기록 → 최근 통화(PC 없이도)
