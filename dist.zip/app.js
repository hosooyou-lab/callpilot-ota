// ============================================================
//  콜파일럿 모바일 — 자동발신 + 수신 (기본 전화 앱 방식)
//
//  콜파일럿이 "기본 전화 앱" → 통화화면을 직접 담당.
//   발신: DIALING(신호) → ACTIVE(상대가 받음) → DISCONNECTED(종료). 정확한 통화시간.
//   수신: RINGING(걸려옴, 받기/거절) → ACTIVE(통화) → DISCONNECTED.
//     · 기존 고객(목록에 있거나 통화한 적 있는 번호)이면 자동으로 통화기록 저장.
//     · 처음 보는 번호는 "고객 저장" 버튼을 눌러야 목록·기록에 남김.
// ============================================================

const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
const PLUGIN = 'CallPilotDialer';
const Dialer = (isNative && Cap.nativePromise) ? {
  dial:          (o) => Cap.nativePromise(PLUGIN, 'dial', o || {}),
  sendSms:       (o) => Cap.nativePromise(PLUGIN, 'sendSms', o || {}),
  sendMms:       (o) => Cap.nativePromise(PLUGIN, 'sendMms', o || {}),
  callLog:       (o) => Cap.nativePromise(PLUGIN, 'callLog', o || {}),
  listRecordings:(o) => Cap.nativePromise(PLUGIN, 'listRecordings', o || {}),
  prepRecording: (o) => Cap.nativePromise(PLUGIN, 'prepRecording', o || {}),
  playRecording: (o) => Cap.nativePromise(PLUGIN, 'playRecording', o || {}),
  pausePlayback: ()  => Cap.nativePromise(PLUGIN, 'pausePlayback', {}),
  resumePlayback:()  => Cap.nativePromise(PLUGIN, 'resumePlayback', {}),
  seekPlayback:  (o) => Cap.nativePromise(PLUGIN, 'seekPlayback', o || {}),
  stopPlayback:  ()  => Cap.nativePromise(PLUGIN, 'stopPlayback', {}),
  getPlaybackState:()=> Cap.nativePromise(PLUGIN, 'getPlaybackState', {}),
  hasStoragePermission: () => Cap.nativePromise(PLUGIN, 'hasStoragePermission', {}),
  requestStoragePermission: () => Cap.nativePromise(PLUGIN, 'requestStoragePermission', {}),
  hasMicPermission:     () => Cap.nativePromise(PLUGIN, 'hasMicPermission', {}),
  ensureMicPermission:  () => Cap.nativePromise(PLUGIN, 'ensureMicPermission', {}),
  endCall:       ()  => Cap.nativePromise(PLUGIN, 'endCall', {}),
  answerCall:    ()  => Cap.nativePromise(PLUGIN, 'answerCall', {}),
  startWatching: ()  => Cap.nativePromise(PLUGIN, 'startWatching', {}),
  stopWatching:  ()  => Cap.nativePromise(PLUGIN, 'stopWatching', {}),
  deviceId:      ()  => Cap.nativePromise(PLUGIN, 'deviceId', {}),
  requestAllPermissions: () => Cap.nativePromise(PLUGIN, 'requestAllPermissions', {}),
  isDefaultDialer:     () => Cap.nativePromise(PLUGIN, 'isDefaultDialer', {}),
  requestDefaultDialer:() => Cap.nativePromise(PLUGIN, 'requestDefaultDialer', {}),
  setKeepAwake:  (on) => Cap.nativePromise(PLUGIN, 'setKeepAwake', { on: !!on }),
  setMute:       (on) => Cap.nativePromise(PLUGIN, 'setMute', { on: !!on }),
  setSpeaker:    (on) => Cap.nativePromise(PLUGIN, 'setSpeaker', { on: !!on }),
  getCurrentCall:()  => Cap.nativePromise(PLUGIN, 'getCurrentCall', {}),
  prefGet:       (o) => Cap.nativePromise(PLUGIN, 'prefGet', o || {}),
  prefSet:       (o) => Cap.nativePromise(PLUGIN, 'prefSet', o || {}),
  bringToFront:  ()  => Cap.nativePromise(PLUGIN, 'bringToFront', {}),
  hasOverlayPermission:     () => Cap.nativePromise(PLUGIN, 'hasOverlayPermission', {}),
  requestOverlayPermission: () => Cap.nativePromise(PLUGIN, 'requestOverlayPermission', {}),
  ensureNotificationPermission:  () => Cap.nativePromise(PLUGIN, 'ensureNotificationPermission', {}),
  hasFullScreenIntentPermission: () => Cap.nativePromise(PLUGIN, 'hasFullScreenIntentPermission', {}),
  requestFullScreenIntentPermission: () => Cap.nativePromise(PLUGIN, 'requestFullScreenIntentPermission', {}),
  addListener:   (ev, cb) => Cap.addListener(PLUGIN, ev, cb),
} : null;

const $ = (id) => document.getElementById(id);
const toastEl = $('toast');
let toastTimer = null;
function toast(msg, ms = 1800) {
  if (!toastEl) return;
  toastEl.textContent = msg; toastEl.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.hidden = true, ms);
}

// ---- 상태 ----
let queue = load('cp_queue', []);
let records = load('cp_records', []);
let sysCalls = [];   // 폰 시스템 통화기록(READ_CALL_LOG) — 최근 통화 표시용
let blocklist = load('cp_blocklist', []);
let running = false;
let idx = -1;
let phase = 'idle';          // idle | call | waiting
let panelMode = 'dial';      // dial | ring | inActive
let curTag = '';
let curDuration = 0;
let dialAt = 0;
let activeAt = 0;
let callWasActive = false;
let callEnded = false;
let waitTimer = null, safetyTimer = null;
let isDefaultDialer = false;
let muteOn = false, speakerOn = false;
// 📞 삼성 통화모드: 삼성 기본 전화앱이 통화·녹음 담당 → 콜파일럿은 스크립트 화면을 통화 위로 자동으로 띄움.
//    (콜파일럿이 기본 전화앱일 필요 없음. 삼성 자동 통화녹음이 양방향으로 확실히 됨.)
let samsungMode = load('cp_samsung_mode', false);
let samsungInCall = false;   // 삼성모드 수신 통화 진행 중(RINGING~IDLE 추적)
let _lastBringUp = 0;
function samsungBringUp() {
  if (!samsungMode || !Dialer || !Dialer.bringToFront) return;
  const now = Date.now(); if (now - _lastBringUp < 700) return; _lastBringUp = now;   // 과다호출 방지
  Dialer.bringToFront().catch(() => {});   // 권한 없으면 조용히 무시(토글 켤 때 안내함)
}
// 삼성모드에선 수신 전화를 앱이 살아있는 동안 감지하려면 통화상태 감시를 상시 켜둬야 한다
// (기본은 자동발신 '시작' 때만 켜짐 → 유휴 상태 수신을 놓침).
function ensureWatching() {
  try { if (samsungMode && Dialer && Dialer.startWatching) Dialer.startWatching().catch(() => {}); } catch (e) {}
}
// 수신 통화용
let incomingNumber = '';
let incomingKnown = false;
let incomingSaved = false;
let pausedForIncoming = false;

const TAGS = ['가망', '부재', '거부', '나중연락', '방문예약', '차단요청'];
function getScript() { const b = $('scriptBox'); return b ? b.value : ''; }

function load(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
function save(k, v) {
  try { localStorage.setItem(k, JSON.stringify(v)); }
  catch (e) { toast('⚠ 저장 실패 — 저장공간을 확인하세요', 3000); }
}

// ---- 유틸 ----
function normNum(n) { return String(n == null ? '' : n).replace(/[^\d]/g, ''); }
function isBlocked(n) { return blocklist.includes(normNum(n)); }
function addToBlocklist(n) {
  n = normNum(n);
  if (n && !blocklist.includes(n)) { blocklist.push(n); save('cp_blocklist', blocklist); }
}
function isKnownNumber(num) {
  const n = normNum(num);
  return queue.some(q => normNum(q.number) === n) || records.some(r => normNum(r.number) === n);
}
function lookupName(num) {
  const n = normNum(num);
  const q = queue.find(x => normNum(x.number) === n);
  if (q && q.name && q.name !== '(이름없음)') return q.name;
  const r = [...records].reverse().find(x => normNum(x.number) === n && x.name && x.name !== '(이름없음)');
  return r ? r.name : '';
}
function newId(seed) {
  try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return String(seed || Date.now()) + '-' + Math.random().toString(16).slice(2);
}
function makeRecord(t, tag, memo, durationSec, dialTs) {
  return {
    id: newId(dialTs),
    name: t.name, number: normNum(t.number),
    tag: tag || '', memo: memo || '',
    dialAt: new Date(dialTs || Date.now()).toISOString(),
    durationSec: durationSec || 0,
    time: new Date().toISOString(),
  };
}
function suggestTag() { return callWasActive ? '' : '부재'; }

// ---- 동기화용 (고객에 id·수정시각, 삭제 tombstone) ----
function nowIso() { return new Date().toISOString(); }
let tombstones = load('cp_tombstones', []);   // [{number, at}] — 삭제 전파용
function addTombstone(number) {
  const n = normNum(number);
  tombstones = tombstones.filter(t => t.number !== n);
  tombstones.push({ number: n, at: nowIso() });
  save('cp_tombstones', tombstones);
}
function ensureCustomerFields(c) {
  if (!c.id) c.id = newId();
  if (!c.updatedAt) c.updatedAt = nowIso();
  return c;
}
function migrateQueue() {
  let changed = false;
  queue.forEach(c => { if (!c.id || !c.updatedAt) { ensureCustomerFields(c); changed = true; } });
  if (changed) save('cp_queue', queue);
}

// ---- 목록 파싱 ----
function parseLines(text) {
  return text.split(/\n/).map(l => l.trim()).filter(Boolean).map(l => {
    let name = '', num = '';
    const parts = l.includes('\t') ? l.split('\t') : (l.includes(',') ? l.split(',') : null);
    if (parts) {
      const a = (parts[0] || '').trim(), b = (parts[1] || '').trim();
      const aNum = normNum(a), bNum = normNum(b);
      if (bNum.length >= 8) { name = a; num = bNum; }
      else if (aNum.length >= 8) { name = b || '(이름없음)'; num = aNum; }
      else { name = a; num = bNum; }
    } else {
      const m = l.match(/[\d][\d\s-]{6,}/);
      num = m ? normNum(m[0]) : '';
      name = m ? l.replace(m[0], '').trim() : l;
    }
    return { name: name || '(이름없음)', number: num, done: false };
  }).filter(x => x.number.length >= 8);
}

// ---- 렌더 ----
function renderQueue() {
  $('queueCount').textContent = queue.length + '명';
  const ul = $('queueList'); ul.innerHTML = '';
  // 2그룹: 아직 안 건(!done) / 통화 끝난(done). 원래 인덱스(i) 보존해 삭제·현재표시 유지.
  const indexed = queue.map((q, i) => ({ q, i }));
  const groups = [
    { label: '📞 통화 전', done: false, items: indexed.filter(x => !x.q.done) },
    { label: '✅ 통화 후', done: true, items: indexed.filter(x => x.q.done) },
  ];
  // 좌우 2열: 왼쪽=통화 전 / 오른쪽=통화 후
  const cols = document.createElement('div');
  cols.className = 'q-cols';
  groups.forEach(g => {
    const col = document.createElement('div');
    col.className = 'q-col';
    const head = document.createElement('div');
    head.className = 'grp';
    head.textContent = `${g.label} (${g.items.length})`;
    col.appendChild(head);
    if (!g.items.length) {
      const e = document.createElement('div'); e.className = 'grp-empty'; e.textContent = '없음';
      col.appendChild(e);
    } else {
      // 항목은 3개까지만 보이고 나머지는 이 안에서 스크롤 (목록이 길어도 화면 안 밀림)
      const items = document.createElement('div');
      items.className = 'q-items';
      g.items.forEach(({ q, i }) => {
        const li = document.createElement('li');
        if (q.done) li.className = 'done';
        if (i === idx && running) li.className = 'active';
        // 통화 후 결과 태그는 '결과가 있을 때만' 오른쪽에 표시(빈 '결과 입력' 칩 없음 → 한 줄 컴팩트)
        const tagHtml = (g.done && q.tag) ? `<span class="rtag">${esc(q.tag)}</span>` : '';
        const nameHtml = q.name ? `<span class="nm">${esc(q.name)}</span>` : '';
        li.innerHTML = `<div class="qbody">` + nameHtml +
          `<span class="no">${fmt(q.number)}</span>` + tagHtml + `</div>`;
        // 번호를 누르면 통합 상세창(정보·메모·전화·메시지·추가/삭제) — 통화 전/후 모두
        li.querySelector('.qbody').onclick = () => openContact(q.number, { name: q.name });
        items.appendChild(li);
      });
      col.appendChild(items);
    }
    cols.appendChild(col);
  });
  ul.appendChild(cols);
}
function deleteQueueItem(i) {
  if (running && i === idx) { toast('통화 중인 항목은 지울 수 없어요'); return; }
  const removed = queue[i];
  queue.splice(i, 1);
  if (removed) addTombstone(removed.number);   // 삭제를 PC에도 전파
  if (i < idx) idx--;
  save('cp_queue', queue); renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화(삭제 바로 PC 반영)
}
function recDateMD(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  return (d && !isNaN(d)) ? `${d.getMonth() + 1}/${d.getDate()}` : '';
}
function renderRecords() {
  $('recCount').textContent = records.length + '건';
  const ul = $('recordList'); ul.innerHTML = '';
  // 전체 표시(최신순). 누르면 결과·메모 수정.
  records.slice().reverse().forEach(r => {
    const li = document.createElement('li');
    li.className = 'rec-item';
    const md = recDateMD(r);
    const meta = [];
    if (r.name && r.name !== '(이름없음)' && r.name !== '(수신)' && r.name !== '(발신)') meta.push(esc(r.name));
    if (r.durationSec) meta.push(r.durationSec + '초');
    if (md) meta.push(md);
    li.innerHTML = `<span class="rtag">${esc(r.tag || '-')}</span>`
      + `<span class="rmeta">${meta.join(' · ')}</span>`
      + `<span class="no">${fmt(r.number)}</span>`;
    li.onclick = () => openContact(r.number, { name: r.name });
    ul.appendChild(li);
  });
  renderRecent();
  renderTodayStats();
}
// 📊 오늘 현황 — 오늘(로컬 날짜) 기록 기준 콜/연결/가망/방문예약/부재 요약 칩
function isTodayRec(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  return !!(d && !isNaN(d) && d.toDateString() === new Date().toDateString());
}
function isConnectedRec(r) {
  return (r.durationSec > 0) || !!(r.tag && r.tag !== '부재' && r.tag !== '건너뜀');
}
function renderTodayStats() {
  const card = $('todayStatCard'), box = $('statChips');
  if (!card || !box) return;
  const today = records.filter(isTodayRec);
  if (!today.length) { card.hidden = true; box.innerHTML = ''; return; }
  const total = today.length;
  const connected = today.filter(isConnectedRec).length;
  const rate = total ? Math.round(connected / total * 100) : 0;
  const cnt = (tag) => today.filter(r => r.tag === tag).length;
  const chips = [
    { n: total, label: '오늘 콜' },
    { n: connected, label: `연결 (${rate}%)` },
    { n: cnt('가망'), label: '가망' },
    { n: cnt('방문예약'), label: '방문예약' },
    { n: cnt('부재'), label: '부재' },
  ];
  box.innerHTML = chips.map(c => `<div class="chip"><b>${esc(String(c.n))}</b><span>${esc(c.label)}</span></div>`).join('');
  card.hidden = false;
}
// 📞 최근 통화 — 번호별 최신 1건(중복 제거)만, 최신순 상위 8개. 전화앱처럼 눌러서 상세창.
function recTimeShort(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  if (!d || isNaN(d)) return '';
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12;
    return `${ap} ${h}:${m}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}
// 폰 시스템 통화기록 읽기(READ_CALL_LOG) → PC 연결 없이도 최근 통화 표시
async function loadSystemCalls() {
  if (!Dialer || !Dialer.callLog) return;
  try {
    const r = await Dialer.callLog({ limit: 60 });
    const calls = (r && r.calls) || [];
    sysCalls = calls.map(c => ({ number: normNum(c.number), name: c.name || '', date: +c.date || 0, type: +c.type || 0, duration: +c.duration || 0 }))
      .filter(c => c.number);
    renderRecent();
  } catch (e) { /* 권한 없거나 실패 → 로컬 기록으로 */ }
}
// 통화가 막 끝나도 안드로이드 CallLog엔 바로 안 남는 경우가 있어, 잠시 뒤 다시 불러옴.
// (중복 타이머 방지 — 연달아 호출돼도 마지막 예약 하나만 실행됨)
let sysCallsReloadTimer = null;
function scheduleSystemCallsReload(delayMs) {
  clearTimeout(sysCallsReloadTimer);
  sysCallsReloadTimer = setTimeout(loadSystemCalls, delayMs || 1800);
}
// 통화 방향/부재 → 화살표·색. (안드로이드 CallLog TYPE: 1 수신·2 발신·3 부재·5 거절·6 차단)
function callMark(type) {
  if (type === 2) return { arrow: '↗', color: 'var(--ok)' };                 // 발신(초록)
  if (type === 3 || type === 5 || type === 6) return { arrow: '↙', color: 'var(--bad)', missed: true }; // 부재중(빨강)
  if (type === 1) return { arrow: '↙', color: '#5b9bd5' };                    // 수신(파랑)
  return { arrow: '↗', color: 'var(--ok)' };
}
function renderRecent() {
  const card = $('recentCard'), ul = $('recentList');
  if (!card || !ul) return;
  const seen = new Set(); const rows = [];
  if (sysCalls && sysCalls.length) {
    // 시스템 통화기록 우선(폰 실제 최근통화). 번호별 최신 1건.
    sysCalls.forEach(c => {
      if (seen.has(c.number)) return; seen.add(c.number);
      const rec = records.slice().reverse().find(r => normNum(r.number) === c.number);
      const nm = (c.name || (rec && rec.name)) || fmt(c.number);
      rows.push({ number: c.number, name: nm, tag: rec ? rec.tag : '', time: c.date ? new Date(c.date) : null, type: c.type });
    });
  } else {
    records.slice().reverse().forEach(r => {
      const n = normNum(r.number); if (!n || seen.has(n)) return; seen.add(n);
      const nm = (r.name && r.name !== '(이름없음)' && r.name !== '(수신)' && r.name !== '(발신)') ? r.name : fmt(r.number);
      const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
      // 로컬 기록엔 통화방향이 없음 → 태그로 추정(수신/부재)
      const type = r.tag === '수신' ? 1 : (r.tag === '부재' ? 3 : 2);
      rows.push({ number: n, name: nm, tag: r.tag, time: d, type });
    });
  }
  const top = rows.slice(0, 8);
  ul.innerHTML = '';
  if (!top.length) { card.hidden = true; return; }
  card.hidden = false;
  top.forEach(row => {
    const li = document.createElement('li');
    li.className = 'rec-item';
    const m = callMark(row.type);
    li.innerHTML = `<span class="rc-arrow" style="color:${m.color}">${m.arrow}</span>`
      + `<span class="rc-main">${esc(row.name)}</span>`
      + (m.missed ? `<span class="rc-missed">부재중</span>` : '')
      + (row.tag ? `<span class="rtag">${esc(row.tag)}</span>` : '')
      + `<span class="rc-time">${row.time ? whenFull(row.time) : ''}</span>`;
    li.onclick = () => openContact(row.number, { name: row.name });
    ul.appendChild(li);
  });
}
function timeShort(d) {
  if (!d || isNaN(d)) return '';
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12; return `${ap} ${h}:${m}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}
// 최근통화용 — 날짜 + 시간 함께(오늘은 시간만, 지난 날은 날짜+시간)
function whenFull(d) {
  if (!d || isNaN(d)) return '';
  let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
  const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12; const t = `${ap} ${h}:${m}`;
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return t;
  return `${d.getMonth() + 1}/${d.getDate()} ${t}`;
}
function esc(s) { return String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])); }
function fmt(n) { n = String(n || ''); return n.length === 11 ? n.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3') : n; }

function setStatus(text, cls) {
  $('statusText').textContent = text;
  $('dot').className = 'dot' + (cls ? ' ' + cls : '');
}

// ---- 결과 태그 ----
function buildTagButtons() {
  const row = $('tagRow'); if (!row) return;
  row.innerHTML = '';
  TAGS.forEach(t => {
    const b = document.createElement('button');
    b.className = 'tag'; b.dataset.tag = t; b.textContent = t;
    b.onclick = () => { curTag = t; [...row.querySelectorAll('.tag')].forEach(x => x.classList.toggle('on', x === b)); };
    row.appendChild(b);
  });
}
function highlightTag() {
  [...document.querySelectorAll('#tagRow .tag')].forEach(b => b.classList.toggle('on', b.dataset.tag === curTag));
}

// ---- 통화 패널 ----
function setPanelMode(mode) {
  panelMode = mode;
  const dial = mode === 'dial', ring = mode === 'ring', inA = mode === 'inActive';
  const disp = (id, on) => { const e = $(id); if (e) e.style.display = on ? '' : 'none'; };
  $('callPanel').classList.toggle('ringing', ring);
  disp('ringRow', ring);
  disp('callScript', dial || inA);   // 발신 중·통화 중 모두 스크립트 크게 표시(수신 통화도)
  $('callCtl').style.display = (dial || inA) ? 'flex' : 'none';
  disp('tagRow', dial);
  disp('memoLabel', dial || inA);   // 📝 메모 라벨 — 스크립트 밑에 메모장이 켜져 있음을 명확히
  disp('memoBox', dial || inA);
  disp('saveRow', dial);
  disp('saveCustomerBtn', inA && !incomingKnown);
  disp('endCallBtn', !ring);
  // 통화 중(발신·수신 통화)엔 위쪽 큰 아바타를 줄여 스크립트+메모에 공간을 준다
  const cf = $('callFull'); if (cf) cf.classList.toggle('cf-oncall', dial || inA);
  $('endCallBtn').textContent = dial ? '■ 통화 종료 · 자동발신 정지' : '■ 통화 종료';
  $('callHead').firstChild.textContent = dial ? '통화 ' : (ring ? '수신 전화 ' : '수신 통화 ');
}
function closeAllOverlays() {
  document.querySelectorAll('.cp-ov').forEach(o => o.remove());
}
// 📞 통화 상태를 PC(같은 wifi·페어링)로 전송 → PC 화면에 "폰 통화 중 · 번호" 배너
function pushLiveCall(state, number, name, incoming) {
  try { if (window.cpLiveCall) window.cpLiveCall({ state, number: normNum(number), name: name || '', incoming: !!incoming }); } catch (e) {}
}
function openCallPanel(mode, name, number) {
  closeAllOverlays();   // 전화 걸기/받기 시작하면 열려있던 고객창·미리보기 등 모두 닫기
  ensureCallFull();
  const nm = (name || '').trim();
  $('memoTarget').textContent = (name ? name + ' · ' : '') + fmt(number || '');
  // 전체화면 상단 — 큰 아바타·이름·번호(삼성 기본 전화 앱 느낌)
  $('cfAvatar').textContent = nm ? nm.charAt(0).toUpperCase() : '👤';
  $('cfName').textContent = nm || fmt(number || '') || '알 수 없음';
  $('cfNum').textContent = nm ? fmt(number || '') : '';
  // 콜 스크립트는 발신·통화 중 모두 크게 보이게 채워둔다(수신 통화 포함)
  $('callScript').textContent = getScript() || '';
  if (mode === 'dial') {
    $('memoBox').value = ''; curTag = ''; highlightTag();
    $('callState').textContent = '발신 중…';
  } else if (mode === 'ring') {
    $('callState').textContent = '📞 수신 전화 — 받으시겠어요?';
  } else {
    $('memoBox').value = '';
    $('callState').textContent = incomingKnown ? '통화 중 · 기존 고객(자동 저장됨)' : '통화 중 · 새 번호';
  }
  muteOn = false; speakerOn = false; syncCtl();
  setPanelMode(mode);
  cfResetGestures();
  $('callFull').hidden = false;
  $('callPanel').hidden = false;
  // 통화 시작(발신·통화 중)엔 콜 스크립트가 잘 보이는 위치로 스크롤 — 스크립트 보며 메모.
  // 수신 벨(ring)일 땐 큰 받기 버튼이 보이도록 패널 상단으로.
  setTimeout(() => {
    try {
      const target = (mode === 'ring') ? $('callPanel') : ($('callScript') || $('callPanel'));
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {}
  }, 140);
}
function closeCallPanel() {
  $('callPanel').hidden = true;
  const cf = $('callFull'); if (cf) { cf.hidden = true; cf.style.height = ''; cf.style.transform = ''; cf.classList.remove('memoing'); }
  stopCfTimer();
  cfResetGestures();
}

// ⌨ 통화 중 메모 입력 시 키보드가 콜 스크립트를 가리지 않게:
//   ① 보이는 영역(visualViewport)에 통화화면을 딱 맞춰 키보드가 화면을 밀어 스크립트가 위로 사라지는 걸 막고
//   ② 메모칸 포커스 동안엔 .memoing 으로 덜 중요한 하단 컨트롤을 접어 스크립트+메모를 같이 보이게 한다.
function bindCallKeyboard() {
  const vv = window.visualViewport;
  const cf = () => document.getElementById('callFull');
  function fit() {
    const el = cf(); if (!el || el.hidden || !vv) return;
    el.style.height = Math.round(vv.height) + 'px';
    // adjustPan/adjustResize 어느 쪽이든: 보이는 영역 위로 통화화면을 이동(키보드에 안 가리게)
    el.style.transform = 'translateY(' + Math.round(vv.offsetTop || 0) + 'px)';
  }
  if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); }
  const memo = document.getElementById('memoBox');
  if (memo) {
    memo.addEventListener('focus', () => {
      const el = cf(); if (el) el.classList.add('memoing');
      setTimeout(fit, 60);
      setTimeout(() => { try { memo.scrollIntoView({ block: 'nearest' }); } catch (e) {} }, 140);
    });
    memo.addEventListener('blur', () => {
      const el = cf(); if (el) el.classList.remove('memoing');
      setTimeout(fit, 60);
    });
  }
}
function syncCtl() {
  $('muteBtn').classList.toggle('on', muteOn);
  $('speakerBtn').classList.toggle('on', speakerOn);
}

// ============================================================
//  📱 전체화면 통화 UI(callfull) — 삼성 기본 전화 앱처럼
//   #callPanel을 그대로 이 안으로 옮겨 쓴다(id·이벤트 로직은 손대지 않음).
//   받기=위로 스와이프, 거절=2초 길게 누르기. 짧게 탭만 하면 안내 토스트만(오작동 방지).
// ============================================================
let callFullBuilt = false;
function ensureCallFull() {
  if (callFullBuilt) return;
  callFullBuilt = true;
  const full = document.createElement('div');
  full.id = 'callFull'; full.className = 'callfull'; full.hidden = true;
  full.innerHTML = `
    <div class="cf-id">
      <div class="cf-avatar" id="cfAvatar">👤</div>
      <div class="cf-name" id="cfName">—</div>
      <div class="cf-num" id="cfNum"></div>
      <div class="cf-timer" id="cfTimer" hidden>00:00</div>
    </div>`;
  const panel = $('callPanel');
  if (panel) full.appendChild(panel);   // 통화패널을 전체화면 컨테이너 안으로 이동(속 id·이벤트 로직은 그대로)
  document.body.appendChild(full);

  // 받기/거절 버튼을 원형 아이콘 + 안내문구로 재구성 (id는 그대로 유지 — 기존 로직과 호환)
  const ansBtn = $('answerBtn'), rejBtn = $('rejectBtn');
  if (ansBtn) ansBtn.innerHTML = '<span class="cf-ic">📞</span><span class="cf-hint">위로 밀어서 받기</span>';
  if (rejBtn) rejBtn.innerHTML = '<span class="cf-hold-ring" id="cfRejectRing"></span><span class="cf-ic">⊘</span><span class="cf-hint">길게 눌러 거절</span>';
  if (ansBtn) setupAnswerSwipe(ansBtn, doAnswer);
  if (rejBtn) setupRejectHold(rejBtn, doReject);

  // 음소거·스피커는 아이콘만 작게(on/off 강조는 기존 syncCtl()이 그대로 처리)
  const mb = $('muteBtn'), sb = $('speakerBtn');
  if (mb) { mb.textContent = '🔇'; mb.title = '음소거'; mb.setAttribute('aria-label', '음소거'); }
  if (sb) { sb.textContent = '🔊'; sb.title = '스피커'; sb.setAttribute('aria-label', '스피커'); }
}

// ⏱ 통화 시간 타이머 — 실제 연결(activeAt) 시점부터 카운트업, 패널이 닫힐 때 정지
let cfTimerInt = null;
function startCfTimer() {
  if (cfTimerInt) return;   // 이미 돌고 있으면 중복 시작 안 함
  const el = $('cfTimer'); if (!el) return;
  const t0 = activeAt || Date.now();
  el.hidden = false;
  const tick = () => {
    const s = Math.max(0, Math.round((Date.now() - t0) / 1000));
    el.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  };
  tick();
  cfTimerInt = setInterval(tick, 1000);
}
function stopCfTimer() {
  if (cfTimerInt) { clearInterval(cfTimerInt); cfTimerInt = null; }
  const el = $('cfTimer'); if (el) { el.hidden = true; el.textContent = '00:00'; }
}

// 진행 중이던 스와이프/홀드 제스처 상태 초기화 (패널을 열고 닫을 때 호출)
function cfResetGestures() {
  const ans = $('answerBtn'); if (ans) { ans.classList.remove('dragging', 'ready'); ans.style.transform = ''; }
  const rej = $('rejectBtn'); if (rej) rej.classList.remove('holding');
  const ring = document.getElementById('cfRejectRing'); if (ring) ring.style.setProperty('--p', '0');
}

// 📞 받기 — 위로 스와이프해서 임계값을 넘으면 응답. 살짝 탭만 하면(오작동 방지) 안내만 띄움.
function setupAnswerSwipe(btn, onAnswer) {
  const THRESH = -70;
  let dragging = false, dy = 0, moved = false;
  function reset() { dragging = false; moved = false; btn.classList.remove('dragging', 'ready'); btn.style.transform = ''; }
  btn.addEventListener('pointerdown', (e) => {
    if (panelMode !== 'ring') return;
    dragging = true; moved = false; dy = 0;
    btn.dataset.startY = String(e.clientY);
    btn.classList.add('dragging');
    try { btn.setPointerCapture(e.pointerId); } catch (err) {}
  });
  btn.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    dy = Math.min(0, e.clientY - Number(btn.dataset.startY || 0));
    if (Math.abs(dy) > 6) moved = true;
    btn.style.transform = `translateY(${Math.max(dy, THRESH * 1.3)}px)`;
    btn.classList.toggle('ready', dy <= THRESH);
  });
  function finish(e) {
    if (!dragging) return;
    const reached = dy <= THRESH;
    try { if (e && e.pointerId != null) btn.releasePointerCapture(e.pointerId); } catch (err) {}
    reset();
    if (reached) onAnswer();
    else if (!moved) toast('위로 밀어서 받기', 1400);
  }
  btn.addEventListener('pointerup', finish);
  btn.addEventListener('pointercancel', reset);
  btn.addEventListener('lostpointercapture', () => { if (dragging) reset(); });
}

// ⊘ 거절 — 2초 길게 누르면 종료. 짧게 탭만 하면(오작동 방지) 안내만 띄움.
function setupRejectHold(btn, onReject) {
  const DURATION = 2000;
  let holding = false, raf = null, t0 = 0;
  function setProgress(p) {
    const ring = document.getElementById('cfRejectRing');
    if (ring) ring.style.setProperty('--p', String(Math.max(0, Math.min(1, p))));
  }
  function stop() {
    holding = false;
    if (raf) cancelAnimationFrame(raf); raf = null;
    btn.classList.remove('holding');
  }
  function step() {
    if (!holding) return;
    const el = Date.now() - t0;
    setProgress(el / DURATION);
    if (el >= DURATION) { stop(); setProgress(0); onReject(); return; }
    raf = requestAnimationFrame(step);
  }
  btn.addEventListener('pointerdown', (e) => {
    if (panelMode !== 'ring') return;
    holding = true; t0 = Date.now();
    btn.classList.add('holding');
    try { btn.setPointerCapture(e.pointerId); } catch (err) {}
    raf = requestAnimationFrame(step);
  });
  function cancel(e) {
    if (!holding) return;
    const wasTap = (Date.now() - t0) < 260;
    try { if (e && e.pointerId != null) btn.releasePointerCapture(e.pointerId); } catch (err) {}
    stop(); setProgress(0);
    if (wasTap) toast('길게 눌러 거절', 1400);
  }
  btn.addEventListener('pointerup', cancel);
  btn.addEventListener('pointercancel', () => { stop(); setProgress(0); });
  btn.addEventListener('lostpointercapture', () => { if (holding) { stop(); setProgress(0); } });
}

async function doAnswer() { try { if (Dialer) await Dialer.answerCall(); } catch (e) {} }
async function doReject() {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  closeCallPanel(); phase = 'idle';
  if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기');
}

// ---- 자동발신 ----
async function refreshDefaultDialer() {
  if (!Dialer || !Dialer.isDefaultDialer) { isDefaultDialer = false; return; }
  try { const r = await Dialer.isDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); }
  catch (e) { isDefaultDialer = false; }
  // 삼성 통화모드에선 콜파일럿이 기본앱이면 '안 됨'(삼성이 녹음 담당) → 이 버튼 숨김
  const btn = $('defaultDialerBtn'); if (btn) btn.hidden = isDefaultDialer || !isNative || samsungMode;
}

async function startAuto() {
  if (!queue.some(q => !q.done)) { toast('걸 대상이 없습니다'); return; }
  if (!isNative) toast('브라우저 미리보기: 발신은 흉내만 냅니다', 2600);

  if (Dialer && Dialer.requestAllPermissions) {
    try {
      const r = await Dialer.requestAllPermissions();
      if (r && r.granted === false) { toast('전화·통화상태·통화제어 권한을 모두 허용해야 시작할 수 있어요', 3200); return; }
    } catch (e) { toast('권한 확인 실패'); return; }
  }

  // 🎙 통화 자동녹음용 마이크 권한(선택 — 없어도 발신은 진행, 녹음만 스킵)
  if (Dialer && Dialer.ensureMicPermission) { try { await Dialer.ensureMicPermission(); } catch (e) {} }

  await refreshDefaultDialer();
  if (isNative && Dialer && samsungMode) {
    // 📞 삼성 통화모드: 스크립트 팝업은 '풀스크린 인텐트 알림'으로 뜬다(오버레이 권한 불필요).
    //    필요한 건 알림 권한 + (안드14) 전체화면 알림 권한.
    try { if (Dialer.ensureNotificationPermission) await Dialer.ensureNotificationPermission(); } catch (e) {}
    try {
      const f = Dialer.hasFullScreenIntentPermission ? await Dialer.hasFullScreenIntentPermission() : null;
      if (f && !f.granted) {
        toast('스크립트 팝업을 위해 "전체 화면 알림" 권한을 켜주세요', 3600);
        try { await Dialer.requestFullScreenIntentPermission(); } catch (e) {}
        return;   // 권한 켜고 다시 시작
      }
    } catch (e) {}
  } else if (isNative && Dialer && !isDefaultDialer) {
    const go = confirm(
      '콜파일럿을 "기본 전화 앱"으로 설정해야 통화화면에 스크립트·메모가 뜹니다.\n\n' +
      '설정하면 통화화면을 콜파일럿이 담당합니다.\n\n지금 설정할까요?'
    );
    if (go) {
      try { const r = await Dialer.requestDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); } catch (e) {}
      await refreshDefaultDialer();
      if (!isDefaultDialer) { toast('기본 전화 앱으로 설정한 뒤 다시 시작을 눌러주세요', 3200); return; }
    } else {
      toast('기본 전화 앱 미설정 — 통화화면에 스크립트가 안 보일 수 있어요', 3000);
    }
  }

  running = true;
  $('startBtn').disabled = true; $('stopBtn').disabled = false; $('nextBtn').disabled = false;
  try { if (Dialer) await Dialer.startWatching(); } catch (e) { toast('통화상태 권한 필요'); }
  idx = queue.findIndex(q => !q.done) - 1;
  nextCall();
}

async function nextCall() {
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  if (!running || pausedForIncoming) return;

  do { idx++; } while (idx < queue.length && queue[idx].done);
  if (idx >= queue.length) { toast('목록 끝 — 완료'); stopAuto(); return; }
  const t = queue[idx];

  if (isBlocked(t.number)) {
    queue[idx].done = true;
    queue[idx].tag = '차단-건너뜀';
    queue[idx].updatedAt = nowIso();
    records.push(makeRecord(t, '차단-건너뜀', '', 0, Date.now()));
    save('cp_queue', queue); save('cp_records', records);
    renderQueue(); renderRecords();
    toast(`${t.name} · 차단번호 — 건너뜀`);
    safetyTimer = setTimeout(() => { if (running) nextCall(); }, 300);
    return;
  }

  samsungInCall = false;   // 발신 시작 — 혹시 남아있던 수신 추적 상태 리셋(이벤트 오분류 방지)
  phase = 'call'; dialAt = Date.now(); activeAt = 0; callWasActive = false; callEnded = false;
  curDuration = 0; curTag = '';
  setStatus('발신 중', 'call'); renderQueue();
  openCallPanel('dial', t.name, t.number);

  try {
    if (Dialer) await Dialer.dial({ number: t.number });
    else if (!isNative) mockCall();
    else { $('callState').textContent = '발신 모듈 없음 — 재설치 필요'; toast('플러그인 로드 실패'); stopAuto(); return; }
    // 삼성 통화모드: 발신하면 삼성 통화화면이 뜨므로, 콜파일럿 스크립트 화면을 그 위로 다시 띄운다(두 번 시도).
    if (samsungMode) { setTimeout(samsungBringUp, 600); setTimeout(samsungBringUp, 1600); }
  } catch (e) {
    $('callState').textContent = '발신 실패 — 권한을 확인하세요';
    toast('전화 걸기 권한을 허용해주세요');
    callEnded = true; curTag = '부재';
    return;
  }

  safetyTimer = setTimeout(() => {
    if (running && phase === 'call' && !callEnded) { callEnded = true; $('callState').textContent = '통화 종료(추정) · 결과 저장'; }
  }, 120000);
}

// 통화 상태 이벤트 (발신 + 수신 통합)
// 📲 삼성 통화모드 수신 처리 — 삼성이 벨을 울리고 통화를 담당, 콜파일럿은 팝업(풀스크린 인텐트)을
//    띄워 탭하면 스크립트가 보이게 한다. 번호는 이 경로(TelephonyCallback)에선 안 와서 생략.
function handleSamsungIncoming(st, number) {
  if (st === 'RINGING') {
    samsungInCall = true;
    incomingNumber = number || ''; incomingKnown = number ? isKnownNumber(number) : false; incomingSaved = false;
    activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
    if (running) { pausedForIncoming = true; clearTimeout(waitTimer); clearTimeout(safetyTimer); }
    phase = 'call';
    openCallPanel('inActive', number ? lookupName(number) : '', number || '');   // 스크립트 보이는 모드(받기는 삼성에서)
    $('callState').textContent = '📲 수신 전화 — 삼성 화면에서 받으세요';
    setStatus('수신 전화', 'watch');
    samsungBringUp(); setTimeout(samsungBringUp, 800);   // 팝업 띄우기(발신처럼 재시도)
    return;
  }
  if (st === 'OFFHOOK' || st === 'ACTIVE') {   // 삼성에서 받음
    callWasActive = true; if (!activeAt) activeAt = Date.now();
    startCfTimer();
    $('callState').textContent = '통화 중 (수신)';
    setStatus('통화 중(수신)', 'call');
    samsungBringUp();
    return;
  }
  if (st === 'IDLE' || st === 'DISCONNECTED') {
    samsungInCall = false;
    if (!callEnded) {
      callEnded = true;
      scheduleSystemCallsReload();
      const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
      if (incomingKnown || incomingSaved) {
        const nm = lookupName(incomingNumber) || '(수신)';
        records.push(makeRecord({ name: nm, number: incomingNumber }, '수신', $('memoBox').value.trim(), dur, dialAt));
        save('cp_records', records); renderRecords();
      }
    }
    closeCallPanel(); phase = 'idle';
    if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); }
    else setStatus('대기');
    return;
  }
}

function onCallEvent(ev) {
  const st = ev && ev.state;
  const incoming = !!(ev && ev.incoming);
  const number = (ev && ev.number) || '';
  if (incoming) return handleIncoming(st, number);   // 기본 전화앱 모드(InCallService — incoming/number 있음)
  // 📲 삼성 통화모드: 네이티브가 incoming/number를 못 실어보내지만, RINGING은 '수신'이 확실하다
  //    (발신은 RINGING 없이 바로 OFFHOOK). 수신 통화 진행 동안(samsungInCall) OFFHOOK/IDLE도 여기서 처리.
  if (samsungMode && (st === 'RINGING' || samsungInCall)) return handleSamsungIncoming(st, number);

  if (!running) return handleExternalCall(st, number);   // 📞 PC/수동 발신도 통화패널 띄움(메모 가능)
  const curNum = number || (queue[idx] && queue[idx].number) || '';
  const curNm = (queue[idx] && queue[idx].name) || '';
  if (st === 'DIALING') { samsungBringUp(); $('callState').textContent = '발신 중… (신호 감)'; pushLiveCall('dialing', curNum, curNm); return; }
  if (st === 'ACTIVE' || st === 'OFFHOOK') {
    samsungBringUp();   // 삼성 통화모드: 통화 시작하면 콜파일럿 스크립트를 앞으로
    callWasActive = true;
    if (!activeAt) activeAt = Date.now();
    startCfTimer();
    if (phase === 'call' && !callEnded) $('callState').textContent = '통화 중… (상대 연결됨)';
    setStatus('통화 중', 'call');
    pushLiveCall('active', curNum, curNm);
    return;
  }
  if (st === 'DISCONNECTED' || st === 'IDLE') {
    if (phase !== 'call' || callEnded) return;
    pushLiveCall('end', curNum, curNm);
    callEnded = true;
    stopCfTimer();   // 통화 종료 시점에 타이머 정지(결과 입력하는 동안 계속 늘어나지 않게)
    scheduleSystemCallsReload();   // 최근 통화 목록도 갱신
    curDuration = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
    curTag = suggestTag(); highlightTag();
    const durTxt = callWasActive ? `통화 ${curDuration}초 · 결과 저장` : '안 받음(부재) · 저장';
    $('callState').textContent = '통화 종료됨 — ' + durTxt;
    $('memoTarget').textContent = (queue[idx] ? queue[idx].name + ' · ' + fmt(queue[idx].number) : '')
      + (curDuration ? ` · ${curDuration}초` : '');
    setStatus('결과 입력', 'watch');
  }
}

// 📞 외부(PC 발신·수동 발신) 통화 처리 — 자동발신 아닐 때도 통화패널을 띄워 메모 가능하게
function handleExternalCall(st, number) {
  if (st === 'DIALING' || st === 'OFFHOOK' || st === 'ACTIVE') {
    samsungBringUp();   // 삼성 통화모드: 수동 발신도 콜파일럿 스크립트를 앞으로
    if (phase !== 'call') {
      incomingNumber = number; incomingKnown = isKnownNumber(number); incomingSaved = false;
      activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
      phase = 'call';
      openCallPanel('inActive', lookupName(number), number);
      $('callState').textContent = (st === 'DIALING') ? '발신 중…' : '통화 중';
      setStatus('통화 중', 'call');
      pushLiveCall((st === 'DIALING') ? 'dialing' : 'active', number, lookupName(number));
    }
    if (st === 'ACTIVE' || st === 'OFFHOOK') { callWasActive = true; if (!activeAt) activeAt = Date.now(); startCfTimer(); $('callState').textContent = '통화 중'; pushLiveCall('active', number, lookupName(number)); }
    return;
  }
  if (st === 'DISCONNECTED' || st === 'IDLE') {
    if (phase !== 'call' || callEnded) return;
    pushLiveCall('end', number, lookupName(number));
    callEnded = true;
    scheduleSystemCallsReload();   // 최근 통화 목록도 갱신
    const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
    if (incomingKnown || incomingSaved) {
      const nm = lookupName(number) || '(발신)';
      records.push(makeRecord({ name: nm, number }, callWasActive ? '' : '부재', $('memoBox').value.trim(), dur, dialAt));
      save('cp_records', records); renderRecords();
    }
    closeCallPanel(); phase = 'idle'; setStatus('대기');
  }
}

// 수신 통화 처리
function handleIncoming(st, number) {
  if (st === 'RINGING') {
    incomingNumber = number; incomingKnown = isKnownNumber(number); incomingSaved = false;
    activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
    if (running) { pausedForIncoming = true; clearTimeout(waitTimer); clearTimeout(safetyTimer); }
    phase = 'call';
    openCallPanel('ring', lookupName(number), number);
    setStatus('수신 전화', 'watch');
    pushLiveCall('ringing', number, lookupName(number), true);
    // 벨만 울리다 끊기는 부재중 케이스는 DISCONNECTED 이벤트가 안 올 수도 있어 미리 한 번 예약(여유있게 20초 뒤)
    scheduleSystemCallsReload(20000);
    return;
  }
  if (st === 'ACTIVE') {
    callWasActive = true; if (!activeAt) activeAt = Date.now();
    startCfTimer();
    openCallPanel('inActive', lookupName(number), number);
    setStatus('통화 중(수신)', 'call');
    pushLiveCall('active', number, lookupName(number), true);
    return;
  }
  if (st === 'DISCONNECTED') {
    pushLiveCall('end', number, lookupName(number), true);
    if (!callEnded) {
      callEnded = true;
      scheduleSystemCallsReload();   // 최근 통화 목록도 갱신
      const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
      // 기존 고객이거나 사용자가 "고객 저장"을 누른 경우만 기록
      if (incomingKnown || incomingSaved) {
        const nm = lookupName(number) || '(수신)';
        records.push(makeRecord({ name: nm, number }, '수신', $('memoBox').value.trim(), dur, dialAt));
        save('cp_records', records); renderRecords();
      }
    }
    closeCallPanel();
    phase = 'idle';
    if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); }
    else setStatus('대기');
  }
}

async function saveAndNext() {
  if (!running || panelMode !== 'dial') return;
  if (!callEnded) { try { if (Dialer) await Dialer.endCall(); } catch (e) {} }
  if (queue[idx]) {
    queue[idx].done = true;
    queue[idx].tag = curTag || '';   // 통화 끝난 그룹에 결과 표시용
    queue[idx].updatedAt = nowIso();  // 📱 통화함 상태를 PC에도 전파(LWW)
    const dur = callEnded ? curDuration : (activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0);
    records.push(makeRecord(queue[idx], curTag, $('memoBox').value.trim(), dur, dialAt));
    if (curTag === '차단요청') addToBlocklist(queue[idx].number);
    save('cp_queue', queue); save('cp_records', records);
  }
  closeCallPanel();
  renderQueue(); renderRecords();
  if (!running) { phase = 'idle'; setStatus('대기'); return; }
  scheduleNext();
}

function scheduleNext() {
  phase = 'waiting';
  clearTimeout(waitTimer);
  const w = Math.max(0, parseInt($('waitSec').value) || 0);
  setStatus(`${w}초 후 다음`, 'watch');
  waitTimer = setTimeout(() => { if (running && !pausedForIncoming) nextCall(); }, w * 1000);
}

async function stopAuto() {
  const wasActive = (phase === 'call');
  running = false; phase = 'idle'; pausedForIncoming = false;
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  $('startBtn').disabled = false; $('stopBtn').disabled = true; $('nextBtn').disabled = true;
  try { if (Dialer && wasActive && !callEnded && panelMode === 'dial') await Dialer.endCall(); } catch (e) {}
  // 삼성모드에선 자동발신을 멈춰도 수신 감지를 계속 유지(watching 유지)
  try { if (Dialer && !samsungMode) Dialer.stopWatching(); } catch (e) {}
  closeCallPanel();
  setStatus('대기'); renderQueue();
}

// ---- 미리보기용 흉내 ----
function mockCall() {
  setTimeout(() => onCallEvent({ state: 'DIALING' }), 400);
  setTimeout(() => onCallEvent({ state: 'ACTIVE' }), 1600);
  setTimeout(() => onCallEvent({ state: 'DISCONNECTED' }), 4200);
}

// ---- 이벤트 바인딩 ----
$('addBtn').onclick = () => {
  const add = parseLines($('pasteBox').value);
  if (!add.length) { toast('인식된 번호가 없습니다'); return; }
  const existing = new Set(queue.map(q => normNum(q.number)));
  const fresh = [];
  let dup = 0;
  add.forEach(a => { const n = normNum(a.number); if (existing.has(n)) dup++; else { existing.add(n); ensureCustomerFields(a); fresh.push(a); } });
  queue = queue.concat(fresh); save('cp_queue', queue);
  $('pasteBox').value = ''; renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화
  toast(`${fresh.length}명 추가` + (dup ? ` · 중복 ${dup}명 제외` : ''));
};
// 그룹별 비우기 (삭제를 PC에도 전파 = tombstone)
function removeQueueBy(pred, msg) {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const targets = queue.filter(pred);
  if (!targets.length) { toast('비울 항목이 없어요'); return; }
  if (!confirm(msg.replace('{n}', targets.length))) return;
  targets.forEach(t => { addTombstone(t.number); });
  const del = new Set(targets.map(t => t.id));
  queue = queue.filter(q => !del.has(q.id));
  idx = -1;
  save('cp_queue', queue); renderQueue();
  if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화
}
// 🧹 목록 비우기 → 통화 전 / 통화 후 / 선택 삭제 중 고르기 (평소엔 버튼 하나만 노출)
function openClearMenu() {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const pre = queue.filter(q => !q.done).length;
  const done = queue.filter(q => q.done).length;
  const { ov, close } = buildOverlay('clearMenuOv',
    `<div class="cp-ov-h">목록 비우기</div>
     <div class="cp-ov-note">어떤 걸 지울지 고르세요.</div>
     <button class="btn ghost danger cm-btn" id="cmPre">📞 통화 전 전부 비우기 (${pre})</button>
     <button class="btn ghost danger cm-btn" id="cmDone">✅ 통화 후 전부 비우기 (${done})</button>
     <button class="btn ghost cm-btn" id="cmCancel">취소</button>`);
  ov.querySelector('#cmPre').onclick = () => { close(); removeQueueBy(q => !q.done, '통화 전 {n}명을 비울까요?'); };
  ov.querySelector('#cmDone').onclick = () => { close(); removeQueueBy(q => q.done, '통화 후 {n}명을 비울까요?'); };
  ov.querySelector('#cmCancel').onclick = close;
}
$('clearMenuBtn').onclick = openClearMenu;
// PC 동기화 카드 접기/펼치기 (기본 접힘)
{ const st = $('syncToggle'); if (st) st.onclick = () => { const c = document.getElementById('syncCard'); if (c) c.classList.toggle('collapsed'); }; }
$('startBtn').onclick = startAuto;
$('stopBtn').onclick = () => { stopAuto(); toast('정지됨'); };
// ▶▶ 다음 번호 (PC와 동일) — 통화 중이면 결과 저장 후 다음, 대기 중이면 바로 다음 발신
$('nextBtn').onclick = () => {
  if (!running) { toast('자동발신 시작 후 사용하세요'); return; }
  if (panelMode === 'dial' && !$('callPanel').hidden) saveAndNext();
  else nextCall();
};
$('saveBtn').onclick = saveAndNext;
$('skipBtn').onclick = () => { curTag = curTag || '건너뜀'; saveAndNext(); };
$('endCallBtn').onclick = async () => {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  if (panelMode !== 'dial') { closeCallPanel(); phase = 'idle'; if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기'); return; }
  stopAuto();
  toast('통화 종료 · 자동발신 멈춤');
};
// 받기/거절은 ensureCallFull()에서 setupAnswerSwipe/setupRejectHold로 바인딩(스와이프·홀드 제스처)
$('saveCustomerBtn').onclick = () => {
  const n = normNum(incomingNumber);
  if (n && !queue.some(q => normNum(q.number) === n)) {
    queue.push(ensureCustomerFields({ name: '(이름없음)', number: n, done: false }));
    save('cp_queue', queue); renderQueue();
  }
  incomingSaved = true;
  $('saveCustomerBtn').textContent = '고객목록에 저장됨 ✓';
  $('saveCustomerBtn').disabled = true;
};
$('muteBtn').onclick = async () => { muteOn = !muteOn; syncCtl(); try { if (Dialer) await Dialer.setMute(muteOn); } catch (e) {} };
$('speakerBtn').onclick = async () => { speakerOn = !speakerOn; syncCtl(); try { if (Dialer) await Dialer.setSpeaker(speakerOn); } catch (e) {} };

// ============================================================
//  🔁 다시 걸기 + 통화기록 결과 수정 (모달)
// ============================================================
// 공용 오버레이 (배경클릭·✕·Esc 로 닫힘)
function buildOverlay(id, innerHtml) {
  const old = document.getElementById(id); if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = id; ov.className = 'cp-ov';
  ov.innerHTML = `<div class="cp-ov-box">${innerHtml}</div>`;
  document.body.appendChild(ov);
  const close = () => { ov.remove(); document.removeEventListener('keydown', onEsc); };
  function onEsc(e) { if (e.key === 'Escape') close(); }
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', onEsc);
  return { ov, close };
}

// 통화기록 한 건: 결과 태그·메모 수정
function openRecordEdit(id) {
  const r = records.find(x => x.id === id); if (!r) return;
  const tagBtns = TAGS.map(t => `<button class="tag${t === r.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('recEditOv',
    `<div class="cp-ov-h">기록 수정 · ${esc(r.name || '')} <span class="cp-ov-sub">${fmt(r.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="reTags">${tagBtns}</div>
     <div class="cp-ov-lbl">메모</div>
     <textarea id="reMemo" rows="3" placeholder="메모…">${esc(r.memo || '')}</textarea>
     <div class="row">
       <button class="btn primary" id="reSave">저장</button>
       <button class="btn ghost" id="reCancel">취소</button>
     </div>`);
  let sel = r.tag || '';
  ov.querySelectorAll('#reTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#reTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#reCancel').onclick = close;
  ov.querySelector('#reSave').onclick = () => {
    r.tag = sel; r.memo = ov.querySelector('#reMemo').value.trim();
    r.time = nowIso();                       // 수정시각(동기화 LWW용)
    if (sel === '차단요청') addToBlocklist(r.number);
    // 발신목록의 같은 번호(통화 끝난)에도 결과 반영
    const q = queue.find(x => normNum(x.number) === normNum(r.number) && x.done);
    if (q) q.tag = sel;
    save('cp_records', records); save('cp_queue', queue);
    renderRecords(); renderQueue();
    close(); toast('기록을 고쳤어요');
  };
}

// 통화 후 발신목록 항목: 통화 결과(태그) 수정. 같은 번호 통화기록이 있으면 그 기록 편집기로(양방향 반영), 없으면 태그만.
function openQueueEdit(id) {
  const q = queue.find(x => x.id === id); if (!q) return;
  const rec = records.slice().reverse().find(r => normNum(r.number) === normNum(q.number));
  if (rec) { openRecordEdit(rec.id); return; }
  const tagBtns = TAGS.map(t => `<button class="tag${t === q.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('qEditOv',
    `<div class="cp-ov-h">통화 결과 · ${esc(q.name || '')} <span class="cp-ov-sub">${fmt(q.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="qeTags">${tagBtns}</div>
     <div class="row">
       <button class="btn primary" id="qeSave">저장</button>
       <button class="btn ghost" id="qeCancel">취소</button>
     </div>`);
  let sel = q.tag || '';
  ov.querySelectorAll('#qeTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#qeTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#qeCancel').onclick = close;
  ov.querySelector('#qeSave').onclick = () => {
    q.tag = sel; q.updatedAt = nowIso();
    if (sel === '차단요청') addToBlocklist(q.number);
    save('cp_queue', queue); renderQueue();
    close(); toast('통화 결과를 고쳤어요');
  };
}

// ============================================================
//  📇 통합 고객 상세창 — 어디서든 번호를 누르면 열림
//     정보·메모·통화결과 + 전화/메시지/고객추가·삭제 (PC와 동일 컨셉)
// ============================================================
function findCustomer(number) { const n = normNum(number); return queue.find(x => normNum(x.number) === n); }
function lastRecordFor(number) { const n = normNum(number); return records.slice().reverse().find(r => normNum(r.number) === n); }
function callCountFor(number) { const n = normNum(number); return records.filter(r => normNum(r.number) === n).length; }

function callNumber(number) {
  const n = normNum(number);
  if (Dialer) { Dialer.dial({ number: n }).catch(() => toast('발신 실패')); }
  else toast('통화는 폰 앱에서만 됩니다');
}
// 📋 클립보드 (복사/읽기) — 안 되는 환경 폴백 포함
async function copyToClip(text) {
  try { await navigator.clipboard.writeText(text || ''); return true; } catch (e) {}
  try {
    const ta = document.createElement('textarea'); ta.value = text || '';
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0'; document.body.appendChild(ta);
    ta.focus(); ta.select(); document.execCommand('copy'); ta.remove(); return true;
  } catch (e) { return false; }
}
async function readClip() { try { return (await navigator.clipboard.readText()) || ''; } catch (e) { return ''; } }

async function messageNumber(number, body, images) {
  const n = normNum(number);
  const imgs = Array.isArray(images) ? images.filter(Boolean) : [];
  // 메시지앱이 내용을 미리 못 채우는 기기 대비 — 보낼 내용을 클립보드에도 복사(붙여넣기로 사용)
  if (body) copyToClip(body);
  // 사진이 있으면 MMS(사진+문자 한 번에) — 네이티브 필요(새 APK)
  if (imgs.length) {
    if (Dialer && Dialer.sendMms) {
      try { await Dialer.sendMms({ number: n, body: body || '', images: imgs }); return; }
      catch (e) { toast('사진 전송은 새 APK 설치 후 됩니다 — 문자만 엽니다', 3000); }
    } else { toast('사진 전송은 새 APK 설치 후 됩니다 — 문자만 엽니다', 3000); }
  }
  if (Dialer && Dialer.sendSms) {
    try { await Dialer.sendSms({ number: n, body: body || '' }); return; }   // 폰 기본 메시지앱 열림
    catch (e) { /* 구버전 APK(메서드 없음) → 폴백 */ }
  }
  try { window.location.href = 'sms:' + n + (body ? ('?body=' + encodeURIComponent(body)) : ''); }
  catch (e) { toast('메시지는 앱 업데이트(새 APK) 후 사용하세요'); }
}

// 사진을 localStorage에 담을 수 있게 축소(긴 변 1080px·JPEG) → data URI
function resizeImageFile(file, maxPx, quality) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let w = img.width, h = img.height; const m = maxPx || 1080;
        if (w > m || h > m) { if (w >= h) { h = Math.round(h * m / w); w = m; } else { w = Math.round(w * m / h); h = m; } }
        try {
          const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
          cv.getContext('2d').drawImage(img, 0, 0, w, h);
          resolve(cv.toDataURL('image/jpeg', quality || 0.8));
        } catch (e) { resolve(reader.result); }
      };
      img.onerror = reject; img.src = reader.result;
    };
    reader.onerror = reject; reader.readAsDataURL(file);
  });
}

// ── 녹음 재생 UI 헬퍼 ────────────────────────────────────────
// 길이(ms) → m:ss
function fmtDur(ms) {
  const s = Math.max(0, Math.round((ms || 0) / 1000));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
// 시:분(오전/오후) — 날짜 헤더가 따로 있으니 행에는 시각만
function clockOf(d) {
  if (!d || isNaN(d)) return '';
  let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
  const ap = h < 12 ? '오전' : '오후'; h = h % 12 || 12; return `${ap} ${h}:${m}`;
}
// 날짜 구분 라벨 — 오늘 / 어제 / M월 D일 (요일)
const _DOW = ['일', '월', '화', '수', '목', '금', '토'];
function daySection(d) {
  const now = new Date(); const t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const d0 = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const diff = Math.round((t0 - d0) / 86400000);
  if (diff === 0) return '오늘';
  if (diff === 1) return '어제';
  return `${d.getMonth() + 1}월 ${d.getDate()}일 (${_DOW[d.getDay()]})`;
}
function dayKey(d) { return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; }

// 재생 폴링 관리(한 번에 하나만 재생)
let _recPoll = null;
function _stopRecPoll() { if (_recPoll) { clearInterval(_recPoll); _recPoll = null; } }
// 재생 종료 이벤트는 한 번만 바인딩(로드마다 붙이면 리스너 누수) — 현재 핸들러만 교체
let _onRecEnd = null, _recEndBound = false;

// 🎙 이 번호의 통화 녹음 로드 — 최근통화 목록처럼 날짜별로 정리해서 표시
async function loadRecordingsInto(box, number) {
  const n = normNum(number);
  box.innerHTML = '<div class="cp-ov-note">불러오는 중…</div>';
  if (!Dialer || !Dialer.listRecordings) { box.innerHTML = '<div class="cp-ov-note">녹음은 새 APK(업데이트) 후 됩니다</div>'; return; }
  try {
    const p = await Dialer.hasStoragePermission();
    if (!p || !p.granted) {
      box.innerHTML = '<div class="cp-ov-note">녹음 파일 접근 권한이 필요해요.</div>';
      const pb = document.createElement('button'); pb.className = 'btn ghost'; pb.textContent = '🔓 권한 허용하기';
      pb.onclick = async () => { try { await Dialer.requestStoragePermission(); toast('허용 후 다시 [녹음 불러오기]', 3000); } catch (e) {} };
      box.appendChild(pb); return;
    }
  } catch (e) {}
  let list = [];
  try { const r = await Dialer.listRecordings({ number: n }); list = (r && r.recordings) || []; }
  catch (e) { box.innerHTML = '<div class="cp-ov-note">녹음 목록 실패: ' + esc(String(e && e.message || e)) + '</div>'; return; }
  list.sort((a, b) => (b.modified || 0) - (a.modified || 0));
  if (!list.length) { box.innerHTML = '<div class="cp-ov-note">이 번호의 녹음이 없어요</div>'; return; }

  box.innerHTML = '';
  const wrap = document.createElement('div'); wrap.className = 'rec-list';
  box.appendChild(wrap);

  // 네이티브 재생 가능? (구 APK 는 WebView <audio> 로 폴백)
  const nativePlay = !!(Dialer.playRecording && Dialer.getPlaybackState);
  const fbAudio = document.createElement('audio'); fbAudio.controls = true; fbAudio.volume = 1.0;
  fbAudio.style.cssText = 'width:100%;margin-top:6px;display:none';

  // 현재 재생 중인 행 상태
  let active = null; // { row, fill, cur, playBtn, durMs }
  function resetActive() {
    _stopRecPoll();
    if (active) { active.row.classList.remove('playing'); active.playBtn.textContent = '▶'; if (active.prog) active.prog.hidden = true; }
    active = null;
  }
  _onRecEnd = resetActive;
  if (nativePlay && Dialer.addListener && !_recEndBound) {
    _recEndBound = true;
    try { Dialer.addListener('recPlaybackEnded', () => { if (_onRecEnd) _onRecEnd(); }); } catch (e) {}
  }

  let last = '';
  list.slice(0, 80).forEach(rec => {
    const dt = rec.modified ? new Date(rec.modified) : null;
    if (dt) { const k = dayKey(dt); if (k !== last) { last = k; const h = document.createElement('div'); h.className = 'rec-day'; h.textContent = daySection(dt); wrap.appendChild(h); } }

    const durMs = rec.duration || 0;
    const row = document.createElement('div'); row.className = 'rec-row';
    row.innerHTML =
      '<button class="rec-play" aria-label="재생">▶</button>' +
      '<div class="rec-meta">' +
        '<div class="rec-t">' + (dt ? clockOf(dt) : esc(rec.name)) + '</div>' +
        '<div class="rec-sub">🎙 통화 녹음</div>' +
        '<div class="rec-prog" hidden><div class="rec-prog-fill"></div></div>' +
      '</div>' +
      '<div class="rec-dur">' + (durMs ? fmtDur(durMs) : '') + '</div>';
    const playBtn = row.querySelector('.rec-play');
    const prog = row.querySelector('.rec-prog');
    const fill = row.querySelector('.rec-prog-fill');
    const durEl = row.querySelector('.rec-dur');

    playBtn.onclick = async () => {
      // 같은 행 재생 중이면 일시정지/재개
      if (active && active.row === row) {
        try {
          const st = await Dialer.getPlaybackState();
          if (st && st.playing) { await Dialer.pausePlayback(); playBtn.textContent = '▶'; _stopRecPoll(); }
          else { await Dialer.resumePlayback(); playBtn.textContent = '⏸'; startPoll(); }
        } catch (e) {}
        return;
      }
      resetActive();
      if (!nativePlay) { // 구 APK 폴백
        try {
          const pr = await Dialer.prepRecording({ path: rec.path });
          const src = (window.Capacitor && window.Capacitor.convertFileSrc) ? window.Capacitor.convertFileSrc(pr.path) : pr.path;
          fbAudio.src = src; fbAudio.style.display = 'block'; fbAudio.play();
        } catch (e) { toast('재생 실패: ' + (e && e.message || e)); }
        return;
      }
      try {
        const res = await Dialer.playRecording({ path: rec.path });
        const dur = (res && res.duration) || durMs || 0;
        if (dur && !durMs) durEl.textContent = fmtDur(dur);
        active = { row, fill, prog, playBtn, durMs: dur };
        row.classList.add('playing'); prog.hidden = false; playBtn.textContent = '⏸';
        startPoll();
      } catch (e) { toast('재생 실패: ' + (e && e.message || e)); }
    };

    // 진행바 탭 → 탐색(seek)
    prog.onclick = async (ev) => {
      if (!active || active.row !== row || !active.durMs) return;
      const r = prog.getBoundingClientRect(); const ratio = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
      try { await Dialer.seekPlayback({ ms: Math.round(ratio * active.durMs) }); } catch (e) {}
    };

    wrap.appendChild(row);
  });

  function startPoll() {
    _stopRecPoll();
    _recPoll = setInterval(async () => {
      if (!active) { _stopRecPoll(); return; }
      try {
        const st = await Dialer.getPlaybackState();
        if (!active) return;                       // 폴링 대기 중 정지됐으면 무시
        if (!st || !st.active) { resetActive(); return; }
        const dur = st.duration || active.durMs || 1;
        active.fill.style.width = Math.min(100, (st.position / dur) * 100) + '%';
        // 아이콘은 재생/일시정지/종료 시에만 갱신(폴링이 덮어써 깜빡이는 문제 방지)
      } catch (e) {}
    }, 300);
  }

  box.appendChild(fbAudio);
}

// 📞 발신 전 미리보기 — 이 사람과의 통화 이력·주고받은 문자·녹음을 보고 걸지 말지 결정
function openPreCall(number, name) {
  const n = normNum(number);
  const nm = name || lookupName(n) || fmt(n);
  const recs = records.filter(r => normNum(r.number) === n).slice().reverse();
  const cnt = recs.length; const last = recs[0];
  const bits = [];
  if (last && last.tag) bits.push('최근 결과 <b>' + esc(last.tag) + '</b>');
  if (last) { const md = recDateMD(last); if (md) bits.push('마지막 ' + md); }
  if (cnt) bits.push('통화 ' + cnt + '회');
  const info = bits.length ? bits.join(' · ') : '통화 기록 없음';
  const recRows = recs.slice(0, 6).map(r => {
    const md = recDateMD(r); const memo = r.memo ? ' · ' + esc(r.memo) : '';
    return `<div class="pc-rec"><span class="rtag">${esc(r.tag || '-')}</span>`
      + `<span class="pc-rec-m">${md}${r.durationSec ? ' · ' + r.durationSec + '초' : ''}${memo}</span></div>`;
  }).join('');

  const { ov, close } = buildOverlay('preCallOv',
    `<div class="cp-ov-h">📞 전화 걸기 전 · ${esc(nm)} <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="cp-ov-note">${info}</div>
     ${recRows ? `<div class="cp-ov-lbl">통화 이력</div><div class="pc-recs">${recRows}</div>` : ''}
     <div class="cp-ov-lbl">🎙 통화 녹음</div>
     <div class="ct-rec" id="pcRec"><button class="btn ghost" id="pcRecLoad">🎙 녹음 불러오기</button></div>
     <div class="row" style="margin-top:14px">
       <button class="btn primary" id="pcCall">📞 전화 걸기</button>
       <button class="btn ghost" id="pcCancel">취소</button>
     </div>`);
  ov.querySelector('#pcRecLoad').onclick = () => loadRecordingsInto(ov.querySelector('#pcRec'), n);
  ov.querySelector('#pcCancel').onclick = close;
  ov.querySelector('#pcCall').onclick = () => { close(); callNumber(n); };
}

// 삼성 전화앱 '통화 상세'풍 풀스크린 고객 상세 — 큰 아바타·이름·원형 액션버튼 + 편집 + 통화 이력.
// 폰 기본 연락처에는 저장하지 않고(안내문 노출) 콜파일럿 안에서만 이름·메모·결과를 관리함.
function openContact(number, opts) {
  opts = opts || {};
  const n = normNum(number);
  const cust0 = findCustomer(n);
  const lastRec = lastRecordFor(n);
  const inList = !!cust0;
  const name0 = (cust0 && cust0.name) || (lastRec && lastRec.name) || opts.name || '';
  const memo0 = (cust0 && cust0.memo) || (lastRec && lastRec.memo) || '';
  const curTag0 = (cust0 && cust0.tag) || (lastRec && lastRec.tag) || '';
  const cnt = callCountFor(n);
  const lastMd = lastRec ? recDateMD(lastRec) : '';
  const bits = [];
  if (curTag0) bits.push('최근 결과 <b>' + esc(curTag0) + '</b>');
  if (lastMd) bits.push('마지막 통화 ' + lastMd);
  if (cnt) bits.push('통화 ' + cnt + '회');
  const info = bits.length ? bits.join(' · ') : '통화 기록 없음';
  const tagBtns = TAGS.map(t => `<button class="tag${t === curTag0 ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');

  const shownName = name0 || fmt(n);
  const nameEmpty = !name0;
  const avatarCh = name0.trim() ? esc(name0.trim().charAt(0).toUpperCase()) : '👤';

  const hist = records.filter(r => normNum(r.number) === n).slice().reverse();
  const histRows = hist.length ? hist.slice(0, 40).map(r => {
    const md = recDateMD(r);
    const meta = [md, r.durationSec ? r.durationSec + '초' : ''].filter(Boolean).join(' · ');
    return `<div class="cs-h-row">
      <span class="rtag">${esc(r.tag || '-')}</span>
      <div class="cs-h-main">
        <div class="cs-h-date">${esc(meta)}</div>
        ${r.memo ? `<div class="cs-h-memo">${esc(r.memo)}</div>` : ''}
      </div>
    </div>`;
  }).join('') : '<div class="cs-empty">통화 이력이 없어요</div>';

  const old = document.getElementById('contactScreen'); if (old) old.remove();
  const sc = document.createElement('div');
  sc.id = 'contactScreen'; sc.className = 'contact-screen';
  sc.innerHTML = `
    <div class="cs-top">
      <button class="cs-icon-btn" id="csBack" aria-label="닫기">←</button>
      <div class="cs-top-title">고객 상세</div>
      <button class="cs-icon-btn" id="csEditToggle" aria-label="편집">✎</button>
    </div>
    <div class="cs-body">
      <div class="cs-head">
        <div class="cs-avatar">${avatarCh}</div>
        <div class="cs-name${nameEmpty ? ' dim' : ''}">${esc(shownName)}</div>
        ${nameEmpty ? '' : `<div class="cs-num">${fmt(n)}</div>`}
        <div class="cs-sum">${info}</div>
      </div>
      <div class="cs-actions">
        <button class="cs-act" id="csCall"><span class="cs-act-ic call">📞</span><span class="cs-act-lb">전화</span></button>
        <button class="cs-act" id="csMsg"><span class="cs-act-ic msg">✉️</span><span class="cs-act-lb">메시지</span></button>
        <button class="cs-act" id="csRecBtn"><span class="cs-act-ic">🎙</span><span class="cs-act-lb">녹음</span></button>
      </div>
      <div class="cs-rec" id="csRec" hidden></div>
      <div class="cs-card" id="csEditBox" hidden>
        <div class="cp-ov-lbl">이름</div>
        <input type="text" id="ctName" value="${esc(name0)}" placeholder="이름" autocomplete="off">
        <div class="cp-ov-lbl">통화 결과</div>
        <div class="tags" id="ctTags">${tagBtns}</div>
        <div class="cp-ov-lbl">메모</div>
        <textarea id="ctMemo" rows="3" placeholder="이 고객 메모…">${esc(memo0)}</textarea>
        <div class="row"><button class="btn primary" id="ctSave">저장</button></div>
      </div>
      <div class="cs-hist-lbl">통화 이력</div>
      <div class="cs-hist">${histRows}</div>
    </div>
    <div class="cs-bottom">
      <button class="btn ghost ${inList ? 'danger' : ''}" id="ctAddDel">${inList ? '🗑 고객 삭제' : '＋ 고객으로 저장'}</button>
      <div class="cs-note">🔒 이 고객 정보는 콜파일럿 안에만 저장됩니다 (폰 연락처에 추가되지 않아요)</div>
    </div>`;
  document.body.appendChild(sc);
  requestAnimationFrame(() => sc.classList.add('open'));

  function onEsc(e) { if (e.key === 'Escape') close(); }
  document.addEventListener('keydown', onEsc);
  function close() {
    document.removeEventListener('keydown', onEsc);
    sc.classList.remove('open');
    setTimeout(() => sc.remove(), 180);
  }
  sc.querySelector('#csBack').onclick = close;

  const editBox = sc.querySelector('#csEditBox');
  const toggleEdit = () => {
    editBox.hidden = !editBox.hidden;
    if (!editBox.hidden) editBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };
  sc.querySelector('#csEditToggle').onclick = toggleEdit;

  // 통화 녹음 로드/재생 (탭하면 펼침)
  const recBox = sc.querySelector('#csRec');
  sc.querySelector('#csRecBtn').onclick = () => {
    recBox.hidden = !recBox.hidden;
    if (!recBox.hidden && !recBox.dataset.loaded) { recBox.dataset.loaded = '1'; loadRecordingsInto(recBox, n); }
  };

  let selTag = curTag0;
  sc.querySelectorAll('#ctTags .tag').forEach(b => b.onclick = () => {
    selTag = (selTag === b.dataset.t) ? '' : b.dataset.t;
    sc.querySelectorAll('#ctTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === selTag));
  });

  // 이름·메모·결과 저장 → 고객(있으면) + 최근 통화기록에 반영. 없으면 고객 신규 추가.
  function persist() {
    const nm = (sc.querySelector('#ctName').value || '').trim();
    const mm = (sc.querySelector('#ctMemo').value || '').trim();
    let c = findCustomer(n);
    if (!c) { c = ensureCustomerFields({ name: nm || '(이름없음)', number: n, memo: mm, tag: selTag, done: false }); queue.push(c); }
    else { if (nm) c.name = nm; c.memo = mm; c.tag = selTag; c.updatedAt = nowIso(); }
    const r = lastRecordFor(n);
    if (r) { r.tag = selTag; r.memo = mm; if (nm) r.name = nm; r.time = nowIso(); }
    if (selTag === '차단요청') addToBlocklist(n);
    save('cp_queue', queue); save('cp_records', records);
    renderQueue(); renderRecords();
    if (window.cpSyncNow) window.cpSyncNow();   // 즉시 동기화(추가·수정 바로 PC 반영)
    return c;
  }

  sc.querySelector('#csCall').onclick = () => {
    persist(); close();
    // 통화한 적 있는 사람이면 발신 전 미리보기(메시지·녹음 보고 걸지 결정), 처음이면 바로 발신
    const hasHist = callCountFor(n) > 0 || (sysCalls && sysCalls.some(c => c.number === n));
    if (hasHist) openPreCall(n, name0); else callNumber(n);
  };
  sc.querySelector('#csMsg').onclick = () => { persist(); openMsgPicker(n); };
  sc.querySelector('#ctSave').onclick = () => { persist(); toast('저장했어요'); editBox.hidden = true; };
  sc.querySelector('#ctAddDel').onclick = () => {
    if (inList) {
      const i2 = queue.findIndex(x => normNum(x.number) === n);
      if (i2 >= 0) { const rem = queue[i2]; queue.splice(i2, 1); addTombstone(rem.number); if (i2 < idx) idx--; save('cp_queue', queue); renderQueue(); if (window.cpSyncNow) window.cpSyncNow(); }
      close(); toast('고객을 삭제했어요');
    } else {
      persist();   // 신규 고객 추가(이름·메모·결과 반영)
      close(); toast('고객목록에 추가했어요');
    }
  };
}

// ============================================================
//  ✉️ 메시지 양식(템플릿) — 저장해두고 골라서 보내기
// ============================================================
function msgTemplates() { try { return JSON.parse(localStorage.getItem('cp_msg_tpl') || '[]'); } catch (e) { return []; } }
function saveMsgTemplates(list) { try { localStorage.setItem('cp_msg_tpl', JSON.stringify(list)); return true; } catch (e) { return false; } }
function tplPreview(t) { const b = (t.body || '').trim(); const im = (t.images && t.images.length) ? ' 📷' + t.images.length : ''; return (b ? esc(b.slice(0, 46)) : '(사진만)') + im; }

// 메시지 버튼 → 저장된 양식 중 선택해서 보내기 (없으면 빈 메시지/양식 추가 안내)
function openMsgPicker(number) {
  const n = normNum(number);
  const tpls = msgTemplates();
  const items = tpls.map(t =>
    `<button class="btn ghost cm-btn" data-tid="${t.id}" style="text-align:left;white-space:normal">${tplPreview(t)}</button>`).join('');
  const { ov, close } = buildOverlay('msgPickOv',
    `<div class="cp-ov-h">메시지 보내기 <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="cp-ov-note">${tpls.length ? '보낼 양식을 고르세요. 메시지앱이 내용·사진 채워져서 열립니다.' : '저장된 양식이 없어요. 아래에서 메시지·사진을 저장해두세요.'}</div>
     ${items}
     <button class="btn ghost cm-btn" id="mpBlank">✏️ 빈 메시지로 열기</button>
     <button class="btn ghost cm-btn" id="mpEdit">⚙️ 양식 편집·추가</button>
     <button class="btn ghost cm-btn" id="mpCancel">취소</button>`);
  ov.querySelectorAll('[data-tid]').forEach(b => b.onclick = () => {
    const t = msgTemplates().find(x => x.id === b.dataset.tid);
    close();
    if (t && t.images && t.images.length) openMsgPreview(n, t);   // 사진 있으면 미리보기 후 전송
    else { messageNumber(n, (t && t.body) || ''); toast('메시지앱을 엽니다…'); }
  });
  ov.querySelector('#mpBlank').onclick = () => { close(); messageNumber(n, ''); toast('메시지앱을 엽니다…'); };
  ov.querySelector('#mpEdit').onclick = () => { close(); openMsgTemplates(n); };
  ov.querySelector('#mpCancel').onclick = close;
}

// 보내기 전 미리보기 — 메시지앱(갤럭시 메시지)에 실제로 갈 내용·사진을 말풍선으로 확인
function openMsgPreview(number, t) {
  const n = normNum(number);
  const imgs = (t.images || []).map(src => `<img class="mp-img" src="${src}">`).join('');
  const { ov, close } = buildOverlay('msgPrevOv',
    `<div class="cp-ov-h">메시지 미리보기 <span class="cp-ov-sub">${fmt(n)}</span></div>
     <div class="mp-thread">
       ${t.body ? `<div class="mp-bubble">${esc(t.body)}</div>` : ''}
       ${imgs ? `<div class="mp-imgs">${imgs}</div>` : ''}
     </div>
     <div class="cp-ov-note">보내기를 누르면 폰 메시지앱이 <b>사진 ${(t.images || []).length}장 + 내용</b>이 채워진 채로 열려요. 거기서 <b>보내기</b>를 눌러야 실제로 전송됩니다. 내용이 안 채워지면 메시지앱에서 붙여넣기 하세요(자동 복사됨).</div>
     <div class="row">
       <button class="btn primary" id="mpvSend">📨 메시지앱으로 보내기</button>
       <button class="btn ghost" id="mpvCopy">📋 내용 복사</button>
     </div>
     <button class="btn ghost" id="mpvCancel" style="margin-top:8px">취소</button>`);
  ov.querySelector('#mpvSend').onclick = () => { close(); messageNumber(n, t.body || '', t.images || []); toast('메시지앱을 엽니다 · 내용은 클립보드에도 복사됨'); };
  ov.querySelector('#mpvCopy').onclick = async () => { const ok = await copyToClip(t.body || ''); toast(ok ? '내용을 복사했어요' : '복사 실패'); };
  ov.querySelector('#mpvCancel').onclick = close;
}

// 양식 관리(추가·삭제) — 이름 없이 '보낼 내용' 한 곳 + 사진 최대 2장
function openMsgTemplates(backNumber) {
  const list = msgTemplates();
  const rows = list.map(t =>
    `<div class="mt-row" data-tid="${t.id}">
       <div class="mt-txt"><div class="mt-body">${esc(t.body || '')}</div>${(t.images && t.images.length) ? '<span class="mt-imgc">📷 사진 ' + t.images.length + '장</span>' : ''}</div>
       <button class="mt-del" data-del="${t.id}" title="삭제">🗑</button>
     </div>`).join('');
  const { ov, close } = buildOverlay('msgTplOv',
    `<div class="cp-ov-h">메시지 양식</div>
     <div class="cp-ov-note">보낼 메시지와 사진(최대 2장)을 저장해두고 골라서 보냅니다.</div>
     <div id="mtList">${rows || '<div class="grp-empty">저장된 양식이 없어요</div>'}</div>
     <div class="cp-ov-lbl">새 양식 — 보낼 내용</div>
     <textarea id="mtBody" rows="3" placeholder="보낼 메시지 내용…"></textarea>
     <div class="mt-photos" id="mtThumbs"></div>
     <input type="file" id="mtFile" accept="image/*" multiple style="display:none">
     <button class="btn ghost" id="mtAddPhoto" style="margin-top:8px">📷 사진 추가 (여러 장 가능)</button>
     <div class="row">
       <button class="btn primary" id="mtAdd">＋ 양식 저장</button>
       <button class="btn ghost" id="mtClose">닫기</button>
     </div>`);
  const MAXP = 10;   // 사진 최대 장수(여러 장)
  let newImgs = [];
  function renderThumbs() {
    const el = ov.querySelector('#mtThumbs'); el.innerHTML = '';
    newImgs.forEach((src, i) => {
      const w = document.createElement('div'); w.className = 'mt-thumb';
      w.innerHTML = `<img src="${src}"><button class="mt-thumb-x">✕</button>`;
      w.querySelector('.mt-thumb-x').onclick = () => { newImgs.splice(i, 1); renderThumbs(); };
      el.appendChild(w);
    });
    ov.querySelector('#mtAddPhoto').style.display = newImgs.length >= MAXP ? 'none' : '';
  }
  ov.querySelector('#mtAddPhoto').onclick = () => ov.querySelector('#mtFile').click();
  ov.querySelector('#mtFile').onchange = async (e) => {
    const files = [...(e.target.files || [])];
    for (const f of files) { if (newImgs.length >= MAXP) break; try { newImgs.push(await resizeImageFile(f, 1080, 0.8)); } catch (err) {} }
    e.target.value = ''; renderThumbs();
  };
  ov.querySelectorAll('[data-del]').forEach(b => b.onclick = () => {
    saveMsgTemplates(msgTemplates().filter(x => x.id !== b.dataset.del));
    close(); openMsgTemplates(backNumber);   // 새로고침
  });
  ov.querySelector('#mtAdd').onclick = () => {
    const body = (ov.querySelector('#mtBody').value || '').trim();
    if (!body && !newImgs.length) { toast('메시지 내용이나 사진을 넣으세요'); return; }
    const list2 = msgTemplates();
    list2.push({ id: newId(), body: body, images: newImgs.slice() });
    if (!saveMsgTemplates(list2)) { toast('저장 공간 부족 — 사진 수/크기를 줄여주세요', 3000); return; }
    close(); openMsgTemplates(backNumber);
  };
  ov.querySelector('#mtClose').onclick = () => { close(); if (backNumber) openMsgPicker(backNumber); };
}

// 다시 걸기: 최근 결과가 부재/나중연락인 번호 → 부재 횟수·통화 날짜 보고 골라서 발신목록에 재추가
function openRedial() {
  const byNum = {};
  records.forEach(r => {
    const n = normNum(r.number); if (!n) return;
    if (!byNum[n]) byNum[n] = { number: n, name: '', buje: 0, later: 0, bujeDates: [], last: 0, lastTag: '' };
    const g = byNum[n];
    if (r.name && r.name !== '(이름없음)') g.name = r.name;
    const t = r.dialAt ? new Date(r.dialAt).getTime() : (r.time ? new Date(r.time).getTime() : 0);
    if (r.tag === '부재') { g.buje++; if (t) g.bujeDates.push(t); }
    else if (r.tag === '나중연락') g.later++;
    if (t >= g.last) { g.last = t; g.lastTag = r.tag || ''; }
  });
  let cands = Object.values(byNum).filter(g => g.lastTag === '부재' || g.lastTag === '나중연락');
  cands.sort((a, b) => a.last - b.last);   // 오래된(먼저 연락해야 할) 순
  const DAY = 86400000;
  const inQ = new Set(queue.filter(q => !q.done).map(q => normNum(q.number)));   // 이미 발신대기 중인 번호
  const { ov, close } = buildOverlay('redialOv',
    `<div class="cp-ov-h">🔁 다시 걸기 <span class="cp-ov-sub">부재·나중연락 ${cands.length}명</span></div>
     <div class="cp-ov-note">부재 횟수와 마지막 통화일을 보고, 오늘 다시 걸 사람을 골라 발신목록(통화 전)에 올리세요.</div>
     <div class="rd-filter" id="rdFilter">
       <button class="rd-f on" data-d="0">전체</button>
       <button class="rd-f" data-d="1">1일↑ 지남</button>
       <button class="rd-f" data-d="2">2일↑ 지남</button>
       <button class="rd-f" data-d="3">3일↑ 지남</button>
     </div>
     <div class="rd-list" id="rdList"></div>
     <div class="row">
       <button class="btn primary" id="rdAdd">선택 발신목록에 추가</button>
       <button class="btn ghost" id="rdClose">닫기</button>
     </div>`);
  let minDays = 0;
  const picked = new Set();
  function daysAgo(t) { return t ? Math.floor((Date.now() - t) / DAY) : 999; }
  function mdOf(t) { const d = new Date(t); return isNaN(d) ? '' : `${d.getMonth() + 1}/${d.getDate()}`; }
  function draw() {
    const list = ov.querySelector('#rdList');
    const shown = cands.filter(g => daysAgo(g.last) >= minDays);
    if (!shown.length) { list.innerHTML = '<div class="rd-empty">해당하는 대상이 없어요.</div>'; return; }
    list.innerHTML = shown.map(g => {
      const da = daysAgo(g.last);
      const dates = g.bujeDates.sort((a, b) => a - b).map(mdOf).filter(Boolean).join(', ');
      const cntTxt = [g.buje ? `부재 ${g.buje}회` : '', g.later ? `나중연락 ${g.later}회` : ''].filter(Boolean).join(' · ');
      const already = inQ.has(g.number) ? ' <span class="rd-inq">발신대기중</span>' : '';
      return `<label class="rd-row${picked.has(g.number) ? ' pk' : ''}" data-n="${g.number}">
        <input type="checkbox" ${picked.has(g.number) ? 'checked' : ''}>
        <div class="rd-main">
          <div class="rd-top"><b>${esc(g.name || '(이름없음)')}</b> <span class="rd-no">${fmt(g.number)}</span>${already}</div>
          <div class="rd-meta">${cntTxt || '재콜 대상'} · 마지막 ${mdOf(g.last)} (${da}일 전)${dates ? ' · 부재일: ' + dates : ''}</div>
        </div></label>`;
    }).join('');
    list.querySelectorAll('.rd-row').forEach(row => {
      const n = row.dataset.n, cb = row.querySelector('input');
      cb.onchange = () => { if (cb.checked) picked.add(n); else picked.delete(n); row.classList.toggle('pk', cb.checked); };
    });
  }
  ov.querySelectorAll('#rdFilter .rd-f').forEach(b => b.onclick = () => {
    minDays = +b.dataset.d;
    ov.querySelectorAll('#rdFilter .rd-f').forEach(x => x.classList.toggle('on', x === b));
    draw();
  });
  ov.querySelector('#rdClose').onclick = close;
  ov.querySelector('#rdAdd').onclick = () => {
    if (!picked.size) { toast('추가할 사람을 선택하세요'); return; }
    let added = 0;
    picked.forEach(n => {
      const g = byNum[n]; if (!g) return;
      const ex = queue.find(q => normNum(q.number) === n);
      if (ex) { ex.done = false; ex.tag = ''; ex.updatedAt = nowIso(); }   // 이미 목록에 있으면 다시 '안 건'으로 되돌림(PC에도 전파)
      else { queue.push(ensureCustomerFields({ name: g.name || '(이름없음)', number: n, done: false })); }
      added++;
    });
    save('cp_queue', queue); renderQueue();
    close(); toast(`${added}명을 발신목록(통화 전)에 올렸어요`);
  };
  draw();
}
$('redialBtn').onclick = openRedial;
// ⋯ 메뉴(통화기록 카드 헤더) — 목록비우기 오버레이 패턴 재사용
function openRecordsMenu() {
  const { ov, close } = buildOverlay('recMenuOv',
    `<div class="cp-ov-h">통화기록 메뉴</div>
     <button class="btn ghost danger cm-btn" id="rmWipe">🗑 기록 전체 삭제</button>
     <button class="btn ghost cm-btn" id="rmCancel">취소</button>`);
  ov.querySelector('#rmWipe').onclick = () => {
    close();
    if (running) { toast('자동발신 정지 후 사용하세요'); return; }
    if (confirm('통화기록을 삭제할까요?')) { records = []; save('cp_records', records); renderRecords(); }
  };
  ov.querySelector('#rmCancel').onclick = close;
}
{ const rm = $('recMenuBtn'); if (rm) rm.onclick = openRecordsMenu; }

const scriptBox = $('scriptBox');
if (scriptBox) {
  scriptBox.value = load('cp_script', '');
  scriptBox.addEventListener('input', () => save('cp_script', scriptBox.value));
}
const defaultDialerBtn = $('defaultDialerBtn');
if (defaultDialerBtn) defaultDialerBtn.onclick = async () => {
  try { if (Dialer) await Dialer.requestDefaultDialer(); } catch (e) {}
  await refreshDefaultDialer();
  toast(isDefaultDialer ? '기본 전화 앱으로 설정됨' : '설정 화면에서 콜파일럿을 선택해주세요', 2600);
};

if (Dialer) {
  Dialer.addListener('callStateChanged', (ev) => onCallEvent(ev || {}));
  // 콜드 스타트 복구: 앱이 (수신 전화로) 막 켜졌으면 놓친 신호를 현재 상태로 보완
  Dialer.getCurrentCall().then(c => {
    if (c && c.state && c.state !== 'NONE' && c.state !== 'DISCONNECTED') onCallEvent(c);
  }).catch(() => {});
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) { refreshDefaultDialer(); loadSystemCalls(); } });
refreshDefaultDialer();
// 화면이 보이는 동안(콜파일럿이 통화화면을 담당 중일 때 포함) 20초마다 최근 통화 재조회 — 갱신 계기가 없어도 최신 유지
setInterval(() => { if (!document.hidden) loadSystemCalls(); }, 20000);

(function () {
  const v = document.querySelector('.brand .ver');
  const wv = (window.CPOta && window.CPOta.webVersion) ? 'v' + window.CPOta.webVersion : '';
  if (v) v.textContent = (isNative ? (Dialer ? '' : '⚠️모듈없음 ') : '미리보기 ') + wv;
})();

// 🔆 화면 계속 켜두기 / 홀드 — 기본은 '켜둠'(앱 켜져 있으면 화면 안 꺼짐). 홀드 누르면 꺼짐 허용.
let keepAwake = load('cp_keepawake', true);
function syncKeepAwake() {
  const b = $('keepAwakeBtn'); if (!b) return;
  b.textContent = keepAwake ? '🔆' : '💤';
  b.classList.toggle('on', keepAwake);
  b.classList.toggle('hold', !keepAwake);
  try { if (Dialer && Dialer.setKeepAwake) Dialer.setKeepAwake(keepAwake).catch(() => {}); } catch (e) {}
}
{ const kb = $('keepAwakeBtn'); if (kb) kb.onclick = () => {
    keepAwake = !keepAwake; save('cp_keepawake', keepAwake); syncKeepAwake();
    toast(keepAwake ? '화면을 계속 켜둡니다' : '홀드 — 화면이 꺼질 수 있어요', 2200);
  }; }
syncKeepAwake();

ensureCallFull();   // 전체화면 통화 UI를 미리 구성해둠(수신·발신 시 바로 표시)
bindCallKeyboard(); // 통화 중 메모 입력 시 키보드가 콜 스크립트를 안 가리게
ensureWatching();   // 삼성모드면 앱 켜질 때부터 수신 전화 감시 시작(자동발신 안 눌러도)

// 🔊 녹음 시 스피커폰 토글 — 기본 켜짐(값 없거나 'true'). 안드 통화녹음은 스피커여야 상대 목소리까지 잡힘.
(function () {
  const t = document.getElementById('recSpeakerToggle'); if (!t) return;
  if (Dialer && Dialer.prefGet) {
    Dialer.prefGet({ key: 'cp_rec_speaker' }).then(r => { t.checked = (!r || r.value == null || r.value !== 'false'); }).catch(() => { t.checked = true; });
    t.addEventListener('change', () => {
      Dialer.prefSet({ key: 'cp_rec_speaker', value: t.checked ? 'true' : 'false' }).catch(() => {});
      toast(t.checked ? '녹음 시 스피커폰 켜짐 — 상대 목소리까지 녹음돼요' : '녹음 시 스피커폰 끔 — 상대 목소리는 안 잡힐 수 있어요', 2600);
    });
  } else { t.checked = true; }   // 미리보기(비네이티브)에선 표시만
})();

// 📞 삼성 통화모드 토글 — 켜면 삼성이 통화·녹음하고, 콜파일럿은 스크립트 화면을 통화 위로 자동으로 띄운다.
(function () {
  const t = document.getElementById('samsungModeToggle'); if (!t) return;
  t.checked = samsungMode;
  function showSetupGuide() {
    // 알림 권한(안드13+)은 조용히 미리 요청 — 풀스크린 인텐트가 이 알림 채널로 통화화면을 띄운다
    try { if (Dialer.ensureNotificationPermission) Dialer.ensureNotificationPermission().catch(() => {}); } catch (e) {}
    const { ov, close } = buildOverlay('samsungGuideOv',
      `<div class="cp-ov-h">📞 삼성 통화모드 설정 (한 번만)</div>
       <div class="cp-ov-note" style="text-align:left;line-height:1.7">
         이 모드는 <b>삼성 기본 전화앱이 통화와 녹음</b>을 맡고, 콜파일럿은 <b>스크립트 화면을 통화 위로</b> 띄웁니다.
         상대 목소리까지 확실히 녹음돼요.<br><br>
         <b>1.</b> 콜파일럿을 <b>기본 전화앱에서 빼세요</b> — 설정 › 기본 앱 › 전화 › <b>삼성 전화</b> 선택.<br>
         <b>2.</b> 삼성 전화앱에서 <b>통화 자동 녹음</b>을 켜세요 — 삼성 전화 › ⋮ › 설정 › 통화 녹음 › 자동 녹음.<br>
         <b>3.</b> 아래 <b>"전체 화면 알림" 권한</b>을 켜세요 — 스크립트 팝업을 띄우는 데 필요합니다.
       </div>
       <div class="row"><button class="btn primary" id="sg-fsi">🔓 전체 화면 알림 권한 (필수)</button></div>
       <div class="row"><button class="btn ghost" id="sg-close">닫기</button></div>`);
    ov.querySelector('#sg-fsi').onclick = async () => { try { await Dialer.requestFullScreenIntentPermission(); } catch (e) {} };
    ov.querySelector('#sg-close').onclick = close;
  }
  t.addEventListener('change', async () => {
    samsungMode = t.checked; save('cp_samsung_mode', samsungMode);
    refreshDefaultDialer();   // '기본 전화 앱으로 설정' 버튼 노출 갱신(삼성모드면 숨김)
    if (samsungMode) {
      ensureWatching();   // 켜는 즉시 수신 전화 감시 시작
      if (Dialer && Dialer.requestFullScreenIntentPermission) showSetupGuide();
      else toast('삼성 통화모드 켜짐', 2200);
    } else {
      toast('삼성 통화모드 끔 — 콜파일럿이 통화화면을 담당하려면 기본 전화앱으로 설정하세요', 3000);
    }
  });
})();

// 🔙 안드로이드 뒤로가기 — 앱을 종료하지 않고 '앱 안에서 뒤로'(열린 창/모달 닫기)를 실행한다.
//    네이티브 MainActivity.onBackPressed가 이 함수를 호출: true 반환=처리함(앱 유지), false=닫을 것 없음(네이티브가 앱을 백그라운드로).
window.CPBack = function () {
  try {
    // 1) 떠 있는 오버레이/모달(설정가이드·메뉴·미리보기·피드백 등) 중 가장 위엣것 하나 닫기
    const ovs = document.querySelectorAll('.cp-ov, #cp-fb');
    if (ovs.length) { ovs[ovs.length - 1].remove(); return true; }
    // 2) 고객 상세 풀스크린
    const cs = document.getElementById('contactScreen');
    if (cs) { const b = document.getElementById('csBack'); if (b) b.click(); else cs.remove(); return true; }
    // 3) 통화 패널(통화 중이 아닐 때만 — 통화 중 실수로 닫히지 않게)
    const cf = document.getElementById('callFull');
    if (cf && !cf.hidden && typeof phase !== 'undefined' && phase !== 'call') { closeCallPanel(); return true; }
  } catch (e) {}
  return false;   // 닫을 게 없음 → 네이티브가 앱을 백그라운드로(종료 안 함)
};

migrateQueue();
buildTagButtons();
renderQueue(); renderRecords(); setStatus('대기');
loadSystemCalls();   // 폰 시스템 통화기록 → 최근 통화(PC 없이도)
