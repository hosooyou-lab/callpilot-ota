// ============================================================
//  콜파일럿 모바일 — 자동발신 + 수신 (기본 전화 앱 방식)
//
//  콜파일럿이 "기본 전화 앱" → 통화화면을 직접 담당.
//   발신: DIALING(신호) → ACTIVE(상대가 받음) → DISCONNECTED(종료). 정확한 통화시간.
//   수신: RINGING(걸려옴, 받기/거절) → ACTIVE(통화) → DISCONNECTED.
//     · 기존 고객(목록에 있거나 통화한 적 있는 번호)이면 자동으로 통화기록 저장.
//     · 처음 보는 번호는 "고객 저장" 버튼을 눌러야 목록·기록에 남김.
// ============================================================

const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
const PLUGIN = 'CallPilotDialer';
const Dialer = (isNative && Cap.nativePromise) ? {
  dial:          (o) => Cap.nativePromise(PLUGIN, 'dial', o || {}),
  endCall:       ()  => Cap.nativePromise(PLUGIN, 'endCall', {}),
  answerCall:    ()  => Cap.nativePromise(PLUGIN, 'answerCall', {}),
  startWatching: ()  => Cap.nativePromise(PLUGIN, 'startWatching', {}),
  stopWatching:  ()  => Cap.nativePromise(PLUGIN, 'stopWatching', {}),
  deviceId:      ()  => Cap.nativePromise(PLUGIN, 'deviceId', {}),
  requestAllPermissions: () => Cap.nativePromise(PLUGIN, 'requestAllPermissions', {}),
  isDefaultDialer:     () => Cap.nativePromise(PLUGIN, 'isDefaultDialer', {}),
  requestDefaultDialer:() => Cap.nativePromise(PLUGIN, 'requestDefaultDialer', {}),
  setMute:       (on) => Cap.nativePromise(PLUGIN, 'setMute', { on: !!on }),
  setSpeaker:    (on) => Cap.nativePromise(PLUGIN, 'setSpeaker', { on: !!on }),
  getCurrentCall:()  => Cap.nativePromise(PLUGIN, 'getCurrentCall', {}),
  addListener:   (ev, cb) => Cap.addListener(PLUGIN, ev, cb),
} : null;

const $ = (id) => document.getElementById(id);
const toastEl = $('toast');
let toastTimer = null;
function toast(msg, ms = 1800) {
  if (!toastEl) return;
  toastEl.textContent = msg; toastEl.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.hidden = true, ms);
}

// ---- 상태 ----
let queue = load('cp_queue', []);
let selQ = new Set();   // 선택 삭제용(발신목록 항목 id)
let selMode = false;    // 선택 삭제 모드일 때만 체크박스 표시
let records = load('cp_records', []);
let blocklist = load('cp_blocklist', []);
let running = false;
let idx = -1;
let phase = 'idle';          // idle | call | waiting
let panelMode = 'dial';      // dial | ring | inActive
let curTag = '';
let curDuration = 0;
let dialAt = 0;
let activeAt = 0;
let callWasActive = false;
let callEnded = false;
let waitTimer = null, safetyTimer = null;
let isDefaultDialer = false;
let muteOn = false, speakerOn = false;
// 수신 통화용
let incomingNumber = '';
let incomingKnown = false;
let incomingSaved = false;
let pausedForIncoming = false;

const TAGS = ['가망', '부재', '거부', '나중연락', '방문예약', '차단요청'];
function getScript() { const b = $('scriptBox'); return b ? b.value : ''; }

function load(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
function save(k, v) {
  try { localStorage.setItem(k, JSON.stringify(v)); }
  catch (e) { toast('⚠ 저장 실패 — 저장공간을 확인하세요', 3000); }
}

// ---- 유틸 ----
function normNum(n) { return String(n == null ? '' : n).replace(/[^\d]/g, ''); }
function isBlocked(n) { return blocklist.includes(normNum(n)); }
function addToBlocklist(n) {
  n = normNum(n);
  if (n && !blocklist.includes(n)) { blocklist.push(n); save('cp_blocklist', blocklist); }
}
function isKnownNumber(num) {
  const n = normNum(num);
  return queue.some(q => normNum(q.number) === n) || records.some(r => normNum(r.number) === n);
}
function lookupName(num) {
  const n = normNum(num);
  const q = queue.find(x => normNum(x.number) === n);
  if (q && q.name && q.name !== '(이름없음)') return q.name;
  const r = [...records].reverse().find(x => normNum(x.number) === n && x.name && x.name !== '(이름없음)');
  return r ? r.name : '';
}
function newId(seed) {
  try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return String(seed || Date.now()) + '-' + Math.random().toString(16).slice(2);
}
function makeRecord(t, tag, memo, durationSec, dialTs) {
  return {
    id: newId(dialTs),
    name: t.name, number: normNum(t.number),
    tag: tag || '', memo: memo || '',
    dialAt: new Date(dialTs || Date.now()).toISOString(),
    durationSec: durationSec || 0,
    time: new Date().toISOString(),
  };
}
function suggestTag() { return callWasActive ? '' : '부재'; }

// ---- 동기화용 (고객에 id·수정시각, 삭제 tombstone) ----
function nowIso() { return new Date().toISOString(); }
let tombstones = load('cp_tombstones', []);   // [{number, at}] — 삭제 전파용
function addTombstone(number) {
  const n = normNum(number);
  tombstones = tombstones.filter(t => t.number !== n);
  tombstones.push({ number: n, at: nowIso() });
  save('cp_tombstones', tombstones);
}
function ensureCustomerFields(c) {
  if (!c.id) c.id = newId();
  if (!c.updatedAt) c.updatedAt = nowIso();
  return c;
}
function migrateQueue() {
  let changed = false;
  queue.forEach(c => { if (!c.id || !c.updatedAt) { ensureCustomerFields(c); changed = true; } });
  if (changed) save('cp_queue', queue);
}

// ---- 목록 파싱 ----
function parseLines(text) {
  return text.split(/\n/).map(l => l.trim()).filter(Boolean).map(l => {
    let name = '', num = '';
    const parts = l.includes('\t') ? l.split('\t') : (l.includes(',') ? l.split(',') : null);
    if (parts) {
      const a = (parts[0] || '').trim(), b = (parts[1] || '').trim();
      const aNum = normNum(a), bNum = normNum(b);
      if (bNum.length >= 8) { name = a; num = bNum; }
      else if (aNum.length >= 8) { name = b || '(이름없음)'; num = aNum; }
      else { name = a; num = bNum; }
    } else {
      const m = l.match(/[\d][\d\s-]{6,}/);
      num = m ? normNum(m[0]) : '';
      name = m ? l.replace(m[0], '').trim() : l;
    }
    return { name: name || '(이름없음)', number: num, done: false };
  }).filter(x => x.number.length >= 8);
}

// ---- 렌더 ----
function renderQueue() {
  $('queueCount').textContent = queue.length + '명';
  const ul = $('queueList'); ul.innerHTML = '';
  // 2그룹: 아직 안 건(!done) / 통화 끝난(done). 원래 인덱스(i) 보존해 삭제·현재표시 유지.
  const indexed = queue.map((q, i) => ({ q, i }));
  const groups = [
    { label: '📞 통화 전', done: false, items: indexed.filter(x => !x.q.done) },
    { label: '✅ 통화 후', done: true, items: indexed.filter(x => x.q.done) },
  ];
  // 선택 삭제 세트에서 사라진 항목(id) 정리
  const liveIds = new Set(queue.map(q => q.id));
  [...selQ].forEach(id => { if (!liveIds.has(id)) selQ.delete(id); });
  // 좌우 2열: 왼쪽=통화 전 / 오른쪽=통화 후
  const cols = document.createElement('div');
  cols.className = 'q-cols';
  groups.forEach(g => {
    const col = document.createElement('div');
    col.className = 'q-col';
    const head = document.createElement('div');
    head.className = 'grp';
    head.textContent = `${g.label} (${g.items.length})`;
    col.appendChild(head);
    if (!g.items.length) {
      const e = document.createElement('div'); e.className = 'grp-empty'; e.textContent = '없음';
      col.appendChild(e);
    } else {
      g.items.forEach(({ q, i }) => {
        const li = document.createElement('li');
        if (q.done) li.className = 'done';
        if (i === idx && running) li.className = 'active';
        // 통화 후 그룹은 결과 태그를 오른쪽에 표시(누르면 수정)
        const tagHtml = g.done ? `<span class="rtag${q.tag ? '' : ' empty'}">${esc(q.tag || '결과 입력')}</span>` : '';
        // 체크박스는 '선택 삭제' 모드일 때만 표시
        const chkHtml = selMode ? `<input type="checkbox" class="qchk"${selQ.has(q.id) ? ' checked' : ''}>` : '';
        li.innerHTML = chkHtml +
          `<div class="qbody"><span class="nm">${esc(q.name)}</span>` + tagHtml +
          `<span class="no">${fmt(q.number)}</span></div>`;
        const toggleSel = () => {
          if (selQ.has(q.id)) selQ.delete(q.id); else selQ.add(q.id);
          const on = selQ.has(q.id);
          li.classList.toggle('sel', on);
          const c = li.querySelector('.qchk'); if (c) c.checked = on;
          updateDelSel();
        };
        if (selMode) {
          li.querySelector('.qchk').onclick = (e) => { e.stopPropagation(); toggleSel(); };
          if (selQ.has(q.id)) li.classList.add('sel');
        }
        // 선택모드: 본문 눌러도 체크 토글 / 평소: 통화 후 항목은 결과 수정
        li.querySelector('.qbody').onclick = () => {
          if (selMode) toggleSel();
          else if (g.done) openQueueEdit(q.id);
        };
        col.appendChild(li);
      });
    }
    cols.appendChild(col);
  });
  ul.appendChild(cols);
  updateDelSel();
}
// 선택 삭제 버튼 개수 갱신
function updateDelSel() {
  const b = $('delSelBtn'); if (!b) return;
  b.textContent = `선택 삭제 (${selQ.size})`;
}
// 선택 삭제 모드 진입/종료
function enterSelMode() {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  if (!queue.length) { toast('목록이 비어 있어요'); return; }
  selMode = true; selQ.clear();
  $('listActions').hidden = true; $('selBar').hidden = false;
  renderQueue();
  toast('지울 항목을 체크하세요');
}
function exitSelMode() {
  selMode = false; selQ.clear();
  $('listActions').hidden = false; $('selBar').hidden = true;
  renderQueue();
}
function deleteQueueItem(i) {
  if (running && i === idx) { toast('통화 중인 항목은 지울 수 없어요'); return; }
  const removed = queue[i];
  queue.splice(i, 1);
  if (removed) addTombstone(removed.number);   // 삭제를 PC에도 전파
  if (i < idx) idx--;
  save('cp_queue', queue); renderQueue();
}
function recDateMD(r) {
  const d = r.dialAt ? new Date(r.dialAt) : (r.time ? new Date(r.time) : null);
  return (d && !isNaN(d)) ? `${d.getMonth() + 1}/${d.getDate()}` : '';
}
function renderRecords() {
  $('recCount').textContent = records.length + '건';
  const ul = $('recordList'); ul.innerHTML = '';
  // 전체 표시(최신순). 누르면 결과·메모 수정.
  records.slice().reverse().forEach(r => {
    const li = document.createElement('li');
    li.className = 'rec-item';
    const dur = r.durationSec ? `<span class="rdur">${r.durationSec}초</span>` : '';
    const md = recDateMD(r);
    li.innerHTML = `<span class="nm">${esc(r.name)}</span>`
      + `<span class="rtag">${esc(r.tag || '-')}</span>` + dur
      + (md ? `<span class="rdate">${md}</span>` : '')
      + `<span class="no">${fmt(r.number)}</span>`;
    li.onclick = () => openRecordEdit(r.id);
    ul.appendChild(li);
  });
}
function esc(s) { return String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])); }
function fmt(n) { n = String(n || ''); return n.length === 11 ? n.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3') : n; }

function setStatus(text, cls) {
  $('statusText').textContent = text;
  $('dot').className = 'dot' + (cls ? ' ' + cls : '');
}

// ---- 결과 태그 ----
function buildTagButtons() {
  const row = $('tagRow'); if (!row) return;
  row.innerHTML = '';
  TAGS.forEach(t => {
    const b = document.createElement('button');
    b.className = 'tag'; b.dataset.tag = t; b.textContent = t;
    b.onclick = () => { curTag = t; [...row.querySelectorAll('.tag')].forEach(x => x.classList.toggle('on', x === b)); };
    row.appendChild(b);
  });
}
function highlightTag() {
  [...document.querySelectorAll('#tagRow .tag')].forEach(b => b.classList.toggle('on', b.dataset.tag === curTag));
}

// ---- 통화 패널 ----
function setPanelMode(mode) {
  panelMode = mode;
  const dial = mode === 'dial', ring = mode === 'ring', inA = mode === 'inActive';
  const disp = (id, on) => { const e = $(id); if (e) e.style.display = on ? '' : 'none'; };
  disp('ringRow', ring);
  disp('callScript', dial);
  $('callCtl').style.display = (dial || inA) ? 'flex' : 'none';
  disp('tagRow', dial);
  disp('memoBox', dial || inA);
  disp('saveRow', dial);
  disp('saveCustomerBtn', inA && !incomingKnown);
  disp('endCallBtn', !ring);
  $('endCallBtn').textContent = dial ? '■ 통화 종료 · 자동발신 정지' : '■ 통화 종료';
  $('callHead').firstChild.textContent = dial ? '통화 ' : (ring ? '수신 전화 ' : '수신 통화 ');
}
function openCallPanel(mode, name, number) {
  $('memoTarget').textContent = (name ? name + ' · ' : '') + fmt(number || '');
  if (mode === 'dial') {
    $('callScript').textContent = getScript() || '';
    $('memoBox').value = ''; curTag = ''; highlightTag();
    $('callState').textContent = '발신 중…';
  } else if (mode === 'ring') {
    $('callState').textContent = '📞 수신 전화 — 받으시겠어요?';
  } else {
    $('memoBox').value = '';
    $('callState').textContent = incomingKnown ? '통화 중 · 기존 고객(자동 저장됨)' : '통화 중 · 새 번호';
  }
  muteOn = false; speakerOn = false; syncCtl();
  setPanelMode(mode);
  $('callPanel').hidden = false;
  $('callPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function closeCallPanel() { $('callPanel').hidden = true; }
function syncCtl() {
  $('muteBtn').classList.toggle('on', muteOn);
  $('speakerBtn').classList.toggle('on', speakerOn);
}

// ---- 자동발신 ----
async function refreshDefaultDialer() {
  if (!Dialer || !Dialer.isDefaultDialer) { isDefaultDialer = false; return; }
  try { const r = await Dialer.isDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); }
  catch (e) { isDefaultDialer = false; }
  const btn = $('defaultDialerBtn'); if (btn) btn.hidden = isDefaultDialer || !isNative;
}

async function startAuto() {
  if (!queue.some(q => !q.done)) { toast('걸 대상이 없습니다'); return; }
  if (!isNative) toast('브라우저 미리보기: 발신은 흉내만 냅니다', 2600);

  if (Dialer && Dialer.requestAllPermissions) {
    try {
      const r = await Dialer.requestAllPermissions();
      if (r && r.granted === false) { toast('전화·통화상태·통화제어 권한을 모두 허용해야 시작할 수 있어요', 3200); return; }
    } catch (e) { toast('권한 확인 실패'); return; }
  }

  await refreshDefaultDialer();
  if (isNative && Dialer && !isDefaultDialer) {
    const go = confirm(
      '콜파일럿을 "기본 전화 앱"으로 설정해야 통화화면에 스크립트·메모가 뜹니다.\n\n' +
      '설정하면 통화화면을 콜파일럿이 담당합니다.\n\n지금 설정할까요?'
    );
    if (go) {
      try { const r = await Dialer.requestDefaultDialer(); isDefaultDialer = !!(r && r.isDefault); } catch (e) {}
      await refreshDefaultDialer();
      if (!isDefaultDialer) { toast('기본 전화 앱으로 설정한 뒤 다시 시작을 눌러주세요', 3200); return; }
    } else {
      toast('기본 전화 앱 미설정 — 통화화면에 스크립트가 안 보일 수 있어요', 3000);
    }
  }

  running = true;
  $('startBtn').disabled = true; $('stopBtn').disabled = false; $('nextBtn').disabled = false;
  try { if (Dialer) await Dialer.startWatching(); } catch (e) { toast('통화상태 권한 필요'); }
  idx = queue.findIndex(q => !q.done) - 1;
  nextCall();
}

async function nextCall() {
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  if (!running || pausedForIncoming) return;

  do { idx++; } while (idx < queue.length && queue[idx].done);
  if (idx >= queue.length) { toast('목록 끝 — 완료'); stopAuto(); return; }
  const t = queue[idx];

  if (isBlocked(t.number)) {
    queue[idx].done = true;
    queue[idx].tag = '차단-건너뜀';
    queue[idx].updatedAt = nowIso();
    records.push(makeRecord(t, '차단-건너뜀', '', 0, Date.now()));
    save('cp_queue', queue); save('cp_records', records);
    renderQueue(); renderRecords();
    toast(`${t.name} · 차단번호 — 건너뜀`);
    safetyTimer = setTimeout(() => { if (running) nextCall(); }, 300);
    return;
  }

  phase = 'call'; dialAt = Date.now(); activeAt = 0; callWasActive = false; callEnded = false;
  curDuration = 0; curTag = '';
  setStatus('발신 중', 'call'); renderQueue();
  openCallPanel('dial', t.name, t.number);

  try {
    if (Dialer) await Dialer.dial({ number: t.number });
    else if (!isNative) mockCall();
    else { $('callState').textContent = '발신 모듈 없음 — 재설치 필요'; toast('플러그인 로드 실패'); stopAuto(); return; }
  } catch (e) {
    $('callState').textContent = '발신 실패 — 권한을 확인하세요';
    toast('전화 걸기 권한을 허용해주세요');
    callEnded = true; curTag = '부재';
    return;
  }

  safetyTimer = setTimeout(() => {
    if (running && phase === 'call' && !callEnded) { callEnded = true; $('callState').textContent = '통화 종료(추정) · 결과 저장'; }
  }, 120000);
}

// 통화 상태 이벤트 (발신 + 수신 통합)
function onCallEvent(ev) {
  const st = ev && ev.state;
  const incoming = !!(ev && ev.incoming);
  const number = (ev && ev.number) || '';
  if (incoming) return handleIncoming(st, number);

  if (!running) return;
  if (st === 'DIALING') { $('callState').textContent = '발신 중… (신호 감)'; return; }
  if (st === 'ACTIVE' || st === 'OFFHOOK') {
    callWasActive = true;
    if (!activeAt) activeAt = Date.now();
    if (phase === 'call' && !callEnded) $('callState').textContent = '통화 중… (상대 연결됨)';
    setStatus('통화 중', 'call');
    return;
  }
  if (st === 'DISCONNECTED' || st === 'IDLE') {
    if (phase !== 'call' || callEnded) return;
    callEnded = true;
    curDuration = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
    curTag = suggestTag(); highlightTag();
    const durTxt = callWasActive ? `통화 ${curDuration}초 · 결과 저장` : '안 받음(부재) · 저장';
    $('callState').textContent = '통화 종료됨 — ' + durTxt;
    $('memoTarget').textContent = (queue[idx] ? queue[idx].name + ' · ' + fmt(queue[idx].number) : '')
      + (curDuration ? ` · ${curDuration}초` : '');
    setStatus('결과 입력', 'watch');
  }
}

// 수신 통화 처리
function handleIncoming(st, number) {
  if (st === 'RINGING') {
    incomingNumber = number; incomingKnown = isKnownNumber(number); incomingSaved = false;
    activeAt = 0; callWasActive = false; callEnded = false; dialAt = Date.now();
    if (running) { pausedForIncoming = true; clearTimeout(waitTimer); clearTimeout(safetyTimer); }
    phase = 'call';
    openCallPanel('ring', lookupName(number), number);
    setStatus('수신 전화', 'watch');
    return;
  }
  if (st === 'ACTIVE') {
    callWasActive = true; if (!activeAt) activeAt = Date.now();
    openCallPanel('inActive', lookupName(number), number);
    setStatus('통화 중(수신)', 'call');
    return;
  }
  if (st === 'DISCONNECTED') {
    if (!callEnded) {
      callEnded = true;
      const dur = activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0;
      // 기존 고객이거나 사용자가 "고객 저장"을 누른 경우만 기록
      if (incomingKnown || incomingSaved) {
        const nm = lookupName(number) || '(수신)';
        records.push(makeRecord({ name: nm, number }, '수신', $('memoBox').value.trim(), dur, dialAt));
        save('cp_records', records); renderRecords();
      }
    }
    closeCallPanel();
    phase = 'idle';
    if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); }
    else setStatus('대기');
  }
}

async function saveAndNext() {
  if (!running || panelMode !== 'dial') return;
  if (!callEnded) { try { if (Dialer) await Dialer.endCall(); } catch (e) {} }
  if (queue[idx]) {
    queue[idx].done = true;
    queue[idx].tag = curTag || '';   // 통화 끝난 그룹에 결과 표시용
    queue[idx].updatedAt = nowIso();  // 📱 통화함 상태를 PC에도 전파(LWW)
    const dur = callEnded ? curDuration : (activeAt ? Math.round((Date.now() - activeAt) / 1000) : 0);
    records.push(makeRecord(queue[idx], curTag, $('memoBox').value.trim(), dur, dialAt));
    if (curTag === '차단요청') addToBlocklist(queue[idx].number);
    save('cp_queue', queue); save('cp_records', records);
  }
  closeCallPanel();
  renderQueue(); renderRecords();
  if (!running) { phase = 'idle'; setStatus('대기'); return; }
  scheduleNext();
}

function scheduleNext() {
  phase = 'waiting';
  clearTimeout(waitTimer);
  const w = Math.max(0, parseInt($('waitSec').value) || 0);
  setStatus(`${w}초 후 다음`, 'watch');
  waitTimer = setTimeout(() => { if (running && !pausedForIncoming) nextCall(); }, w * 1000);
}

async function stopAuto() {
  const wasActive = (phase === 'call');
  running = false; phase = 'idle'; pausedForIncoming = false;
  clearTimeout(safetyTimer); clearTimeout(waitTimer);
  $('startBtn').disabled = false; $('stopBtn').disabled = true; $('nextBtn').disabled = true;
  try { if (Dialer && wasActive && !callEnded && panelMode === 'dial') await Dialer.endCall(); } catch (e) {}
  try { if (Dialer) Dialer.stopWatching(); } catch (e) {}
  closeCallPanel();
  setStatus('대기'); renderQueue();
}

// ---- 미리보기용 흉내 ----
function mockCall() {
  setTimeout(() => onCallEvent({ state: 'DIALING' }), 400);
  setTimeout(() => onCallEvent({ state: 'ACTIVE' }), 1600);
  setTimeout(() => onCallEvent({ state: 'DISCONNECTED' }), 4200);
}

// ---- 이벤트 바인딩 ----
$('addBtn').onclick = () => {
  const add = parseLines($('pasteBox').value);
  if (!add.length) { toast('인식된 번호가 없습니다'); return; }
  const existing = new Set(queue.map(q => normNum(q.number)));
  const fresh = [];
  let dup = 0;
  add.forEach(a => { const n = normNum(a.number); if (existing.has(n)) dup++; else { existing.add(n); ensureCustomerFields(a); fresh.push(a); } });
  queue = queue.concat(fresh); save('cp_queue', queue);
  $('pasteBox').value = ''; renderQueue();
  toast(`${fresh.length}명 추가` + (dup ? ` · 중복 ${dup}명 제외` : ''));
};
// 그룹별 비우기 / 선택 삭제 (모두 삭제를 PC에도 전파 = tombstone)
function removeQueueBy(pred, msg) {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const targets = queue.filter(pred);
  if (!targets.length) { toast('비울 항목이 없어요'); return; }
  if (!confirm(msg.replace('{n}', targets.length))) return;
  targets.forEach(t => { addTombstone(t.number); selQ.delete(t.id); });
  const del = new Set(targets.map(t => t.id));
  queue = queue.filter(q => !del.has(q.id));
  idx = -1;
  save('cp_queue', queue); renderQueue();
}
// 🧹 목록 비우기 → 통화 전 / 통화 후 / 선택 삭제 중 고르기 (평소엔 버튼 하나만 노출)
function openClearMenu() {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  const pre = queue.filter(q => !q.done).length;
  const done = queue.filter(q => q.done).length;
  const { ov, close } = buildOverlay('clearMenuOv',
    `<div class="cp-ov-h">목록 비우기</div>
     <div class="cp-ov-note">어떤 걸 지울지 고르세요.</div>
     <button class="btn ghost danger cm-btn" id="cmPre">📞 통화 전 전부 비우기 (${pre})</button>
     <button class="btn ghost danger cm-btn" id="cmDone">✅ 통화 후 전부 비우기 (${done})</button>
     <button class="btn ghost cm-btn" id="cmSel">☑️ 하나씩 골라 삭제</button>
     <button class="btn ghost cm-btn" id="cmCancel">취소</button>`);
  ov.querySelector('#cmPre').onclick = () => { close(); removeQueueBy(q => !q.done, '통화 전 {n}명을 비울까요?'); };
  ov.querySelector('#cmDone').onclick = () => { close(); removeQueueBy(q => q.done, '통화 후 {n}명을 비울까요?'); };
  ov.querySelector('#cmSel').onclick = () => { close(); enterSelMode(); };
  ov.querySelector('#cmCancel').onclick = close;
}
$('clearMenuBtn').onclick = openClearMenu;
$('selCancelBtn').onclick = exitSelMode;
$('delSelBtn').onclick = () => {
  if (!selQ.size) { toast('지울 항목을 체크하세요'); return; }
  removeQueueBy(q => selQ.has(q.id), '선택한 {n}명을 삭제할까요?');
  exitSelMode();
};
$('startBtn').onclick = startAuto;
$('stopBtn').onclick = () => { stopAuto(); toast('정지됨'); };
// ▶▶ 다음 번호 (PC와 동일) — 통화 중이면 결과 저장 후 다음, 대기 중이면 바로 다음 발신
$('nextBtn').onclick = () => {
  if (!running) { toast('자동발신 시작 후 사용하세요'); return; }
  if (panelMode === 'dial' && !$('callPanel').hidden) saveAndNext();
  else nextCall();
};
$('saveBtn').onclick = saveAndNext;
$('skipBtn').onclick = () => { curTag = curTag || '건너뜀'; saveAndNext(); };
$('endCallBtn').onclick = async () => {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  if (panelMode !== 'dial') { closeCallPanel(); phase = 'idle'; if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기'); return; }
  stopAuto();
  toast('통화 종료 · 자동발신 멈춤');
};
$('answerBtn').onclick = async () => { try { if (Dialer) await Dialer.answerCall(); } catch (e) {} };
$('rejectBtn').onclick = async () => {
  try { if (Dialer) await Dialer.endCall(); } catch (e) {}
  closeCallPanel(); phase = 'idle';
  if (running && pausedForIncoming) { pausedForIncoming = false; scheduleNext(); } else setStatus('대기');
};
$('saveCustomerBtn').onclick = () => {
  const n = normNum(incomingNumber);
  if (n && !queue.some(q => normNum(q.number) === n)) {
    queue.push(ensureCustomerFields({ name: '(이름없음)', number: n, done: false }));
    save('cp_queue', queue); renderQueue();
  }
  incomingSaved = true;
  $('saveCustomerBtn').textContent = '고객목록에 저장됨 ✓';
  $('saveCustomerBtn').disabled = true;
};
$('muteBtn').onclick = async () => { muteOn = !muteOn; syncCtl(); try { if (Dialer) await Dialer.setMute(muteOn); } catch (e) {} };
$('speakerBtn').onclick = async () => { speakerOn = !speakerOn; syncCtl(); try { if (Dialer) await Dialer.setSpeaker(speakerOn); } catch (e) {} };

// ============================================================
//  🔁 다시 걸기 + 통화기록 결과 수정 (모달)
// ============================================================
// 공용 오버레이 (배경클릭·✕·Esc 로 닫힘)
function buildOverlay(id, innerHtml) {
  const old = document.getElementById(id); if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = id; ov.className = 'cp-ov';
  ov.innerHTML = `<div class="cp-ov-box">${innerHtml}</div>`;
  document.body.appendChild(ov);
  const close = () => { ov.remove(); document.removeEventListener('keydown', onEsc); };
  function onEsc(e) { if (e.key === 'Escape') close(); }
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', onEsc);
  return { ov, close };
}

// 통화기록 한 건: 결과 태그·메모 수정
function openRecordEdit(id) {
  const r = records.find(x => x.id === id); if (!r) return;
  const tagBtns = TAGS.map(t => `<button class="tag${t === r.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('recEditOv',
    `<div class="cp-ov-h">기록 수정 · ${esc(r.name || '')} <span class="cp-ov-sub">${fmt(r.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="reTags">${tagBtns}</div>
     <div class="cp-ov-lbl">메모</div>
     <textarea id="reMemo" rows="3" placeholder="메모…">${esc(r.memo || '')}</textarea>
     <div class="row">
       <button class="btn primary" id="reSave">저장</button>
       <button class="btn ghost" id="reCancel">취소</button>
     </div>`);
  let sel = r.tag || '';
  ov.querySelectorAll('#reTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#reTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#reCancel').onclick = close;
  ov.querySelector('#reSave').onclick = () => {
    r.tag = sel; r.memo = ov.querySelector('#reMemo').value.trim();
    r.time = nowIso();                       // 수정시각(동기화 LWW용)
    if (sel === '차단요청') addToBlocklist(r.number);
    // 발신목록의 같은 번호(통화 끝난)에도 결과 반영
    const q = queue.find(x => normNum(x.number) === normNum(r.number) && x.done);
    if (q) q.tag = sel;
    save('cp_records', records); save('cp_queue', queue);
    renderRecords(); renderQueue();
    close(); toast('기록을 고쳤어요');
  };
}

// 통화 후 발신목록 항목: 통화 결과(태그) 수정. 같은 번호 통화기록이 있으면 그 기록 편집기로(양방향 반영), 없으면 태그만.
function openQueueEdit(id) {
  const q = queue.find(x => x.id === id); if (!q) return;
  const rec = records.slice().reverse().find(r => normNum(r.number) === normNum(q.number));
  if (rec) { openRecordEdit(rec.id); return; }
  const tagBtns = TAGS.map(t => `<button class="tag${t === q.tag ? ' on' : ''}" data-t="${t}">${t}</button>`).join('');
  const { ov, close } = buildOverlay('qEditOv',
    `<div class="cp-ov-h">통화 결과 · ${esc(q.name || '')} <span class="cp-ov-sub">${fmt(q.number)}</span></div>
     <div class="cp-ov-lbl">통화 결과</div>
     <div class="tags" id="qeTags">${tagBtns}</div>
     <div class="row">
       <button class="btn primary" id="qeSave">저장</button>
       <button class="btn ghost" id="qeCancel">취소</button>
     </div>`);
  let sel = q.tag || '';
  ov.querySelectorAll('#qeTags .tag').forEach(b => b.onclick = () => {
    sel = (sel === b.dataset.t) ? '' : b.dataset.t;
    ov.querySelectorAll('#qeTags .tag').forEach(x => x.classList.toggle('on', x.dataset.t === sel));
  });
  ov.querySelector('#qeCancel').onclick = close;
  ov.querySelector('#qeSave').onclick = () => {
    q.tag = sel; q.updatedAt = nowIso();
    if (sel === '차단요청') addToBlocklist(q.number);
    save('cp_queue', queue); renderQueue();
    close(); toast('통화 결과를 고쳤어요');
  };
}

// 다시 걸기: 최근 결과가 부재/나중연락인 번호 → 부재 횟수·통화 날짜 보고 골라서 발신목록에 재추가
function openRedial() {
  const byNum = {};
  records.forEach(r => {
    const n = normNum(r.number); if (!n) return;
    if (!byNum[n]) byNum[n] = { number: n, name: '', buje: 0, later: 0, bujeDates: [], last: 0, lastTag: '' };
    const g = byNum[n];
    if (r.name && r.name !== '(이름없음)') g.name = r.name;
    const t = r.dialAt ? new Date(r.dialAt).getTime() : (r.time ? new Date(r.time).getTime() : 0);
    if (r.tag === '부재') { g.buje++; if (t) g.bujeDates.push(t); }
    else if (r.tag === '나중연락') g.later++;
    if (t >= g.last) { g.last = t; g.lastTag = r.tag || ''; }
  });
  let cands = Object.values(byNum).filter(g => g.lastTag === '부재' || g.lastTag === '나중연락');
  cands.sort((a, b) => a.last - b.last);   // 오래된(먼저 연락해야 할) 순
  const DAY = 86400000;
  const inQ = new Set(queue.filter(q => !q.done).map(q => normNum(q.number)));   // 이미 발신대기 중인 번호
  const { ov, close } = buildOverlay('redialOv',
    `<div class="cp-ov-h">🔁 다시 걸기 <span class="cp-ov-sub">부재·나중연락 ${cands.length}명</span></div>
     <div class="cp-ov-note">부재 횟수와 마지막 통화일을 보고, 오늘 다시 걸 사람을 골라 발신목록(통화 전)에 올리세요.</div>
     <div class="rd-filter" id="rdFilter">
       <button class="rd-f on" data-d="0">전체</button>
       <button class="rd-f" data-d="1">1일↑ 지남</button>
       <button class="rd-f" data-d="2">2일↑ 지남</button>
       <button class="rd-f" data-d="3">3일↑ 지남</button>
     </div>
     <div class="rd-list" id="rdList"></div>
     <div class="row">
       <button class="btn primary" id="rdAdd">선택 발신목록에 추가</button>
       <button class="btn ghost" id="rdClose">닫기</button>
     </div>`);
  let minDays = 0;
  const picked = new Set();
  function daysAgo(t) { return t ? Math.floor((Date.now() - t) / DAY) : 999; }
  function mdOf(t) { const d = new Date(t); return isNaN(d) ? '' : `${d.getMonth() + 1}/${d.getDate()}`; }
  function draw() {
    const list = ov.querySelector('#rdList');
    const shown = cands.filter(g => daysAgo(g.last) >= minDays);
    if (!shown.length) { list.innerHTML = '<div class="rd-empty">해당하는 대상이 없어요.</div>'; return; }
    list.innerHTML = shown.map(g => {
      const da = daysAgo(g.last);
      const dates = g.bujeDates.sort((a, b) => a - b).map(mdOf).filter(Boolean).join(', ');
      const cntTxt = [g.buje ? `부재 ${g.buje}회` : '', g.later ? `나중연락 ${g.later}회` : ''].filter(Boolean).join(' · ');
      const already = inQ.has(g.number) ? ' <span class="rd-inq">발신대기중</span>' : '';
      return `<label class="rd-row${picked.has(g.number) ? ' pk' : ''}" data-n="${g.number}">
        <input type="checkbox" ${picked.has(g.number) ? 'checked' : ''}>
        <div class="rd-main">
          <div class="rd-top"><b>${esc(g.name || '(이름없음)')}</b> <span class="rd-no">${fmt(g.number)}</span>${already}</div>
          <div class="rd-meta">${cntTxt || '재콜 대상'} · 마지막 ${mdOf(g.last)} (${da}일 전)${dates ? ' · 부재일: ' + dates : ''}</div>
        </div></label>`;
    }).join('');
    list.querySelectorAll('.rd-row').forEach(row => {
      const n = row.dataset.n, cb = row.querySelector('input');
      cb.onchange = () => { if (cb.checked) picked.add(n); else picked.delete(n); row.classList.toggle('pk', cb.checked); };
    });
  }
  ov.querySelectorAll('#rdFilter .rd-f').forEach(b => b.onclick = () => {
    minDays = +b.dataset.d;
    ov.querySelectorAll('#rdFilter .rd-f').forEach(x => x.classList.toggle('on', x === b));
    draw();
  });
  ov.querySelector('#rdClose').onclick = close;
  ov.querySelector('#rdAdd').onclick = () => {
    if (!picked.size) { toast('추가할 사람을 선택하세요'); return; }
    let added = 0;
    picked.forEach(n => {
      const g = byNum[n]; if (!g) return;
      const ex = queue.find(q => normNum(q.number) === n);
      if (ex) { ex.done = false; ex.tag = ''; ex.updatedAt = nowIso(); }   // 이미 목록에 있으면 다시 '안 건'으로 되돌림(PC에도 전파)
      else { queue.push(ensureCustomerFields({ name: g.name || '(이름없음)', number: n, done: false })); }
      added++;
    });
    save('cp_queue', queue); renderQueue();
    close(); toast(`${added}명을 발신목록(통화 전)에 올렸어요`);
  };
  draw();
}
$('redialBtn').onclick = openRedial;
$('wipeBtn').onclick = () => {
  if (running) { toast('자동발신 정지 후 사용하세요'); return; }
  if (confirm('통화기록을 삭제할까요?')) { records = []; save('cp_records', records); renderRecords(); }
};

const scriptBox = $('scriptBox');
if (scriptBox) {
  scriptBox.value = load('cp_script', '');
  scriptBox.addEventListener('input', () => save('cp_script', scriptBox.value));
}
const defaultDialerBtn = $('defaultDialerBtn');
if (defaultDialerBtn) defaultDialerBtn.onclick = async () => {
  try { if (Dialer) await Dialer.requestDefaultDialer(); } catch (e) {}
  await refreshDefaultDialer();
  toast(isDefaultDialer ? '기본 전화 앱으로 설정됨' : '설정 화면에서 콜파일럿을 선택해주세요', 2600);
};

if (Dialer) {
  Dialer.addListener('callStateChanged', (ev) => onCallEvent(ev || {}));
  // 콜드 스타트 복구: 앱이 (수신 전화로) 막 켜졌으면 놓친 신호를 현재 상태로 보완
  Dialer.getCurrentCall().then(c => {
    if (c && c.state && c.state !== 'NONE' && c.state !== 'DISCONNECTED') onCallEvent(c);
  }).catch(() => {});
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshDefaultDialer(); });
refreshDefaultDialer();

(function () {
  const v = document.querySelector('.brand .ver');
  const wv = (window.CPOta && window.CPOta.webVersion) ? ' · 웹 v' + window.CPOta.webVersion : '';
  if (v) v.textContent = (isNative ? (Dialer ? '모바일 · 실기기' : '모바일 · ⚠️모듈없음') : '모바일 · 미리보기') + wv;
})();

migrateQueue();
buildTagButtons();
renderQueue(); renderRecords(); setStatus('대기');
